﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common.Drawing.InspectionInformation
{
    #region Fiducial Align type.
    /// <summary>   Strip align default value.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
    public static class StripAlignDefaultValue
    {
        public static bool DefaultValueLoaded = false;

        public static int AlignMarginX;     // 0043
        public static int AlignMarginY;     // 0044
        public static int AlignAcceptance;  // 0045

        public static void LoadDefaultValue()
        {
            string inspectTypeCode = "0101";
            string fiducialAlignCode = "3001";
            AlignMarginX = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, fiducialAlignCode, "0043");
            AlignMarginY = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, fiducialAlignCode, "0044");
            AlignAcceptance = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, fiducialAlignCode, "0045");
        }
    }

    /// <summary>   Unit align default value.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
    public static class UnitAlignDefaultValue
    {
        public static bool DefaultValueLoaded = false;

        public static int AlignMarginX;     // 0043
        public static int AlignMarginY;     // 0044
        public static int AlignAcceptance;  // 0045

        public static void LoadDefaultValue()
        {
            string inspectTypeCode = "0401";
            string fiducialAlignCode = "3001";
            AlignMarginX = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, fiducialAlignCode, "0043");
            AlignMarginY = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, fiducialAlignCode, "0044");
            AlignAcceptance = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, fiducialAlignCode, "0045");
        }
    }
    #endregion

    #region Lead Shape With Center Line Type.
    /// <summary>   Lead shape with center line default value.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
    public static class LeadShapeWithCenterLineDefaultValue
    {
        public static bool DefaultValueLoaded = false;

        public static int ThreshType;       // 0000
        public static int LowerThresh;      // 0001
        public static int UpperThresh;      // 0002
        public static int MinWidthRatio;    // 0030
        public static int MinWidthSize;     // 0031
        public static int MaxWidthRatio;    // 0032
        public static int MaxWidthSize;     // 0033
        public static int MinHeightsize;    // 0035
        public static int MinNormalRatio;   // 0038
        public static int MaxNormalRatio;   // 0039

        public static void LoadDefaultValue()
        {
            string inspectTypeCode = "0415";
            string leadShapeWithCenterLineCode = "3008";
            ThreshType = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, leadShapeWithCenterLineCode, "0000");
            LowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, leadShapeWithCenterLineCode, "0001");
            UpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, leadShapeWithCenterLineCode, "0002");
            MinWidthRatio = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, leadShapeWithCenterLineCode, "0030");
            MinWidthSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, leadShapeWithCenterLineCode, "0031");
            MaxWidthRatio = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, leadShapeWithCenterLineCode, "0032");
            MaxWidthSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, leadShapeWithCenterLineCode, "0033");
            MinHeightsize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, leadShapeWithCenterLineCode, "0035");
            MinNormalRatio = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, leadShapeWithCenterLineCode, "0038");
            MaxNormalRatio = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, leadShapeWithCenterLineCode, "0039");
        }
    }

    /// <summary>   Lead gap default value.  </summary>
    /// <remarks>   Shin.Cheol-min, 2011-11-16. </remarks>
    public static class LeadGapDefaultValue
    {
        public static bool DefaultValueLoaded = false;

        public static int LowerThresh;      // 0001
        public static int UpperThresh;      // 0002
        public static int MinWidthSize;     // 0031

        public static void LoadDefaultValue()
        {
            string inspectTypeCode = "0435";
            string LeadGapCode = "3017";
            LowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, LeadGapCode, "0001");
            UpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, LeadGapCode, "0002");
            MinWidthSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, LeadGapCode, "0031");
        }
    }
    #endregion

    #region Groove With Center Line Type.
    /// <summary>   Groove default value.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
    public static class GrooveDefaultValue
    {
        public static bool DefaultValueLoaded = false;

        public static int ThreshType;           // 0000
        public static int LowerThresh;          // 0001
        public static int UpperThresh;          // 0002
        public static int ApplyAverDiff;        // 0003
        public static int AverMinMargin;        // 0007
        public static int AverMaxMargin;        // 0008
        public static int MinWidthRatio;        // 0030
        public static int MinWidthSize;         // 0031
        public static int MaxWidthRatio;        // 0032
        public static int MaxWidthSize;         // 0033
        public static int MinHeightSize;        // 0035
        public static int MaxHeightRatio;       // 0036
        public static int MaxHeightSize;        // 0037
        public static int CriterionSize;        // 0048
        public static int MinNormalRatio;       // 0038
        public static int MaxNormalRatio;       // 0039

        public static void LoadDefaultValue()
        {
            string inspectTypeCode = "0416";
            string grooveCode = "3009";
            ThreshType = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0000");
            LowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0001");
            UpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0002");
            ApplyAverDiff = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0003");
            AverMinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0007");
            AverMaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0008");
            MinWidthRatio = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0030");
            MinWidthSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0031");
            MaxWidthRatio = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0032");
            MaxWidthSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0033");
            MinHeightSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0035");
            MaxHeightRatio = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0036");
            MaxHeightSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0037");
            CriterionSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0048");
            MinNormalRatio = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0038");
            MaxNormalRatio = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, grooveCode, "0039");
        }
    }
    #endregion

    #region Figure Shape Type.

    /// <summary>   Shape half etching default value.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
    public static class ShapeHalfEtchingDefaultValue
    {
        public static bool DefaultValueLoaded = false;

        public static int InspRange;            // 0006
        public static int AverMinMargin;        // 0007
        public static int AverMaxMargin;        // 0008
        public static int MinMargin;            // 0009
        public static int MaxMargin;            // 0010
        public static int ErosionTrainIter;     // 0011
        public static int DilationTrainIter;    // 0012
        public static int ErosionInspIter;      // 0013
        public static int DilationInspIter;     // 0014
        public static int MinWidthSize;         // 0031
        public static int MinHeightSize;        // 0035
        public static int MinNormalRatio;       // 0038
        public static int MaxNormalRatio;       // 0039
        public static int AlignMaxDist;         // 0046
        public static int DarkAreaWidth;        // 0047

        public static void LoadDefaultValue()
        {
            string inspectTypeCode = "0417";
            string figureShapeCode = "3010";
            InspRange = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0006");
            AverMinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0007");
            AverMaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0008");
            MinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0009");
            MaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0010");
            ErosionTrainIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0011");
            DilationTrainIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0012");
            ErosionInspIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0013");
            DilationInspIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0014");
            MinWidthSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0031");
            MinHeightSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0035");
            MinNormalRatio = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0038");
            MaxNormalRatio = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0039");
            AlignMaxDist = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0046");
            DarkAreaWidth = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, figureShapeCode, "0047");
        }
    }
    #endregion

    #region State Intensity type.

    /// <summary>   Down set default value.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
    public static class DownSetDefaultValue
    {
        public static bool DefaultValueLoaded = false;

        public static int ThreshType;              // 0000
        public static int LowerThresh;             // 0001
        public static int UpperThresh;             // 0002
        public static int ApplyAverDiff;           // 0003
        public static int InspRange;               // 0006
        public static int AverMinMargin;           // 0007
        public static int AverMaxMargin;           // 0008
        public static int MinMargin;               // 0009
        public static int MaxMargin;               // 0010
        public static int ErosionTrainIter = 0;    // 0011
        public static int DilationTrainIter = 0;   // 0012
        public static int ErosionInspIter = 0;     // 0013
        public static int DilationInspIter = 0;    // 0014
        public static int MinDefectSize;           // 0015
        public static int Invert;                  // 0020

        public static void LoadDefaultValue()
        {
            string inspectTypeCode = "0419";
            string stateIntensityCode = "3011";
            ThreshType = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0000");
            LowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0001");
            UpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0002");
            ApplyAverDiff = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0003");
            InspRange = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0006");
            AverMinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0007");
            AverMaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0008");
            MinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0009");
            MaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0010");
            ErosionTrainIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0011");
            DilationTrainIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0012");
            ErosionInspIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0013");
            DilationInspIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0014");
            MinDefectSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0015");
            Invert = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateIntensityCode, "0020");
        }
    }
    #endregion

    #region State Aligned Mask type.
    /// <summary>   Surface half etching default value.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
    public static class SurfaceHalfEtchingDefaultValue
    {
        public static bool DefaultValueLoaded = false;

        public static int ThreshType;              // 0000
        public static int LowerThresh;             // 0001
        public static int UpperThresh;             // 0002
        public static int ApplyAverDiff;           // 0003
        public static int MaskLowerThresh;         // 0004
        public static int MaskUpperThresh;         // 0005
        public static int InspRange;               // 0006
        public static int AverMinMargin;           // 0007
        public static int AverMaxMargin;           // 0008
        public static int MinMargin;               // 0009
        public static int MaxMargin;               // 0010
        public static int ErosionTrainIter = 0;    // 0011
        public static int DilationTrainIter = 0;   // 0012
        public static int ErosionInspIter = 0;     // 0013
        public static int DilationInspIter = 0;    // 0014
        public static int MinDefectSize;           // 0015
        public static int MinSmallDefectSize;      // 0016
        public static int MinSmallDefectCount;     // 0017

        public static void LoadDefaultValue()
        {
            string inspectTypeCode = "0418";
            string stateAlignedMaskcode = "3012";
            ThreshType = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0000");
            LowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0001");
            UpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0002");
            ApplyAverDiff = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0003");
            MaskLowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0004");
            MaskUpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0005");
            InspRange = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0006");
            AverMinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0007");
            AverMaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0008");
            MinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0009");
            MaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0010");
            ErosionTrainIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0011");
            DilationTrainIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0012");
            ErosionInspIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0013");
            DilationInspIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0014");
            MinDefectSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0015");
            MinSmallDefectSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0016");
            MinSmallDefectCount = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0017");
            
        }
    }

    /// <summary>   Surface default value.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
    public static class SurfaceDefaultValue
    {
        public static bool DefaultValueLoaded = false;

        public static int ThreshType;              // 0000
        public static int LowerThresh;             // 0001
        public static int UpperThresh;             // 0002
        public static int ApplyAverDiff;           // 0003
        public static int MaskLowerThresh;         // 0004
        public static int MaskUpperThresh;         // 0005
        public static int InspRange;               // 0006
        public static int AverMinMargin;           // 0007
        public static int AverMaxMargin;           // 0008
        public static int MinMargin;               // 0009
        public static int MaxMargin;               // 0010
        public static int ErosionTrainIter = 0;    // 0011
        public static int DilationTrainIter = 0;   // 0012
        public static int ErosionInspIter = 0;     // 0013
        public static int DilationInspIter = 0;    // 0014
        public static int MinDefectSize;           // 0015
        public static int MinSmallDefectSize;      // 0016
        public static int MinSmallDefectCount;     // 0017

        public static void LoadDefaultValue()
        {
            string inspectTypeCode = "0422";
            string stateAlignedMaskcode = "3012";
            ThreshType = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0000");
            LowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0001");
            UpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0002");
            ApplyAverDiff = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0003");
            MaskLowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0004");
            MaskUpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0005");
            InspRange = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0006");
            AverMinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0007");
            AverMaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0008");
            MinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0009");
            MaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0010");
            ErosionTrainIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0011");
            DilationTrainIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0012");
            ErosionInspIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0013");
            DilationInspIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0014");
            MinDefectSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0015");
            MinSmallDefectSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0016");
            MinSmallDefectCount = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0017");
        }
    }

    /// <summary>   Space default value.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
    public static class SpaceDefaultValue
    {
        public static bool DefaultValueLoaded = false;

        public static int ThreshType;              // 0000
        public static int LowerThresh;             // 0001
        public static int UpperThresh;             // 0002
        public static int ApplyAverDiff;           // 0003
        public static int MaskLowerThresh;         // 0004
        public static int MaskUpperThresh;         // 0005
        public static int InspRange;               // 0006
        public static int AverMinMargin;           // 0007
        public static int AverMaxMargin;           // 0008
        public static int MinMargin;               // 0009
        public static int MaxMargin;               // 0010
        public static int ErosionTrainIter = 0;    // 0011
        public static int DilationTrainIter = 0;   // 0012
        public static int ErosionInspIter = 0;     // 0013
        public static int DilationInspIter = 0;    // 0014
        public static int MinDefectSize;           // 0015
        public static int MinSmallDefectSize;      // 0016
        public static int MinSmallDefectCount;     // 0017

        public static void LoadDefaultValue()
        {
            string inspectTypeCode = "0423";
            string stateAlignedMaskcode = "3012";
            ThreshType = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0000");
            LowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0001");
            UpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0002");
            ApplyAverDiff = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0003");
            MaskLowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0004");
            MaskUpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0005");
            InspRange = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0006");
            AverMinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0007");
            AverMaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0008");
            MinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0009");
            MaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0010");
            ErosionTrainIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0011");
            DilationTrainIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0012");
            ErosionInspIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0013");
            DilationInspIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0014");
            MinDefectSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0015");
            MinSmallDefectSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0016");
            MinSmallDefectCount = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, stateAlignedMaskcode, "0017");
        }
    }
    #endregion

    #region Shape Shift type.
    /// <summary>   Tape default value.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
    public static class TapeDefaultValue
    {
        public static bool DefaultValueLoaded = false;

        public static int ThreshType;              // 0000
        public static int LowerThresh;             // 0001
        public static int UpperThresh;             // 0002
        public static int ApplyAverDiff;           // 0003
        public static int MaskLowerThresh;         // 0004
        public static int MaskUpperThresh;         // 0005
        public static int InspRange;               // 0006
        public static int AverMinMargin;           // 0007
        public static int AverMaxMargin;           // 0008
        public static int MinMargin;               // 0009
        public static int MaxMargin;               // 0010
        public static int ErosionTrainIter = 0;    // 0011
        public static int DilationTrainIter = 0;   // 0012
        public static int ErosionInspIter = 0;     // 0013
        public static int DilationInspIter = 0;    // 0014
        public static int MinDefectSize;           // 0015
        public static int MinSmallDefectSize;      // 0016
        public static int MinSmallDefectCount;     // 0017
        public static int ErosionShapeIter;        // 0021  
        public static int DilationShapeIter;       // 0022
        public static int GroundLowerThresh;       // 0023
        public static int GroundUpperThresh;       // 0024
        public static int ShapeLowerThresh;        // 0025
        public static int ShapeUpperThresh;        // 0026
        public static int CorrectMethod;           // 0027
        public static int ShapeShiftMarginX;       // 0028
        public static int ShapeShiftMarginY;       // 0029

        public static void LoadDefaultValue()
        {
            string inspectTypeCode = "0420";
            string shapeShiftCode = "3005";
            ThreshType = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0000");
            LowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0001");
            UpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0002");
            ApplyAverDiff = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0003");
            MaskLowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0004");
            MaskUpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0005");
            InspRange = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0006");
            AverMinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0007");
            AverMaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0008");
            MinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0009");
            MaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0010");
            ErosionTrainIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0011");
            DilationTrainIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0012");
            ErosionInspIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0013");
            DilationInspIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0014");
            MinDefectSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0015");
            MinSmallDefectSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0016");
            MinSmallDefectCount = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0017");
            ErosionShapeIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0021");
            DilationShapeIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0022");
            GroundLowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0023");
            GroundUpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0024");
            ShapeLowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0025");
            ShapeUpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0026");
            CorrectMethod = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0027");
            ShapeShiftMarginX = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0028");
            ShapeShiftMarginY = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0029");
        }
    }

    /// <summary>   Plate default value.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
    public static class PlateDefaultValue
    {
        public static bool DefaultValueLoaded = false;

        public static int ThreshType;              // 0000
        public static int LowerThresh;             // 0001
        public static int UpperThresh;             // 0002
        public static int ApplyAverDiff;           // 0003
        public static int MaskLowerThresh;         // 0004
        public static int MaskUpperThresh;         // 0005
        public static int InspRange;               // 0006
        public static int AverMinMargin;           // 0007
        public static int AverMaxMargin;           // 0008
        public static int MinMargin;               // 0009
        public static int MaxMargin;               // 0010
        public static int ErosionTrainIter = 0;    // 0011
        public static int DilationTrainIter = 0;   // 0012
        public static int ErosionInspIter = 0;     // 0013
        public static int DilationInspIter = 0;    // 0014
        public static int MinDefectSize;           // 0015
        public static int MinSmallDefectSize;      // 0016
        public static int MinSmallDefectCount;     // 0017
        public static int ErosionShapeIter;        // 0021  
        public static int DilationShapeIter;       // 0022
        public static int GroundLowerThresh;       // 0023
        public static int GroundUpperThresh;       // 0024
        public static int ShapeLowerThresh;        // 0025
        public static int ShapeUpperThresh;        // 0026
        public static int CorrectMethod;           // 0027
        public static int ShapeShiftMarginX;       // 0028
        public static int ShapeShiftMarginY;       // 0029

        public static void LoadDefaultValue()
        {
            string inspectTypeCode = "0421";
            string shapeShiftCode = "3005";
            ThreshType = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0000");
            LowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0001");
            UpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0002");
            ApplyAverDiff = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0003");
            MaskLowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0004");
            MaskUpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0005");
            InspRange = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0006");
            AverMinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0007");
            AverMaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0008");
            MinMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0009");
            MaxMargin = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0010");
            ErosionTrainIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0011");
            DilationTrainIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0012");
            ErosionInspIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0013");
            DilationInspIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0014");
            MinDefectSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0015");
            MinSmallDefectSize = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0016");
            MinSmallDefectCount = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0017");
            ErosionShapeIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0021");
            DilationShapeIter = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0022");
            GroundLowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0023");
            GroundUpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0024");
            ShapeLowerThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0025");
            ShapeUpperThresh = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0026");
            CorrectMethod = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0027");
            ShapeShiftMarginX = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0028");
            ShapeShiftMarginY = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, shapeShiftCode, "0029");
        }
    }
    #endregion

    /// <summary>   Exceptional Mask default value.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
    public static class ExceptionalMaskDefaultValue
    {
        public static bool DefaultValueLoaded = false;

        public static int ExceptionX;             // 0000
        public static int ExceptionY;             // 0001
        public static int UseShapeShift;          // 0002

        public static void LoadDefaultValue()
        {
            string inspectTypeCode = "0999";
            string exceptionalMaskCode = "3016";
            ExceptionX = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, exceptionalMaskCode, "0000");
            ExceptionY = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, exceptionalMaskCode, "0001");
            UseShapeShift = InspectionQueryHelper.GetDefaultParamValue(inspectTypeCode, exceptionalMaskCode, "0002");
        }
    }
}
