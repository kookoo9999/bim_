﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.Drawing.InspectionTypeUI;

namespace Common.Drawing.InspectionInformation
{
    /// <summary>   Inspection item helper.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
    public static class InspectionItemHelper
    {
        /// <summary>   Copies the inspection item described by inspectionItem. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-11. </remarks>
        public static InspectionItem CopyInspectionItem(InspectionItem inspectionItem)
        {
            if (inspectionItem != null && inspectionItem.InspectionAlgorithm != null && inspectionItem.InspectionType != null)
            {
                InspectionItem copiedInspectionItem = new InspectionItem();
                copiedInspectionItem.ID = inspectionItem.ID;
                copiedInspectionItem.InspectionType = inspectionItem.InspectionType;

                // 검사 설정 값은 독자적으로 관리되어야 하기 때문에 Deep copy를 수행하여준다.
                copiedInspectionItem.InspectionAlgorithm = inspectionItem.InspectionAlgorithm.Clone();

                return copiedInspectionItem;
            }
            else
            {
                return inspectionItem;
            }
        }

        /// <summary>   Gets an inspection item. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        /// <returns>   The inspection item. </returns>
        public static InspectionItem GetInspectionItem(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode,
            string strRoiCode, string strInspectID, string strInspectCode)
        {
            InspectionType inspectionType = null;
            List<InspectionType> inspectionTypeList = InspectionType.GetInspectionTypeList();
            foreach (InspectionType inspectionTypeElement in inspectionTypeList)
            {
                if (strInspectCode == inspectionTypeElement.Code)
                {
                    inspectionType = inspectionTypeElement;
                }
            }

            if (inspectionType == null)
            {
                return null;
            }

            switch (inspectionType.InspectType)
            {
                case eVisInspectType.eInspTypeGlobalAlign: // Strip Align
                case eVisInspectType.eInspTypeUnitAlign: // Unit Align
                    FiducialAlignProperty fiducialAlignProperty = new FiducialAlignProperty();
                    fiducialAlignProperty.LoadProperty(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, inspectionType.Code);
                    return new InspectionItem(inspectionType, fiducialAlignProperty, int.Parse(strInspectID));
                //break;

                case eVisInspectType.eInspTypeLeadShapeWithCL: // 리드 형상 검사
                    LeadShapeWithCenterLineProperty leadShapeWithCenterLineProperty = new LeadShapeWithCenterLineProperty();
                    leadShapeWithCenterLineProperty.LoadProperty(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, inspectionType.Code);
                    return new InspectionItem(inspectionType, leadShapeWithCenterLineProperty, int.Parse(strInspectID));
                //break;

                case eVisInspectType.eInspTypeGroove: // 그루브 검사
                    GrooveProperty grooveProperty = new GrooveProperty();
                    grooveProperty.LoadProperty(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, inspectionType.Code);
                    return new InspectionItem(inspectionType, grooveProperty, int.Parse(strInspectID));
                //break;

                case eVisInspectType.eInspTypeShapeHalfEtching: // 형상 Half Etching 검사
                    FigureShapeProperty figureShapeProperty = new FigureShapeProperty();
                    figureShapeProperty.LoadProperty(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, inspectionType.Code);
                    return new InspectionItem(inspectionType, figureShapeProperty, int.Parse(strInspectID));
                //break;

                case eVisInspectType.eInspTypeDownSet: // D/S 검사
                    StateIntensityProperty stateIntensityProperty = new StateIntensityProperty();
                    stateIntensityProperty.LoadProperty(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, inspectionType.Code);
                    return new InspectionItem(inspectionType, stateIntensityProperty, int.Parse(strInspectID));
                //break;

                case eVisInspectType.eInspTypeTape: // T/P 검사
                case eVisInspectType.eInspTypePlate: // 도금 검사
                    ShapeShiftProperty shapeShiftProperty = new ShapeShiftProperty();
                    shapeShiftProperty.LoadProperty(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, inspectionType.Code);
                    return new InspectionItem(inspectionType, shapeShiftProperty, int.Parse(strInspectID));
                //break;

                case eVisInspectType.eInspTypeSurfaceHalfEtching: // 표면 Half Etching 검사
                case eVisInspectType.eInspTypeSurface: // 표면 검사
                case eVisInspectType.eInspTypeSpace: // 공간 검사
                    StateAlignedMaskProperty stateAlignedMaskProperty = new StateAlignedMaskProperty();
                    stateAlignedMaskProperty.LoadProperty(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, inspectionType.Code);
                    return new InspectionItem(inspectionType, stateAlignedMaskProperty, int.Parse(strInspectID));
                //break;
                case eVisInspectType.eInspTypeLeadGap: // 공간 검사
                    LeadGapProperty leadGapProperty = new LeadGapProperty();
                    leadGapProperty.LoadProperty(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, inspectionType.Code);
                    return new InspectionItem(inspectionType, leadGapProperty, int.Parse(strInspectID));
                case eVisInspectType.eInspTypeExceptionalMask:
                    ExceptionalMaskProperty exceptionalMaskProperty = new ExceptionalMaskProperty();
                    exceptionalMaskProperty.LoadProperty(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, inspectionType.Code);
                    return new InspectionItem(inspectionType, exceptionalMaskProperty, int.Parse(strInspectID));
                default:
                    return null;
            }
        }
    }
}
