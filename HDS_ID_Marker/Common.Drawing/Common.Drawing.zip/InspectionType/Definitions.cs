﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common.Drawing.InspectionInformation
{
    /// <summary>   Values that represent Inspection Type ID.  </summary>
    public enum eVisInspectType
    {
        eInspTypeNone = 0,	// 없음

        eInspTypeGlobalAlign = 101,	// Strip Align
        eInspTypeGlobalCross = 102,	// Strip 십자가
        eInspTypeGlobalPsrShift = 103,	// Strip PSR Shift
        eInspTypeGlobalBallPsr = 104,	// Strip Ball PSR Shift
        eInspTypeGlobalAlignedMask = 111,	// Strip 마스크 검사
        eInspTypeGlobalIntensity = 112,	// Strip 밝기 검사

        eInspTypeRailAlign = 201,	// 외곽 Align
        eInspTypeRailCross = 202,	// 외곽 십자가
        eInspTypeRailPsrShift = 203,	// 외곽 PSR Shift
        eInspTypeRailBallPsr = 204,	// 외곽 Ball PSR Shift
        eInspTypeRailAlignedMask = 211,	// 외곽 마스크 검사
        eInspTypeRailIntensity = 212,	// 외곽 밝기 검사

        eInspTypeBlockAlign = 301,	// 블록 Align
        eInspTypeBlockCross = 302,	// 블록 십자가
        eInspTypeBlockPsrShift = 303,	// 블록 PSR Shift
        eInspTypeBlockBallPsr = 304,	// 블록 Ball PSR Shift
        eInspTypeBlockAlignedMask = 311,	// 블록 마스크 검사
        eInspTypeBlockIntensity = 312,	// 블록 밝기 검사

        eInspTypeUnitAlign = 401,	// Unit Align
        eInspTypeUnitCross = 402,	// Unit 십자가
        eInspTypeUnitPsrShift = 403,	// Unit PSR Shift
        eInspTypeUnitBallPsr = 404,	// Unit Ball PSR Shift
        eInspTypeUnitTolerancePsr = 405,	// 치수 공차 Psr 검사 (PSR Shift Y, Punch Shift X,Y)
        eInspTypeUnitPunchShift = 406,	// Punch Shift (Punch Shift X, Y)

        eInspTypeUnitFidu = 411,	// 인식키 검사 (Aligned Mask)
        eInspTypeUnitRawMaterialNonPlate = 412,	// 원소재 미도금 (Aligned Mask)
        eInspTypeUnitRawMaterial = 413,	// 원소재 검사 (Aligned Mask)
        eInspTypeLeadShapeWithDir = 414,	// 리드 형상 검사
        eInspTypeLeadShapeWithCL = 415,	// 리드 형상 검사
        eInspTypeGroove = 416,	// Groove 전용 검사
        eInspTypeShapeHalfEtching = 417,	// 형상 Half-Etching
        eInspTypeSurfaceHalfEtching = 418,	// 표면 Half-Etching
        eInspTypeDownSet = 419,	// Down Set 검사
        eInspTypeTape = 420,	// Tape 검사
        eInspTypePlate = 421,	// 도금 검사
        eInspTypeSurface = 422,	// 표면 검사
        eInspTypeSpace = 423,	// 공간 검사
        eInspTypeBondPadState = 424,	// Bond-Pad 외관 (Aligned Mask)
        eInspTypeBondPadShapeWithDir = 425,	// Bond-Pad 패턴 (Shape with Dir)
        eInspTypeBondPadLift = 426,	// Bond-Pad 리드 들림 (Aligned Mask)
        eInspTypeBondPadInterval = 427,	// Bond-Pad 리드 간격 (Interval)
        eInspTypeCoreCrack = 428,	// Core Crack (Intensity)
        eInspTypeBallPattern = 429,	// Ball Pattern (Ball Pattern)
        eInspTypeBallLand = 430,	// Ball 영역 (Aligned Mask)
        eInspTypePSR = 431,	// PSR 영역 (Aligned Mask)
        eInspTypePunchBurr = 432,	// Punch Burr (Intensity)
        eInspTypeDamBar = 433,	// Dam Bar 검사(DamBar)
        eInspTypeVentHole = 434,	// Vent-Hole (Vent-Hole)
        eInspTypeLeadGap = 435,	// 리드 간격 검사(Interval)
        eInspTypeExceptionalMask = 999,	// Exceptional Mask
    }

    /// <summary>   Values that represent Grabber Type.  </summary>
    public enum eGrabberType
    {
        eGrabberFile = 0,
        eGrabberSapera = 1,
        eGrabberMulticam = 2,
        eGrabberMil = 3
    }

    /// <summary>   Values that represent Image Depth.  </summary>
    public enum eImageDepth
    {
        eColor8 = 8,
        eColor24 = 24,
        eColor32 = 32
    }

    /// <summary>   Values that represent Section Type.  </summary>
    public enum eSectionType
    {
        eSecTypeNone = 0,
        eSecTypeGlobal = 1,
        eSecTypeRail = 2,
        eSecTypeBlock = 3,
        eSecTypeUnit = 4
    }

    /// <summary>   Values that represent Drawing types.  </summary>
    public enum eVisDrawType
    {
        eDrawTypeNone = 0,		// 없음
        eDrawTypeRect = 1,		// 사각형
        eDrawTypeEllipse = 2,	// 원형
        eDrawTypeCross = 3,		// X 모양 (단순 Diplay용)
        eDrawTypeLine = 4,		// 선형
        eDrawTypePoly = 5		// 다각형
    }

    /// <summary>   Values that represent Inspection algorithms.  </summary>
    public enum eVisInspectAlgo
    {
        eInspAlgoFeatureAlign = 1,	// coefficient of correlation Align
        eInspAlgoBallPsrShift = 2,	// Ball PSR Shift 검사
        eInspAlgoCrossPattern = 3,	// 십자가 인식키 전용 검사
        eInspAlgoTolerance = 4,	// 공차 치수 검사(PSR Y, Punch Y 검사)
        eInspAlgoShapeShift = 5,	// Shape Shfit 검사
        eInspAlgoLeadGap = 6,	// 리드 간격 검사
        eInspAlgoShapeWithDir = 7,	// Shape Inspection
        eInspAlgoLeadWithCenterLine = 8,	// 중앙선 검사
        eInspAlgoGrooveWithCenterLine = 9,	// Groove 검사 with 중앙선
        eInspAlgoShapeHalfEtching = 10,	// 특이 형상 Half Etching 검사
        eInspAlgoStateIntensity = 11,	// State Intensity
        eInspAlgoStateAlignedMask = 12,	// State Inspection
        eInspAlgoBallPattern = 13,	// Ball 패턴 전용 검사
        eInspAlgoDamBar = 14,	// Dam Bar 검사
        eInspAlgoVentHole = 15,	// Via-Hole Inspection
        eInspAlgoExceptionalMask = 16,	// Exceptional Mask Area
    }

    /// <summary>   Values that represent Inspection Priority.  </summary>
    public enum eInspectPriority
    {
        eInspPriorityNone = 0,

        eInspPriorityGlobalAlign = 11,
        eInspPriorityGlobalPsr = 12,
        eInspPriorityGlobalFidu = 13,
        eInspPriorityGlobalNormal = 14,

        eInspPriorityRailAlign = 21,
        eInspPriorityRailPsr = 22,
        eInspPriorityRailFidu = 23,
        eInspPriorityRailNormal = 24,

        eInspPriorityBlockAlign = 31,
        eInspPriorityBlockPsr = 32,
        eInspPriorityBlockFidu = 33,
        eInspPriorityBlockNormal = 34,

        eInspPriorityUnitAlign = 41,
        eInspPriorityUnitPsr = 42,
        eInspPriorityUnitPunch = 43,
        eInspPriorityUnitFidu = 44,
        eInspPriorityUnitPlate = 45,
        eInspPriorityUnitRaw = 46,
        eInspPriorityUnitNormal = 47
    }

    /// <summary>   Values that represent Inspection result types.  </summary>
    public enum eVisInspectResultType
    {
        eInspectGood = 0,  // 양품

        // Strip 영역 불량
        eInspResultStripAlign = 101,	// Strip Align 불량
        eInspResultContamiInStripFidu = 102,	// Strip 인식키 오염
        eInspResultOpenInStripFidu = 103,	// Strip 인식키 단락
        eInspResultNonPlateInStripFidu = 104,	// Strip 인식키 미도금

        // 외곽 영역 불량
        eInspResultRailAlign = 201,	// Rail Align 불량
        eInspResultContamiInRailFidu = 202,	// Rail 인식키 오염
        eInspResultOpenInRailFidu = 203,	// Rail 인식키 단락
        eInspResultNonPlateInRailFidu = 204,	// Rail 인식키 미도금

        eInspResultPSRInRail = 211,	// Rail영역 PSR 불량
        eInspResultNonPSRInRail = 212,	// Rail영역 PSR 미도포 불량
        eInspResultContamiInRail = 213,  // Rail영역 오염성 불량
        eInspResultNonPlateInRail = 214,	// Rail영역 미도금 불량
        eInspResultScratchInRail = 215,	// Rail영역 스크래치 불량
        eInspResultForeignBodyInRail = 216,	// Rail영역 이물질 불량
        eInspResultPSRShiftInRail = 217,	// Rail영역 PSR Shift 불량

        // Block 영역 불량
        eInspResultBlockAlign = 301,	// Block Align 불량
        eInspResultContamiInBlockFidu = 302,	// Block 인식키 오염
        eInspResultOpenInBlockFidu = 303,	// Block 인식키 단락
        eInspResultNonPlateInBlockFidu = 304,	// Block 인식키 미도금

        eInspResultPSRInBlock = 311,	// Block영역 PSR 불량
        eInspResultNonPSRInBlock = 312,	// Block영역 PSR 미도포 불량
        eInspResultContamiInBlock = 313,   // Block영역 오염성 불량
        eInspResultNonPlateInBlock = 314,	// Block영역 미도금 불량
        eInspResultScratchInBlock = 315,	// Block영역 스크래치 불량
        eInspResultForeignBodyInBlock = 316,	// Block영역 이물질 불량
        eInspResultPSRShiftInBlock = 317,	// Block영역 PSR Shift 불량

        // Unit 영역 불량
        eInspResultUnitAlign = 401,	// Unit Align 불량
        eInspResultContamiInUnitFidu = 402,	// Unit 인식키 오염
        eInspResultOpenInUnitFidu = 403,	// Unit 인식키 단락
        eInspResultNonPlateInUnitFidu = 404,	// Unit 인식키 미도금
        eInspResultNonPlateInRawMeterial = 411,	// Dummy 불량 (제품 없음 or 조명 이상)
        eInspResultRawMaterial = 412,	// 원소재 불량 (1차 마킹 제품)
        eInspResultOpen = 413,	// Open성 불량
        eInspResultShort = 414,	// Short성 불량
        eInspResultMB = 415,	// MB성 불량
        eInspResultProtrusion = 416,	// 미성형 불량
        eInspResultLeadPinhole = 417,	// 리드 핀홀 불량
        eInspResultIsland = 418,	// 섬형 불량
        eInspResultPit = 419,	// Pit성 불량
        eInspResultNoLead = 420,	// 리드 탈락
        eInspResultCurvedLead = 421,	// 리드 휨
        eInspResultShortLead = 422,	// 리드 휨
        eInspResultLargeSurface = 423,	// 광역 표면 불량
        eInspResultLeadDeviation = 424,	// 리드 편차 불량
        eInspResultLeadLocation = 425,	// 리드 위치
        eInspResultMinWidth = 426,	// 최소 선폭 검사 이하 검출
        eInspResultMaxWidth = 427,  // 최대 선폭 검사 이상 검출
        eInspResultPSRInLead = 428,	// 리드 내 PSR 잔존
        eInspResultNodule = 429,	// 동돌출 불량
        eInspResultBondPadInterval = 430,	// 리드 간격 불량
        eInspResultSR = 431,	// SR 뭉침
        eInspResultPSR = 432,	// PSR 뭉침
        eInspResultNonSR = 433,	// SR 미도포
        eInspResultNonPSR = 434,	// PSR 미도포
        eInspResultSRPinHole = 435,	// SR Pinhole 불량
        eInspResultPSRPinHole = 436,	// PSR Pinhole 불량
        eInspResultNonPlate = 437,	// 미도금
        eInspResultPlateVoid = 438,	// 도금 VOID (PSR 잔존)
        eInspResultScratch = 439,	// Scratch 불량
        eInspResultContami = 440,	// 오염성 불량
        eInspResultForeignBody = 441,	// 이물질 불량
        eInspResultSRShfit = 442,	// SR Location
        eInspResultPSRShift = 443,	// PSR Shift;
        eInspResultPunchShift = 444,	// Windows Punch Shift
        eInspResultIllumiFault = 445,	// 조명 이상
        eInspResultScratchInLead = 446,	// 리드 Scratch(Min)
        eInspResultNonPlateInLead = 447,	// 리드 미도금(Max)
        eInspResultLeadLift = 448,	// 리드 들뜸(Min)
        eInspResultCoreCrack = 449,	// Core Crack(Max)
        eInspResultPSRInBall = 450,	// Ball PSR잔존(Min)
        eInspResultNonPlateInBall = 451,	// Ball 미도금(Max)
        eInspResultPunchBurr = 452,	// Punch Burr(Min)
        eInspResultShapeInBall = 453,	// Ball 형상 이상
        eInspResultSmallBall = 454,	// Ball 크기이상(작음)
        eInspResultLargeBall = 455,	// Ball 크기이상(큼)
        eInspResultDamBarLength = 456,	// Dam Bar 길이 불량
        eInspResultVentHole = 457,	// Vent-Hole 불량
        eInspResultViaHole = 458,	// Via-Hole 불량
        eInspResultTape = 459,	// Tape 불량
        eInspResultDownset = 460,	// Downset 불량
        eInspResultLeadWidth = 461,	// 리드폭 불량
        eInspResultLeadSpace = 462,	// 공간폭 불량
        eInspResultPlateFlash = 463,	// 도금 Flash
        eInspResultShape = 464,  // 형상 이상 불량
        eInspResultLocationShape = 465,  // 형상 위치 불량
        eInspResultLargeSize = 466,  // 형상 확대 불량
        eInspResultSmallSize = 467,  // 형상 축소 불량
        eInspResultGrooveNone = 468,	// 전체 Groove 미성형
        eInspResultGroovePartial = 469,	// 부분 Groove 미성형
        eInspResultGrooveMB = 470,	// 부분 Groove MB
        eInspResultGrooveProtrusion = 471,	// 부분 Groove 돌출
        eInspResultHalfEtchingShape = 472,	// Half Etching 외형
        eInspResultHalfEtchingIntensity = 473,	// Half Etching 색상
        eInspResultLeadGap = 474,
        eInspResultOther = 999,

        // Error
        eInspResultTrainError = 901,
        eInspResultBufferError = 902,
        eInspResultInputParamError = 903
    }

    /// <summary>   Define break type.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-09-23. </remarks>
    public static class DefineBreakType
    {
        public const int BREAK_TYPE_CONTINUE = 0;
        public const int BREAK_TYPE_UNIT = 1;
        public const int BREAK_TYPE_STRIP = 2;
    }
}
