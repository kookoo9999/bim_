﻿/*********************************************************************************
 * Copyright(c) 2011,2012,2013 by Samsung Techwin.
 * 
 * This software is copyrighted by, and is the sole property of Samsung Techwin.
 * All rigths, title, ownership, or other interests in the software remain the
 * property of Samsung Techwin. This software may only be used in accordance with
 * the corresponding license agreement. Any unauthorized use, duplication, 
 * transmission, distribution, or disclosure of this software is expressly 
 * forbidden.
 *
 * This Copyright notice may not be removed or modified without prior written
 * consent of Samsung Techwin.Samsung Techwin reserves the right to modify this 
 * software without notice.
 *
 * Samsung Techwin.
 * KOREA 
 * http://www.samsungtechwin.co.kr
 *********************************************************************************/
/**
 * @file  InspectionBase.cs
 * @brief 
 *  InspectionBase class.
 * 
 * @author : Minseok Hwang <h.min-suck@samsung.com>
 * @date : 2011.09.23
 * @version : 1.0
 * 
 * <b> Revision Histroy </b>
 * - 2011.09.23 First creation.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Xml.Serialization;
using System.Windows.Controls;

namespace Common.Drawing.InspectionInformation
{
    /// <summary>   Inspection algorithm.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-09. </remarks>
    public abstract class InspectionAlgorithm
    {
        [XmlIgnore]
        protected string Code;

        // XML Serializer
        public InspectionAlgorithm()
        {

        }

        public abstract InspectionAlgorithm Clone();

        public abstract void LoadProperty(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID, string strInspectCode);

        public abstract int SaveProperty(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID, string strInspectCode);
    }

    /// <summary>   Inspection type.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-09. </remarks>
    public class InspectionType
    {
        #region Properties.
        [XmlElement(ElementName = "Code")]
        public string Code // 검사 코드
        {
            get
            {
                return m_strCode;
            }
            set
            {
                m_strCode = value;
            }
        }

        [XmlElement(ElementName = "Name")]
        public string Name // 검사 이름
        {
            get
            {
                return m_strName;
            }
            set
            {
                m_strName = value;
            }
        }

        [XmlElement(ElementName = "Priority")]
        public eInspectPriority Priority; // 검사 우선순위
        [XmlElement(ElementName = "InspectionType")]
        public eVisInspectType InspectType; // 검사 항목
        [XmlElement(ElementName = "InspectionAlgorithm")]
        public eVisInspectAlgo InspectAlgorithm; // 검사 알고리즘

        [XmlElement(ElementName = "ResultType")]
        public int ResultType; // 대표 불량 리포트 항목
        [XmlElement(ElementName = "ResultType2")]
        public int ResultType1; // 불량 리포트 항목 1
        [XmlElement(ElementName = "ResultType3")]
        public int ResultType2; // 불량 리포트 항목 2

        [XmlElement(ElementName="BreakType")]
        public int BreakType;
        #endregion

        #region Constructors.
        /// <summary>   Initializes a new instance of the InspectionType class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-09. </remarks>
        public InspectionType()
        {
            if (SettingControl == null)
            {
                SettingControl = GetInspectionTypeSettingDialog(InspectType);
            }
        }

        /// <summary>   Initializes a new instance of the InspectionType class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-09. </remarks>
        private InspectionType(string strCode, string strName, eInspectPriority priority, eVisInspectType inspectType, eVisInspectAlgo inspectAlgorithm, int breakType, UserControl settingControl, int resultType = -1, int resultType1 = -1, int resultType2 = -1)
        {
            m_strCode = strCode;
            m_strName = strName;

            Priority = priority;

            InspectType = inspectType;
            InspectAlgorithm = inspectAlgorithm;

            SettingControl = settingControl;

            ResultType = resultType;
            ResultType1 = resultType1;
            ResultType2 = resultType2;

            BreakType = breakType;
        }
        #endregion

        #region Private member variables.
        /// <summary> The string code </summary>
        private string m_strCode;

        /// <summary> Name of the string </summary>
        private string m_strName;
        
        /// <summary> The uc setting control </summary>
        private UserControl m_ucSettingControl;
        #endregion

        #region Set Inspection types.
        /// <summary> List of inspection types </summary>
        private static List<InspectionType> m_inspectionTypeList = new List<InspectionType>();

        /// <summary>   Gets the inspection type list. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-09. </remarks>
        /// <returns>   The inspection type list. </returns>
        public static List<InspectionType> GetInspectionTypeList()
        {
            return m_inspectionTypeList;
        }

        // Strip Align에 대한 검사 설정 목록.
        public static List<InspectionType> GetStripAlignInspectionTypeList()
        {
            List<InspectionType> stripInspectionTypeList = new List<InspectionType>();

            foreach (InspectionType inspectionElement in m_inspectionTypeList)
            {
                if (inspectionElement.InspectType == eVisInspectType.eInspTypeGlobalAlign)
                {
                    stripInspectionTypeList.Add(inspectionElement);
                    break;
                }
            }

            return stripInspectionTypeList;
        }

        // Unit Align에 대한 검사 설정 목록.
        public static List<InspectionType> GetUnitAlignInspectionTypeList()
        {
            List<InspectionType> unitInspectionTypeList = new List<InspectionType>();

            foreach (InspectionType inspectionElement in m_inspectionTypeList)
            {
                if (inspectionElement.InspectType == eVisInspectType.eInspTypeUnitAlign)
                {
                    unitInspectionTypeList.Add(inspectionElement);
                }
                if (inspectionElement.InspectType == eVisInspectType.eInspTypeExceptionalMask)
                {
                    unitInspectionTypeList.Add(inspectionElement);
                }
            }

            return unitInspectionTypeList;
        }

        // 일반 검사 영역에 대한 검사 설정 목록.
        public static List<InspectionType> GetDefaultInspectionTypeList()
        {
            List<InspectionType> defaultInspectionTypeList = new List<InspectionType>();

            foreach (InspectionType inspectionElement in m_inspectionTypeList)
            {
                if (inspectionElement.InspectType != eVisInspectType.eInspTypeGlobalAlign)
                {
                    defaultInspectionTypeList.Add(inspectionElement);
                }
            }

            return defaultInspectionTypeList;
        }

        [XmlIgnore]
        public UserControl SettingControl
        {
            get
            {
                if (m_ucSettingControl == null)
                {
                    m_ucSettingControl = InspectionType.GetInspectionTypeSettingDialog(this.InspectType);
                }
                return m_ucSettingControl;
            }
            set
            {
                m_ucSettingControl = value;
            }
        }

        // Name에 의한 InspectionType 조회.
        public static InspectionType GetInspectionType(string aszName)
        {
            foreach (InspectionType inspectionTypeElement in m_inspectionTypeList)
            {
                if (inspectionTypeElement.Name == aszName)
                {
                    return inspectionTypeElement;
                }
            }

            return null;
        }

        // Enum에 의한 InspectionType 조회.
        public static InspectionType GetInspectionType(eVisInspectType inspectType)
        {
            foreach (InspectionType inspectionTypeElement in m_inspectionTypeList)
            {
                if (inspectionTypeElement.InspectType == inspectType)
                {
                    return inspectionTypeElement;
                }
            }

            return null;
        }

        /// <summary>   Gets an inspection type setting dialog. </summary>
        /// <remarks>   Minseok. Hwang, 2011-11-21. </remarks>
        public static UserControl GetInspectionTypeSettingDialog(eVisInspectType inspectType)
        {
            foreach (InspectionType inspectionTypeElement in m_inspectionTypeList)
            {
                if (inspectionTypeElement.InspectType == inspectType)
                {
                    return inspectionTypeElement.SettingControl;
                }
            }

            return null;
        }

        /// <summary>   Initializes static members of the InspectionType class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-09. </remarks>
        static InspectionType()
        {
            #region Strip Align Item
            InspectionType stripAlignType = new InspectionType(
                "0101",
                "Strip Align",
                eInspectPriority.eInspPriorityGlobalAlign, // priority
                eVisInspectType.eInspTypeGlobalAlign, // inspect type
                eVisInspectAlgo.eInspAlgoFeatureAlign, // inspect algorithm type
                DefineBreakType.BREAK_TYPE_STRIP, // inspect break type
                new InspectionTypeUI.FiducialAlign(), // setting control
                (int)eVisInspectResultType.eInspResultStripAlign // inspect result type
                );

            m_inspectionTypeList.Add(stripAlignType);
            #endregion

            #region Unit Align Item
            InspectionType unitAlignType = new InspectionType(
                "0401",
                "Unit Align",
                eInspectPriority.eInspPriorityUnitAlign, // priority
                eVisInspectType.eInspTypeUnitAlign, // inspect type
                eVisInspectAlgo.eInspAlgoFeatureAlign, // inspect algorithm type
                DefineBreakType.BREAK_TYPE_UNIT, // inspect break type
                new InspectionTypeUI.FiducialAlign(), // setting control
                (int)eVisInspectResultType.eInspResultUnitAlign // inspect result type
                );

            m_inspectionTypeList.Add(unitAlignType);
            #endregion

            #region Lead Shape With Center Line Item
            InspectionType leadShapeType = new InspectionType(
                "0415",
                "리드 형상 검사",
                eInspectPriority.eInspPriorityUnitNormal, // priority
                eVisInspectType.eInspTypeLeadShapeWithCL, // inspect type
                eVisInspectAlgo.eInspAlgoLeadWithCenterLine, // inspect algorithm type
                DefineBreakType.BREAK_TYPE_CONTINUE, // inspect break type
                new InspectionTypeUI.LeadShapeWithCenterLine(), // setting control
                (int)eVisInspectResultType.eInspResultLeadDeviation, // inspect result type // Result 항목이 여러개인 경우 리포팅하지 않음.
                (int)eVisInspectResultType.eInspResultNoLead, // inspect result type 1 // Result 항목이 여러개인 경우 리포팅하지 않음.
                (int)eVisInspectResultType.eInspResultIsland // inspect result type 2 // Result 항목이 여러개인 경우 리포팅하지 않음.
                );

            m_inspectionTypeList.Add(leadShapeType);
            #endregion

            #region Groove Item
            InspectionType grooveType = new InspectionType(
                "0416",
                "Groove 검사",
                eInspectPriority.eInspPriorityUnitNormal, // priority
                eVisInspectType.eInspTypeGroove, // inspect type
                eVisInspectAlgo.eInspAlgoGrooveWithCenterLine, // inspect algorithm type
                DefineBreakType.BREAK_TYPE_CONTINUE, // inspect break type
                new InspectionTypeUI.Groove(), // setting control
                (int)eVisInspectResultType.eInspResultGrooveNone, // inspect result type // Not Defined !!!!!!
                (int)eVisInspectResultType.eInspResultGrooveNone, // inspect result type // Not Defined !!!!!!
                (int)eVisInspectResultType.eInspResultGroovePartial // inspect result type 1 // Not Defined !!!!!!
                );

            m_inspectionTypeList.Add(grooveType);
            #endregion

            #region Shape Half Etching
            InspectionType shapeHalfEtchingType = new InspectionType(
                "0417",
                "형상 Half Etching 검사",
                eInspectPriority.eInspPriorityUnitNormal, // priority
                eVisInspectType.eInspTypeShapeHalfEtching, // inspect type
                eVisInspectAlgo.eInspAlgoShapeHalfEtching, // inspect algorithm type
                DefineBreakType.BREAK_TYPE_CONTINUE, // inspect break type
                new InspectionTypeUI.FigureShape() // setting control
                , (int)eVisInspectResultType.eInspResultHalfEtchingShape
                , (int)eVisInspectResultType.eInspResultHalfEtchingShape
                , (int)eVisInspectResultType.eInspResultHalfEtchingShape
                );

            m_inspectionTypeList.Add(shapeHalfEtchingType);
            #endregion

            #region Surface Half Etching Item
            InspectionType surfaceHalfEtchingType = new InspectionType(
                "0418",
                "표면 Half Etching 검사",
                eInspectPriority.eInspPriorityUnitNormal, // priority
                eVisInspectType.eInspTypeSurfaceHalfEtching, // inspect type
                eVisInspectAlgo.eInspAlgoStateAlignedMask, // inspect algorithm type
                DefineBreakType.BREAK_TYPE_CONTINUE, // inspect break type
                new InspectionTypeUI.State_AlignedMask() // setting control
                , (int)eVisInspectResultType.eInspResultHalfEtchingIntensity
                , (int)eVisInspectResultType.eInspResultHalfEtchingIntensity
                , (int)eVisInspectResultType.eInspResultHalfEtchingIntensity
                );

            m_inspectionTypeList.Add(surfaceHalfEtchingType);
            #endregion

            #region Down Set Item
            InspectionType downSetType = new InspectionType(
                "0419",
                "D/S 검사",
                eInspectPriority.eInspPriorityUnitNormal, // priority
                eVisInspectType.eInspTypeDownSet, // inspect type
                eVisInspectAlgo.eInspAlgoStateIntensity, // inspect algorithm type
                DefineBreakType.BREAK_TYPE_CONTINUE, // inspect break type
                new InspectionTypeUI.State_Intensity() // setting control
                , (int)eVisInspectResultType.eInspResultDownset, 
                (int)eVisInspectResultType.eInspResultDownset,
                (int)eVisInspectResultType.eInspResultDownset
                );

            m_inspectionTypeList.Add(downSetType);
            #endregion

            #region Tape Item
            InspectionType tapeType = new InspectionType(
                "0420",
                "T/P 검사",
                eInspectPriority.eInspPriorityUnitNormal, // priority
                eVisInspectType.eInspTypeTape, // inspect type
                eVisInspectAlgo.eInspAlgoShapeShift, // inspect algorithm type
                DefineBreakType.BREAK_TYPE_CONTINUE, // inspect break type
                new InspectionTypeUI.ShapeShift() // setting control
                ,(int)eVisInspectResultType.eInspResultTape, // inspect result type // Not Defined !!!!!!
                (int)eVisInspectResultType.eInspResultTape, // inspect result type 1 // Not Defined !!!!!!
                (int)eVisInspectResultType.eInspResultTape // inspect result type 2 // Not Defined !!!!!!
                );

            m_inspectionTypeList.Add(tapeType);
            #endregion

            #region Plate Item
            InspectionType plateType = new InspectionType(
                "0421",
                "도금 검사",
                eInspectPriority.eInspPriorityUnitNormal, // priority
                eVisInspectType.eInspTypePlate, // inspect type
                eVisInspectAlgo.eInspAlgoShapeShift, // inspect algorithm type
                DefineBreakType.BREAK_TYPE_CONTINUE,
                new InspectionTypeUI.ShapeShift(), // setting control
                (int)eVisInspectResultType.eInspResultNonPlate,
                (int)eVisInspectResultType.eInspResultNonPlate,
                (int)eVisInspectResultType.eInspResultPlateVoid // inspect result type 2
                );

            m_inspectionTypeList.Add(plateType);
            #endregion

            #region Surface Item
            InspectionType surfaceType = new InspectionType(
                "0422",
                "표면 검사",
                eInspectPriority.eInspPriorityUnitNormal, // priority
                eVisInspectType.eInspTypeSurface, // inspect type
                eVisInspectAlgo.eInspAlgoStateAlignedMask, // inspect algorithm type
                DefineBreakType.BREAK_TYPE_CONTINUE, // inspect break type
                new InspectionTypeUI.State_AlignedMask() // setting control
                , (int)eVisInspectResultType.eInspResultPlateFlash,
                (int)eVisInspectResultType.eInspResultPlateFlash, 
                (int)eVisInspectResultType.eInspResultPlateFlash
                );

            m_inspectionTypeList.Add(surfaceType);
            #endregion

            #region Space Item
            InspectionType spcaeType = new InspectionType(
                "0423",
                "공간 검사",
                eInspectPriority.eInspPriorityUnitNormal, // priority
                eVisInspectType.eInspTypeSpace, // inspect type
                eVisInspectAlgo.eInspAlgoStateAlignedMask, // inspect algorithm type
                DefineBreakType.BREAK_TYPE_CONTINUE, // inspect break type
                new InspectionTypeUI.State_AlignedMask(),
                (int)eVisInspectResultType.eInspResultLeadSpace, (int)eVisInspectResultType.eInspResultLeadSpace, (int)eVisInspectResultType.eInspResultLeadSpace
                );

            m_inspectionTypeList.Add(spcaeType);
            #endregion
            
            #region Lead Gap
            InspectionType LeadGap = new InspectionType(
                "0435",
                "리드 간격 검사",
                eInspectPriority.eInspPriorityUnitNormal, // priority
                eVisInspectType.eInspTypeLeadGap, // inspect type
                eVisInspectAlgo.eInspAlgoLeadGap, // inspect algorithm type
                DefineBreakType.BREAK_TYPE_CONTINUE, // inspect break type
                new InspectionTypeUI.Lead_Gap(),
                (int)eVisInspectResultType.eInspResultLeadGap, (int)eVisInspectResultType.eInspResultLeadGap, (int)eVisInspectResultType.eInspResultLeadGap
                );

            m_inspectionTypeList.Add(LeadGap);
            #endregion

            #region Exceptional Mask
            InspectionType ExceptionalMask = new InspectionType(
                "0999",
                "검사 제외",
                eInspectPriority.eInspPriorityUnitNormal, // priority
                eVisInspectType.eInspTypeExceptionalMask, // inspect type
                eVisInspectAlgo.eInspAlgoExceptionalMask, // inspect algorithm type
                DefineBreakType.BREAK_TYPE_CONTINUE, // inspect break type
                new InspectionTypeUI.ExceptionalMask(),
                (int)eVisInspectResultType.eInspectGood, (int)eVisInspectResultType.eInspectGood, (int)eVisInspectResultType.eInspectGood
                );

            m_inspectionTypeList.Add(ExceptionalMask);
            #endregion
        }
        #endregion
    }
}
