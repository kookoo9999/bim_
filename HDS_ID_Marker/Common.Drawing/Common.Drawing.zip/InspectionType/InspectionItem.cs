﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.Windows.Controls;
using Common.Drawing.InspectionTypeUI;

namespace Common.Drawing.InspectionInformation
{
    /// <summary>   Inspection item.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-09. </remarks>
    [XmlInclude(typeof(ExceptionalMaskProperty))]
    [XmlInclude(typeof(FiducialAlignProperty))]
    [XmlInclude(typeof(FigureShapeProperty))]
    [XmlInclude(typeof(GrooveProperty))]
    [XmlInclude(typeof(LeadGapProperty))]
    [XmlInclude(typeof(LeadShapeWithCenterLineProperty))]
    [XmlInclude(typeof(ShapeShiftProperty))]
    [XmlInclude(typeof(StateAlignedMaskProperty))]
    [XmlInclude(typeof(StateIntensityProperty))]
    public class InspectionItem : NotifyPropertyChanged
    {
        /// <summary>   Gets the identifier. </summary>
        /// <value> The identifier. </value>
        [XmlElement(ElementName = "SequenceID")]
        public int ID
        {
            get
            {
                return m_nID;
            }
            set
            {
                m_nID = value;
                Notify("ID");
            }
        }
        private int m_nID = 0;

        [XmlElement(ElementName = "IsExceptionSkip")]
        public int IsExceptionSkip
        {
            get
            {
                return m_IsExceptionSkip;
            }
            set
            {
                m_IsExceptionSkip = value;
                Notify("IsExceptionSkip");
            }
        }
        private int m_IsExceptionSkip = 0;

        /// <summary> Type of the inspection </summary>
        [XmlElement(ElementName = "InspectionType")]
        public InspectionType InspectionType
        {
            get;
            set;
        }

        /// <summary> The inspection algorithm </summary>
        [XmlElement(ElementName = "InspectionProperty")]
        public InspectionAlgorithm InspectionAlgorithm
        {
            get;
            set;
        }

        #region Constructors.
        /// <summary>   Initializes a new instance of the InspectionItem class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-14. </remarks>
        public InspectionItem()
        {
        }

        /// <summary>   Initializes a new instance of the InspectionItem class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-14. </remarks>
        /// <param name="inspectionType">       Type of the inspection. </param>
        /// <param name="inspectionAlgorithm">  The inspection algorithm. </param>
        public InspectionItem(InspectionType inspectionType, InspectionAlgorithm inspectionAlgorithm)
        {
            this.InspectionType = inspectionType;
            this.InspectionAlgorithm = inspectionAlgorithm;
        }

        /// <summary>   Initializes a new instance of the InspectionItem class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        /// <param name="inspectionType">       Type of the inspection. </param>
        /// <param name="inspectionAlgorithm">  The inspection algorithm. </param>
        public InspectionItem(InspectionType inspectionType, InspectionAlgorithm inspectionAlgorithm, int id)
        {
            this.m_nID = id;
            this.InspectionType = inspectionType;
            this.InspectionAlgorithm = inspectionAlgorithm;
        }

        /// <summary>   Saves an inspect item. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        /// <returns>   Query result. </returns>
        public int SaveInspectItem(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID)
        {
            return this.InspectionAlgorithm.SaveProperty(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, this.InspectionType.Code);
        }
        #endregion
    }
}
