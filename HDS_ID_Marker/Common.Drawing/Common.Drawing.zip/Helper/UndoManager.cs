// http://www.codeproject.com/cs/design/commandpatterndemo.asp
// The Command Pattern and MVC Architecture
// By David Veeneman.

using System;
using System.Collections.Generic;
using System.Text;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>   Manager for undoes. It has history list of commands. </summary>
    class UndoManager
    {
        #region member variables.
        /// <summary> The drawing canvas </summary>
        private DrawingCanvas drawingCanvas;

        /// <summary> List of command histories </summary>
        private List<CommandBase> historyList;

        /// <summary> The next undo position. </summary>
        int nextUndo;

        /// <summary> State changed Delegate. </summary>
        public event EventHandler StateChanged;
        #endregion

        /// <summary>   Initializes a new instance of the UndoManager class. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public UndoManager(DrawingCanvas drawingCanvas)
        {
            this.drawingCanvas = drawingCanvas; // save pointer of drawingCanvas.
            ClearHistory();
        }

        /// <summary>   Gets a value indicating whether we can undo. </summary>
        /// <value> true if we can undo, false if not. </value>
        public bool CanUndo
        {
            get
            {
                if (nextUndo < 0 || nextUndo > historyList.Count - 1)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        /// <summary>   Gets a value indicating whether we can redo. </summary>
        /// <value> true if we can redo, false if not. </value>
        public bool CanRedo
        {
            get
            {
                if (nextUndo == historyList.Count - 1)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        /// <summary>   Gets a value indicating whether this object is dirty. </summary>
        /// <value> true if this object is dirty, false if not. </value>
        public bool IsDirty
        {
            get
            {
                // IsDirty == CanUndo
                return CanUndo;
            }
        }

        /// <summary>   Gets the current command. </summary>
        /// <value> The current command. </value>
        public CommandBase Command
        {
            get
            {
                return historyList[nextUndo + 1];
            }
        }

        /// <summary>   Gets the history count. </summary>
        /// <returns>   The history count. </returns>
        public int GetHistoryCount()
        {
            return historyList.Count;
        }

        /// <summary>   Clears the history. </summary>
        public void ClearHistory()
        {
            historyList = new List<CommandBase>();

            nextUndo = -1;            
            RaiseStateChangedEvent();
        }

        /// <summary>   Adds a command to history.  </summary>
        /// <param name="command">  The command. </param>
        public void AddCommandToHistory(CommandBase command)
        {
            TrimHistoryList();

            historyList.Add(command);

            nextUndo++;
            RaiseStateChangedEvent();
        }

        /// <summary>   Undoes this object. </summary>
        public void Undo()
        {
            CommandBase command = historyList[nextUndo];

            // Undo.
            command.Undo(drawingCanvas);

            nextUndo--;
            RaiseStateChangedEvent();
        }

        /// <summary>   Redoes this object. </summary>
        public void Redo()
        {
            int itemToRedo = nextUndo + 1;
            CommandBase command = historyList[itemToRedo];

            // Redo.
            command.Redo(drawingCanvas);

            nextUndo++;
            RaiseStateChangedEvent();
        }

        /// <summary>   Trim history list. </summary>
        private void TrimHistoryList()
        {
            if (historyList.Count == 0 || nextUndo == historyList.Count - 1)
            {
                return;
            }

            // Delete un-used part of historyList. (nextUndo to end of historyList)
            for (int i = historyList.Count - 1; i > nextUndo; i--)
            {
                historyList.RemoveAt(i);
            }
        }

        /// <summary>   Raises the state changed event. </summary>
        private void RaiseStateChangedEvent()
        {
            if (StateChanged != null)
            {
                // State changed !
                StateChanged(this, EventArgs.Empty);
            }
        }
    }
}
