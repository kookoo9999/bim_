// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using Common.Drawing.InspectionInformation;

// Modify & Comment by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>   Ellipse object properties. </summary>
    public class PropertiesGraphicsEllipse : PropertiesGraphicsBase
    {
        #region Member variables.
        /// <summary> The left </summary>
        private double left;

        /// <summary> The top </summary>
        private double top;

        /// <summary> The right </summary>
        private double right;

        /// <summary> The bottom </summary>
        private double bottom;
        #endregion

        // For XmlSerializer
        public PropertiesGraphicsEllipse()
        {
            // XML���� ������ ���� �⺻ �����ڰ� �ʿ��ϴ�.
        }

        /// <summary>   Initializes a new instance of the PropertiesGraphicsEllipse class. </summary>
        /// <exception cref="ArgumentNullException">    Thrown when one or more required arguments are
        ///                                             null. </exception>
        /// <param name="ellipse">  The ellipse. </param>
        public PropertiesGraphicsEllipse(GraphicsEllipse ellipse)
        {
            if (ellipse == null)
            {
                throw new ArgumentNullException("ellipse");
            }

            this.left = ellipse.Left;
            this.top = ellipse.Top;
            this.right = ellipse.Right;
            this.bottom = ellipse.Bottom;
            this.lineWidth = ellipse.LineWidth;
            this.regionType = ellipse.RegionType;
            this.objectColor = ellipse.ObjectColor;
            this.textColor = ellipse.TextColor;
            this.actualScale = ellipse.ActualScale;
            this.ID = ellipse.Id;
            this.selected = ellipse.IsSelected;
            this.caption = ellipse.Caption;

            if (ellipse.InspectionList != null)
            {
                inspectionItems = new InspectionItem[ellipse.InspectionList.Count];
                int nIndex = 0;
                foreach (InspectionItem inspectionElement in ellipse.InspectionList)
                {
                    inspectionItems[nIndex++] = inspectionElement;
                }
            }
        }

        /// <summary>   Creates the graphics. </summary>
        /// <returns>   Ellipse. </returns>
        public override GraphicsBase CreateGraphics()
        {
            base.SetGraphicsColor();
            lineWidth = 2; // Default thickness.

            List<InspectionItem> inspectionList = new List<InspectionItem>();
            foreach (InspectionItem inspectionElement in inspectionItems)
            {
                inspectionList.Add(InspectionItemHelper.CopyInspectionItem(inspectionElement));
            }

            actualScale = (actualScale > 0) ? actualScale : 1.0;
            GraphicsBase b = new GraphicsEllipse(left, top, right, bottom, lineWidth, regionType, objectColor, textColor, actualScale, caption, inspectionList);

            if (this.ID != 0)
            {
                b.Id = this.ID;
                b.IsSelected = this.selected;
            }

            return b;
        }

        #region Properties
        /// <summary>   Left bounding rectangle side, X. </summary>
        /// <value> The left. </value>
        public double Left
        {
            get
            {
                return left;
            }
            set
            {
                left = value;
            }
        }

        /// <summary>   Top bounding rectangle side, Y. </summary>
        /// <value> The top. </value>
        public double Top
        {
            get
            {
                return top;
            }
            set
            {
                top = value;
            }
        }

        /// <summary>   Right bounding rectangle side, X. </summary>
        /// <value> The right. </value>
        public double Right
        {
            get
            {
                return right;
            }
            set
            {
                right = value;
            }
        }

        /// <summary>   Bottom bounding rectangle side, Y. </summary>
        /// <value> The bottom. </value>
        public double Bottom
        {
            get
            {
                return bottom;
            }
            set
            {
                bottom = value;
            }
        }

        /// <summary>   Gets or sets the type of the region. </summary>
        /// <value> The type of the region. </value>
        public GraphicsRegionType RegionType
        {
            get
            {
                return regionType;
            }
            set
            {
                regionType = value;
            }
        }

        /// <summary>   Gets or sets the caption. </summary>
        /// <value> The caption. </value>
        public string Caption
        {
            get
            {
                return caption;
            }
            set
            {
                caption = value;
            }
        }

        /// <summary>   Gets or sets a list of inspections. </summary>
        /// <value> A List of inspections. </value>
        public InspectionItem[] InspectionList
        {
            get
            {
                return inspectionItems;
            }
            set
            {
                inspectionItems = value;
            }
        }
        #endregion Properties
    }
}
