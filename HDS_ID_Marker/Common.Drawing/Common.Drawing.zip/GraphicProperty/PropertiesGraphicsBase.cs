// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Windows;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using Common.Drawing.InspectionInformation;
using System.Windows.Media;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>
    /// Base class for all serialization helper classes.
    /// PropertiesGraphics* class hierarchy contains base class
    /// and class for every non-abstract Graphics* class.
    /// Since Graphics* classes are derived from DrawingVisual, I
    /// cannot serialize them directly.
    /// 
    /// Every PropertiesGraphics* class knows to create instance
    /// of Graphics* class - see CreateGraphics function.
    /// This function is called during deserialization, when 
    /// PropertiesGraphics* class is loaded from XML file.
    /// 
    /// On the other hand, every non-abstract Graphics* class
    /// can create PropertiesGraphics* class: see 
    /// GraphicsBase.CreateSerializedObject function.
    /// It is called during serialization, when every Graphics*
    /// object must create PropertiesGraphics*.
    /// 
    /// 
    /// PropertiesGraphics* classes are also used in UndoManager
    /// as light-weight clones of Graphics* classes.
    /// These classes are also used in DrawingCanvas.GetListOfGraphicObjects
    /// function for client which needs to get all data from DrawingCanvas
    /// directly.
    /// 
    /// </summary>
    public abstract class PropertiesGraphicsBase
    {
        /// <summary> The identifier </summary>
        [XmlIgnore]
        internal int ID;

        /// <summary> true to selected </summary>
        [XmlIgnore]
        internal bool selected;

        /// <summary> The actual scale </summary>
        [XmlIgnore]
        internal double actualScale;

        /// <summary> Type of the region </summary>
        [XmlIgnore]
        internal GraphicsRegionType regionType;

        /// <summary> The object color </summary>
        [XmlIgnore]
        internal Color objectColor;

        /// <summary> The text color </summary>
        [XmlIgnore]
        internal Color textColor;

        /// <summary> Width of the line </summary>
        [XmlIgnore]
        internal double lineWidth;

        /// <summary> The caption </summary>
        [XmlIgnore]
        internal string caption;

        /// <summary> List of inspections </summary>
        [XmlIgnore]
        internal InspectionItem[] inspectionItems;

        /// <summary>   Gets or sets the local aligns. </summary>
        /// <value> The local aligns. </value>
        [XmlArrayItem(typeof(Point), ElementName = "LocalAlign")]
        public Point[] LocalAligns
        {
            get;
            set;
        }
        
        public abstract GraphicsBase CreateGraphics();

        /// <summary>   Sets the graphics color. </summary>
        /// <remarks>   Minseok. Hwang, 2011-11-21. </remarks>
        public void SetGraphicsColor()
        {
            switch (regionType)
            {
                case GraphicsRegionType.Inspection:
                case GraphicsRegionType.UnitRegion:
                case GraphicsRegionType.OuterRegion:
                    objectColor = GraphicsColors.Green;
                    textColor = GraphicsColors.Green;
                    break;
                case GraphicsRegionType.StripAlign:
                case GraphicsRegionType.UnitAlign:
                case GraphicsRegionType.LocalAlign:
                    objectColor = GraphicsColors.Red;
                    textColor = GraphicsColors.Red;
                    break;
                case GraphicsRegionType.Except:
                    objectColor = GraphicsColors.Blue;
                    textColor = GraphicsColors.Blue;
                    break;
                default:
                    objectColor = Colors.Transparent;
                    textColor = Colors.Transparent;
                    break;
            }
        }
    }
}
