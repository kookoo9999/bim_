// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using System.Collections.Generic;
using Common.Drawing.InspectionInformation;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>
    /// Line object properties
    /// </summary>
    public class PropertiesGraphicsLine : PropertiesGraphicsBase
    {
        #region Private member variables.
        /// <summary> The start </summary>
        private Point start;

        /// <summary> The end </summary>
        private Point end;
        #endregion

        // For XmlSerializer
        public PropertiesGraphicsLine()
        {
            // XML���� ������ ���� �⺻ �����ڰ� �ʿ��ϴ�.
        }

        public PropertiesGraphicsLine(GraphicsLine line)
        {
            if (line == null)
            {
                throw new ArgumentNullException("line");
            }

            this.start = line.Start;
            this.end = line.End;
            this.lineWidth = line.LineWidth;
            this.regionType = line.RegionType;
            this.objectColor = line.ObjectColor;
            this.textColor = line.TextColor;
            this.actualScale = line.ActualScale;
            this.ID = line.Id;
            this.selected = line.IsSelected;
            this.caption = line.Caption;

            if (line.InspectionList != null)
            {
                inspectionItems = new InspectionItem[line.InspectionList.Count];
                int nIndex = 0;
                foreach (InspectionItem inspectionElement in line.InspectionList)
                {
                    inspectionItems[nIndex++] = inspectionElement;
                }
            }
        }

        public override GraphicsBase CreateGraphics()
        {
            base.SetGraphicsColor();
            lineWidth = 2; // Default thickness.

            List<InspectionItem> inspectionList = new List<InspectionItem>();
            foreach (InspectionItem inspectionElement in inspectionItems)
            {
                inspectionList.Add(InspectionItemHelper.CopyInspectionItem(inspectionElement));
            }

            actualScale = (actualScale > 0) ? actualScale : 1.0;
            GraphicsBase b = new GraphicsLine(start, end, lineWidth, regionType, objectColor, textColor, actualScale, caption, inspectionList);

            if (this.ID != 0)
            {
                b.Id = this.ID;
                b.IsSelected = this.selected;
            }

            return b;
        }

        #region Properties
        /// <summary>   Gets or sets the start point of line. </summary>
        /// <value> The start point. </value>
        public Point Start
        {
            get { return start; }
            set { start = value; }
        }

        /// <summary>   Gets or sets the end point of line. </summary>
        /// <value> The end point. </value>
        public Point End
        {
            get { return end; }
            set { end = value; }
        }

        /// <summary>   Gets or sets the type of the region. </summary>
        /// <value> The type of the region. </value>
        public GraphicsRegionType RegionType
        {
            get
            {
                return regionType;
            }
            set
            {
                regionType = value;
            }
        }

        /// <summary>   Gets or sets the caption. </summary>
        /// <value> The caption. </value>
        public string Caption
        {
            get
            {
                return caption;
            }
            set
            {
                caption = value;
            }
        }

        /// <summary>   Gets or sets a list of inspections. </summary>
        /// <value> A List of inspections. </value>
        public InspectionItem[] InspectionList
        {
            get
            {
                return inspectionItems;
            }
            set
            {
                inspectionItems = value;
            }
        }
        #endregion Properties
    }
}
