// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using Common.Drawing.InspectionInformation;
using System.Collections.Generic;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>
    /// Text object properties
    /// </summary>
    public class PropertiesGraphicsText : PropertiesGraphicsBase
    {
        #region Member variables.
        /// <summary> The text </summary>
        private string text;

        /// <summary> The left </summary>
        private double left;

        /// <summary> The top </summary>
        private double top;

        /// <summary> The right </summary>
        private double right;

        /// <summary> The bottom </summary>
        private double bottom;
        
        /// <summary> Size of the text font </summary>
        private double textFontSize;

        /// <summary> Name of the text font family </summary>
        private string textFontFamilyName;

        /// <summary> The text font style </summary>
        private string textFontStyle;

        /// <summary> The text font weight </summary>
        private string textFontWeight;

        /// <summary> The text font stretch </summary>
        private string textFontStretch;
        #endregion

        // For XmlSerializer
        public PropertiesGraphicsText()
        {
            // XML���� ������ ���� �⺻ �����ڰ� �ʿ��ϴ�.
        }

        public PropertiesGraphicsText(GraphicsText graphicsText)
        {
            if (graphicsText == null)
            {
                throw new ArgumentNullException("graphicsText");
            }

            this.text = graphicsText.Text;
            this.left = graphicsText.Left;
            this.top = graphicsText.Top;
            this.right = graphicsText.Right;
            this.bottom = graphicsText.Bottom;
            this.regionType = graphicsText.RegionType;
            this.objectColor = graphicsText.ObjectColor;
            this.textColor = graphicsText.TextColor;
            this.textFontSize = graphicsText.TextFontSize;
            this.textFontFamilyName = graphicsText.TextFontFamilyName;
            this.textFontStyle = FontConversions.FontStyleToString(graphicsText.TextFontStyle);
            this.textFontWeight = FontConversions.FontWeightToString(graphicsText.TextFontWeight);
            this.textFontStretch = FontConversions.FontStretchToString(graphicsText.TextFontStretch);
            this.actualScale = graphicsText.ActualScale;
            this.ID = graphicsText.Id;
            this.selected = graphicsText.IsSelected;
            this.caption = graphicsText.Caption;

            if (graphicsText.InspectionList != null)
            {
                inspectionItems = new InspectionItem[graphicsText.InspectionList.Count];
                int nIndex = 0;
                foreach (InspectionItem inspectionElement in graphicsText.InspectionList)
                {
                    inspectionItems[nIndex++] = inspectionElement;
                }
            }
        }

        public override GraphicsBase CreateGraphics()
        {
            base.SetGraphicsColor();

            List<InspectionItem> inspectionList = new List<InspectionItem>();
            foreach (InspectionItem inspectionElement in this.inspectionItems)
            {
                inspectionList.Add(InspectionItemHelper.CopyInspectionItem(inspectionElement));
            }

            actualScale = (actualScale > 0) ? actualScale : 1.0;
            GraphicsBase b = new GraphicsText(
                text,
                left,
                top,
                right,
                bottom,
                regionType,
                objectColor,
                textColor,
                textFontSize,
                textFontFamilyName,
                FontConversions.FontStyleFromString(textFontStyle),
                FontConversions.FontWeightFromString(textFontWeight),
                FontConversions.FontStretchFromString(textFontStretch),
                actualScale,
                caption,
                inspectionList);

            if (this.ID != 0)
            {
                b.Id = this.ID;
                b.IsSelected = this.selected;
            }

            return b;

        }

        #region Properties

        /// <summary>
        /// Left bounding rectangle side, X
        /// </summary>
        public string Text
        {
            get
            {
                return text;
            }
            set
            {
                text = value;
            }
        }

        /// <summary>
        /// Top bounding rectangle side, Y
        /// </summary>
        public double Left
        {
            get
            {
                return left;
            }
            set
            {
                left = value;
            }
        }

        /// <summary>
        /// Right bounding rectangle side, X
        /// </summary>
        public double Top
        {
            get
            {
                return top;
            }
            set
            {
                top = value;
            }
        }

        /// <summary>
        /// Bottom bounding rectangle side, Y
        /// </summary>
        public double Right
        {
            get
            {
                return right;
            }
            set
            {
                right = value;
            }
        }

        public double Bottom
        {
            get
            {
                return bottom;
            }
            set
            {
                bottom = value;
            }
        }

        /// <summary>   Gets or sets the type of the region. </summary>
        /// <value> The type of the region. </value>
        public GraphicsRegionType RegionType
        {
            get
            {
                return regionType;
            }
            set
            {
                regionType = value;
            }
        }

        /// <summary>   Gets or sets the caption. </summary>
        /// <value> The caption. </value>
        public string Caption
        {
            get
            {
                return caption;
            }
            set
            {
                caption = value;
            }
        }

        /// <summary>   Gets or sets a list of inspections. </summary>
        /// <value> A List of inspections. </value>
        public InspectionItem[] InspectionItems
        {
            get
            {
                return inspectionItems;
            }
            set
            {
                inspectionItems = value;
            }
        }

        /// <summary>
        /// Font Size
        /// </summary>
        public double TextFontSize
        {
            get
            {
                return textFontSize;
            }
            set
            {
                textFontSize = value;
            }
        }

        /// <summary>
        /// Font Family Name
        /// </summary>
        public string TextFontFamilyName
        {
            get
            {
                return textFontFamilyName;
            }
            set
            {
                textFontFamilyName = value;
            }
        }

        /// <summary>
        /// Font Style
        /// </summary>
        public string TextFontStyle
        {
            get
            {
                return textFontStyle;
            }
            set
            {
                textFontStyle = value;
            }
        }

        /// <summary>
        /// Font Weight
        /// </summary>
        public string TextFontWeight
        {
            get
            {
                return textFontWeight;
            }
            set
            {
                textFontWeight = value;
            }
        }

        /// <summary>
        /// Font Stretch
        /// </summary>
        public string TextFontStretch
        {
            get
            {
                return textFontStretch;
            }
            set
            {
                textFontStretch = value;
            }
        }
        #endregion Properties
    }
}
