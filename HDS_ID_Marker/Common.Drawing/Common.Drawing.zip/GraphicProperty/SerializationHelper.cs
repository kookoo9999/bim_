// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>
    /// Helper class used for XML serialization. Contains array of SerializedGraphicsBase instances.
    /// </summary>
    [XmlRoot("Teaching Data")]
    public class SerializationHelper
    {
        /// <summary> The graphics </summary>
        private PropertiesGraphicsBase[] graphics;

        /// <summary> Name of the model </summary>
        [XmlElement(ElementName = "ModelName")]
        public string ModelName
        {
            get;
            set;
        }

        /// <summary> Name of the section </summary>
        [XmlElement(ElementName = "SectionName")]
        public string SectionName
        {
            get;
            set;
        }

        /// <summary>   Gets or sets the width of the region. </summary>
        /// <value> The width of the region. </value>
        [XmlElement(ElementName = "RegionWidth")]
        public int RegionWidth
        {
            get;
            set;
        }

        /// <summary>   Gets or sets the height of the region. </summary>
        /// <value> The height of the region. </value>
        [XmlElement(ElementName = "RegionHeight")]
        public int RegionHeight
        {
            get;
            set;
        }

        /// <summary>   Default constructor is XML serialization requirement. </summary>
        public SerializationHelper()
        {
            // XML���� ������ ���� �⺻ �����ڰ� �ʿ��ϴ�.
        }

        /// <summary>
        /// This constructor is used for serialization. VisualCollection contains Graphics* instances.
        /// Every Graphics instance creates SerializedGraphics* instance which is added to graphics array.
        /// </summary>
        /// <exception cref="ArgumentNullException">    Thrown when one or more required arguments are
        ///                                             null. </exception>
        /// <param name="collection">   The collection. </param>
        public SerializationHelper(VisualCollection collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("collection");
            }
            graphics = new PropertiesGraphicsBase[collection.Count];

            int nIndex = 0;
            PropertiesGraphicsBase serializedObject;
            foreach (GraphicsBase g in collection)
            {
                if (g is GraphicsRectangle && ((GraphicsRectangle)g).MotherROI != null)
                {
                    continue;
                }

                serializedObject = g.CreateSerializedObject();
                if (g.LocalAligns != null)
                {
                    serializedObject.LocalAligns = new Point[Definitions.MAX_LOCAL_ALIGN_COUNT];
                    for (int i = 0; i < serializedObject.LocalAligns.Length; i++)
                    {
                        if (g.LocalAligns[i] != null)
                        {
                            serializedObject.LocalAligns[i] = new Point(
                                g.LocalAligns[i].Left + (g.LocalAligns[i].Right - g.LocalAligns[i].Left) / 2.0,
                                g.LocalAligns[i].Top + (g.LocalAligns[i].Bottom - g.LocalAligns[i].Top) / 2.0
                                );
                        }
                        else
                        {
                            serializedObject.LocalAligns[i] = new Point(-1, -1);
                        }
                    }
                }
                graphics[nIndex++] = serializedObject;
            }
        }

        /// <summary>
        /// When class is serialized, graphics array is filled in the constructor and saved to XML file.
        /// When class is deserialized, graphics array is loaded from XML file and then used by called to
        /// create VisualCollection.
        /// </summary>
        /// <value> The graphics. </value>
        [XmlArrayItem(typeof(PropertiesGraphicsEllipse), ElementName = "Ellipse"),
         XmlArrayItem(typeof(PropertiesGraphicsLine), ElementName = "Line"),
         XmlArrayItem(typeof(PropertiesGraphicsPolyLine), ElementName = "PolyLine"),
         XmlArrayItem(typeof(PropertiesGraphicsRectangle), ElementName = "Rectangle"),
         XmlArrayItem(typeof(PropertiesGraphicsText), ElementName = "RectangleText")]
        public PropertiesGraphicsBase[] Graphics
        {
            get { return graphics; }
            set { graphics = value; }
        }
    }
}
