// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using System.Collections.Generic;
using Common.Drawing.InspectionInformation;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>
    /// Polyline object properties
    /// </summary>
    public class PropertiesGraphicsPolyLine : PropertiesGraphicsBase
    {
        /// <summary> The points </summary>
        private Point[] points;
        
        // For XmlSerializer
        public PropertiesGraphicsPolyLine()
        {
            // XML���� ������ ���� �⺻ �����ڰ� �ʿ��ϴ�.
        }

        /// <summary>   Initializes a new instance of the PropertiesGraphicsPolyLine class. </summary>
        /// <exception cref="ArgumentNullException">    Thrown when one or more required arguments are
        ///                                             null. </exception>
        /// <param name="polyLine"> The polygon line. </param>
        public PropertiesGraphicsPolyLine(GraphicsPolyLine polyLine)
        {
            if (polyLine == null)
            {
                throw new ArgumentNullException("polyLine");
            }
            this.points = polyLine.GetPoints();
            this.lineWidth = polyLine.LineWidth;
            this.regionType = polyLine.RegionType;
            this.objectColor = polyLine.ObjectColor;
            this.textColor = polyLine.TextColor;
            this.actualScale = polyLine.ActualScale;
            this.ID = polyLine.Id;
            this.selected = polyLine.IsSelected;
            this.caption = polyLine.Caption;

            if (polyLine.InspectionList != null)
            {
                inspectionItems = new InspectionItem[polyLine.InspectionList.Count];
                int nIndex = 0;
                foreach (InspectionItem inspectionElement in polyLine.InspectionList)
                {
                    inspectionItems[nIndex++] = inspectionElement;
                }
            }
        }

        public override GraphicsBase CreateGraphics()
        {
            base.SetGraphicsColor();
            lineWidth = 2; // Default thickness.

            // ���� ������ PolyLine�� �׷����� ���� List�� ��� �����ڸ� ȣ���Ѵ�.
            List<Point> pointList = new List<Point>();
            foreach(Point point in Points)
            {
                pointList.Add(point);
            }

            List<InspectionItem> inspectionList = new List<InspectionItem>();
            foreach (InspectionItem inspectionElement in inspectionItems)
            {
                inspectionList.Add(InspectionItemHelper.CopyInspectionItem(inspectionElement));
            }

            actualScale = (actualScale > 0) ? actualScale : 1.0;
            GraphicsBase b = new GraphicsPolyLine(pointList, lineWidth, regionType, objectColor, textColor, actualScale, caption, inspectionList);

            if (this.ID != 0)
            {
                b.Id = this.ID;
                b.IsSelected = this.selected;
            }

            return b;

        }

        #region Properties
        /// <summary>
        /// Points
        /// </summary>
        public Point[] Points
        {
            get
            {
                return points;
            }
            set
            {
                points = value;
            }
        }
        
        /// <summary>   Gets or sets the type of the region. </summary>
        /// <value> The type of the region. </value>
        public GraphicsRegionType RegionType
        {
            get
            {
                return regionType;
            }
            set
            {
                regionType = value;
            }
        }

        /// <summary>   Gets or sets the caption. </summary>
        /// <value> The caption. </value>
        public string Caption
        {
            get
            {
                return caption;
            }
            set
            {
                caption = value;
            }
        }

        /// <summary>   Gets or sets a list of inspections. </summary>
        /// <value> A List of inspections. </value>
        public InspectionItem[] InspectionList
        {
            get
            {
                return inspectionItems;
            }
            set
            {
                inspectionItems = value;
            }
        }
        #endregion Properties
    }
}
