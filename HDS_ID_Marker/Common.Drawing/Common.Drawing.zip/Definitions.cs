using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media;

namespace Common.Drawing
{
    /// <summary>   Definitions.  </summary>
    /// <remarks>   Minseok. Hwang, 2011-11-28. </remarks>
    public static class Definitions
    {
        public static int MAX_LOCAL_ALIGN_COUNT = 4;
    }

    /// <summary>   Values that represent GraphicsRegionType.  </summary>
    /// <remarks>   Minseok,Hwang, 2011-08-16. </remarks>
    public enum GraphicsRegionType
    {
        None = 0,
        Inspection = 1,     // �˻� ����
        UnitRegion = 2,     // ���� ����
        OuterRegion = 3,    // �ܰ� ����
        Except = 4,         // �˻� ���� ����
        StripAlign = 5,     // ��Ʈ�� Align
        UnitAlign = 6,      // ���� Align
        LocalAlign = 7      // ���� Align
    }

    /// <summary>   Values that represent ToolType.  </summary>
    public enum ToolType
    {
        Move = 0,
        Pointer = 1,
        Rectangle = 2,
        Ellipse = 3,
        Line = 4,
        PolyLine = 5,
        Text = 6,
        AlignPattern = 7, // Equals Rectangle.
        Max = 8         // = 7 �� = 8 // 20120207 : �迭 ����� Max ������ ������(����ȣ)
    };

    public enum FilpType
    {
        UPDOWN = 0,
        LEFTRIGHT = 1,
        STARTPOINT = 2
    }

    /// <summary>   Values that represent ContextMenuCommand.  </summary>
    public enum ContextMenuCommand
    {
        SetROIArrayCopy = 0,
        SetFiducialUnit = 1,
        UnsetFiducialUnit = 2,
        SetFiducialOuter = 3,
        UnsetFiducialOuter = 4,
        SetExceptInspectionRegion = 5,
        UnSetExceptInspectionRegion = 6,
        SetUnitRow = 7,
        SetUnitColumn = 8,
        Pointer = 9,
        Rectangle = 10,
        Ellipse = 11,
        PolyLine = 12,
        StripAlign = 13,
        UnitAlign = 14,
        SelectAll = 15,
        UnselectAll = 16,
        Delete = 17,
        DeleteAll = 18,
        Undo = 19,
        Redo = 20,
        MoveToFront = 21,
        MoveToBack = 22,
        SerProperties = 23,
        CopyROIToTop = 24,
        CopyROIToBottom = 25,
        CopyROIToTrans = 26,
        RotateROI = 27,
        RotateROI90 = 28,
        RotateROI180 = 29,
        SymmetryROI = 30,
        SymmetryROIUpDown = 31,
        SymmetryROILeftRight = 32,
        LocalAlign = 33,
        AddInspectItem = 34
    };

    /// <summary>   Information about the iteration symmetry.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-11-01. </remarks>
    public class IterationSymmetryInformation
    {
        /// <summary> The start x coordinate </summary>
        public int StartX;

        /// <summary> The start y coordinate </summary>
        public int StartY;

        /// <summary> The jump x coordinate </summary>
        public int JumpX;

        /// <summary> The jump y coordinate </summary>
        public int JumpY;

        /// <summary>   Initializes a new instance of the IterationSymmetryInformation class. </summary>
        /// <remarks>   Minseok. Hwang, 2011-11-10. </remarks>
        public IterationSymmetryInformation()
        {
            //
        }

        /// <summary>   Initializes a new instance of the IterationSymmetryInformation class. </summary>
        /// <remarks>   Minseok. Hwang, 2011-11-10. </remarks>
        public IterationSymmetryInformation(int startX, int startY, int jumpX, int jumpY)
        {
            this.StartX = startX;
            this.StartY = startY;
            this.JumpX = jumpX;
            this.JumpY = jumpY;
        }

        /// <summary>   Makes a deep copy of this object. </summary>
        /// <remarks>   Minseok. Hwang, 2011-11-10. </remarks>
        /// <returns>   A copy of this object. </returns>
        public IterationSymmetryInformation Clone()
        {
            IterationSymmetryInformation clonedSymmetryValue = new IterationSymmetryInformation();
            clonedSymmetryValue.StartX = this.StartX;
            clonedSymmetryValue.StartY = this.StartY;
            clonedSymmetryValue.JumpX = this.JumpX;
            clonedSymmetryValue.JumpY = this.JumpY;

            return clonedSymmetryValue;
        }
    }
    
    /// <summary>   Information about the iteration.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-09-23. </remarks>
    public class IterationInformation
    {
        /// <summary> The column </summary>
        public int Column;

        /// <summary> The row </summary>
        public int Row;

        /// <summary> The x coordinate pitch </summary>
        public double XPitch;

        /// <summary> The y coordinate pitch </summary>
        public double YPitch;

        /// <summary>   Initializes a new instance of the IterationInformation class. </summary>
        /// <remarks>   Minseok. Hwang, 2011-11-10. </remarks>
        public IterationInformation()
        {
            //
        }

        /// <summary>   Initializes a new instance of the Definitions class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-09-23. </remarks>
        /// <param name="column">   The column. </param>
        /// <param name="row">      The row. </param>
        /// <param name="xPitch">   The x coordinate pitch. </param>
        /// <param name="YPitch">   The y coordinate pitch. </param>
        public IterationInformation(int column, int row, double xPitch, double YPitch)
        {
            this.Column = column;
            this.Row = row;
            this.XPitch = xPitch;
            this.YPitch = YPitch;
        }

        /// <summary>   Initializes static members of the IterationInformation class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-17. </remarks>
        public IterationInformation Clone()
        {
            IterationInformation clonedIterationValue = new IterationInformation();
            clonedIterationValue.Column = this.Column;
            clonedIterationValue.Row = this.Row;
            clonedIterationValue.XPitch = this.XPitch;
            clonedIterationValue.YPitch = this.YPitch;

            return clonedIterationValue;
        }
    }

    /// <summary>   Graphics colors.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-09-07. </remarks>
    public static class GraphicsColors
    {
        /// <summary> The green brush </summary>
        public static readonly Color Green = Color.FromArgb(255, 0, 255, 0); // Inspection Type

        /// <summary> The red brush </summary>
        public static readonly Color Red = Color.FromArgb(255, 255, 0, 0); // Align Type

        /// <summary> The blue brush </summary>
        public static readonly Color Blue = Color.FromArgb(255, 0, 0, 255); // Except Type

        /// <summary> The yellow brush </summary>
        public static readonly Color Yellow = Colors.Yellow; // Align Text
    }

    /// <summary>   Caption helper.  </summary>
    /// <remarks>   Minseok. Hwang, 2011-11-24. </remarks>
    public static class CaptionHelper
    {
        /// <summary> The strip align caption </summary>
        public static readonly string StripAlignCaption = "Strip Align";

        /// <summary> The unit align caption </summary>
        public static readonly string UnitAlignCaption = "Unit Align";

        /// <summary> The fiducial outer region caption </summary>
        public static readonly string LocalAlignCaption = "Align";

        /// <summary> The fiducial unit region caption </summary>
        public static readonly string FiducialUnitRegionCaption = "���� Unit����";

        /// <summary> The fiducial outer region caption </summary>
        public static readonly string FiducialOuterRegionCaption = "���� �ܰ�����";

        /// <summary> The exceptional mask caption </summary>
        public static readonly string ExceptionalMaskCaption = "�˻�����";

        /// <summary>   Gets a section position caption. </summary>
        /// <remarks>   Minseok. Hwang, 2011-11-24. </remarks>
        /// <returns>   The section position caption. </returns>
        public static string GetSectionPositionCaption(GraphicsRectangle graphic)
        {
            if (graphic != null)
            {
                return String.Format("X:{0} Y:{1}", 
                    (graphic.SymmetryValue.StartX + graphic.SymmetryValue.JumpX * graphic.IterationXPosition), 
                    (graphic.SymmetryValue.StartY + graphic.SymmetryValue.JumpY * graphic.IterationYPosition));
            }
            else return string.Empty;
        }
    }
}
