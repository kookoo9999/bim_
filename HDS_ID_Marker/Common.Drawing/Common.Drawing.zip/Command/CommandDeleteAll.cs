// http://www.codeproject.com/cs/design/commandpatterndemo.asp
// The Command Pattern and MVC Architecture
// By David Veeneman.

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>   Command delete all.  </summary>
    class CommandDeleteAll : CommandBase
    {
        /// <summary> List of deleteds </summary>
        List<PropertiesGraphicsBase> deletedList = null;

        /// <summary>   Create this command before applying Delete All function. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public CommandDeleteAll(DrawingCanvas drawingCanvas)
        {
            deletedList = new List<PropertiesGraphicsBase>();

            // Make clone of the whole list. (for Undo/Redo)
            foreach (GraphicsBase g in drawingCanvas.GraphicsList)
            {
                deletedList.Add(g.CreateSerializedObject());
            }
        }

        /// <summary>   Restore all deleted objects to GraphicsList. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public override void Undo(DrawingCanvas drawingCanvas)
        {
            try
            {
                foreach (PropertiesGraphicsBase o in deletedList)
                {
                    drawingCanvas.GraphicsList.Add(o.CreateGraphics());
                }
                drawingCanvas.RefreshClip();
            }
            catch
            {
            }
        }

        /// <summary>   Delete all again. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public override void Redo(DrawingCanvas drawingCanvas)
        {
            try
            {
                drawingCanvas.GraphicsList.Clear();
            }
            catch
            {
            }
        }
    }
}
