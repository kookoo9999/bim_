// http://www.codeproject.com/cs/design/commandpatterndemo.asp
// The Command Pattern and MVC Architecture
// By David Veeneman.
// 
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>   Command base.  </summary>
    abstract class CommandBase
    {
        /// <summary>   Undo command. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public abstract void Undo(DrawingCanvas drawingCanvas);

        /// <summary>   Redo command. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public abstract void Redo(DrawingCanvas drawingCanvas);
    }
}
