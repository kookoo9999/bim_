// http://www.codeproject.com/cs/design/commandpatterndemo.asp
// The Command Pattern and MVC Architecture
// By David Veeneman.

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Diagnostics;
using System.Globalization;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>   
    /// 			Command change z-order.
    /// 			Command keeps list of object IDs before and after operation.
    /// 			Using these lists, it is possible to undo / redo change z-order operation.
    /// </summary>
    class CommandChangeOrder : CommandBase
    {
        #region member variables. (listBefore & listAfter)
        /// <summary> The list before. It stored z-orders of graphic list. </summary>
        private List<int> listBefore = null;

        /// <summary> The list after. It stored z-orders of graphic list. </summary>
        private List<int> listAfter = null;
        #endregion

        /// <summary>   Initializes a new instance of the CommandChangeOrder class. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public CommandChangeOrder(DrawingCanvas drawingCanvas)
        {
            FillList(drawingCanvas.GraphicsList, ref listBefore);
        }

        /// <summary>   Creates a new state. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public void NewState(DrawingCanvas drawingCanvas)
        {
            FillList(drawingCanvas.GraphicsList, ref listAfter);
        }

        /// <summary>   Undo command. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public override void Undo(DrawingCanvas drawingCanvas)
        {
            ChangeOrder(drawingCanvas.GraphicsList, listBefore);
        }

        /// <summary>   Redo command. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public override void Redo(DrawingCanvas drawingCanvas)
        {
            ChangeOrder(drawingCanvas.GraphicsList, listAfter);
        }

        /// <summary>   Fill list. </summary>
        /// <param name="graphicsList"> List of graphics. </param>
        /// <param name="listToFill">   [in,out] The list to fill. </param>
        private static void FillList(VisualCollection graphicsList, ref List<int> listToFill)
        {
            listToFill = new List<int>(); // listBefore or listAfter

            foreach (GraphicsBase g in graphicsList)
            {
                listToFill.Add(g.Id);
            }
        }

        /// <summary>   Change order. </summary>
        /// <param name="graphicsList"> List of graphics. </param>
        /// <param name="indexList">    List of indexes. </param>
        private static void ChangeOrder(VisualCollection graphicsList, List<int> indexList)
        {
            List<GraphicsBase> correctOrderList = new List<GraphicsBase>();

            // Read indexList, and re-arrange.
            foreach (int id in indexList)
            {
                foreach (GraphicsBase g in graphicsList)
                {
                    if (g.Id == id)
                    {
                        correctOrderList.Add(g); // Correct order.
                        graphicsList.Remove(g);
                        break;
                    }
                }
            }

            foreach (GraphicsBase g in correctOrderList)
            {
                graphicsList.Add(g); // Sets to DrawingCanvas.
            }
        }
    }
}
