// http://www.codeproject.com/cs/design/commandpatterndemo.asp
// The Command Pattern and MVC Architecture
// By David Veeneman.

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>   
    /// 			Changing state of existing objects : MOVE, RESIZE, and change properties.
    /// 			This command is always applied to the list selection.
    /// 			It keeps selection clone before and after operation.
    /// 			Undo/Redo operations replace objects in the list
    /// 			using selection clone.
    /// </summary>
    class CommandChangeState : CommandBase
    {
        #region member variables (listBefore & listAfter)
        /// <summary> The list before. Selected object(s) before operation </summary>
        private List<PropertiesGraphicsBase> listBefore = null;

        /// <summary> The list after. Selected object(s) after operation </summary>
        private List<PropertiesGraphicsBase> listAfter  = null;
        #endregion

        /// <summary>   Initializes a new instance of the CommandChangeState class. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public CommandChangeState(DrawingCanvas drawingCanvas)
        {
            FillList(drawingCanvas.GraphicsList, ref listBefore);
        }

        /// <summary>   Initializes a new instance of the CommandChangeState class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-06. </remarks>
        /// <param name="graphic">  The graphic. </param>
        public CommandChangeState(GraphicsBase graphic)
        {
            if (graphic != null)
            {
                listBefore = new List<PropertiesGraphicsBase>();
                listBefore.Add(graphic.CreateSerializedObject());
            }
        }

        /// <summary>   Creates a new state. (After operation(s)). </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public void NewState(DrawingCanvas drawingCanvas)
        {
            FillList(drawingCanvas.GraphicsList, ref listAfter);
        }

        /// <summary>   Creates a new state. (After operation(s)). </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-06. </remarks>
        /// <param name="graphic">  The graphic. </param>
        public void NewState(GraphicsBase graphic)
        {
            if (graphic != null)
            {
                listAfter = new List<PropertiesGraphicsBase>();
                listAfter.Add(graphic.CreateSerializedObject());
            }
        }

        #region Undo & Redo.
        /// <summary>   Undo command. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public override void Undo(DrawingCanvas drawingCanvas)
        {
            // Replace all objects in the list with objects from listBefore
            ReplaceObjects(drawingCanvas.GraphicsList, listBefore);

            drawingCanvas.RefreshClip();
        }

        /// <summary>   Redo command. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public override void Redo(DrawingCanvas drawingCanvas)
        {
            ReplaceObjects(drawingCanvas.GraphicsList, listAfter);

            drawingCanvas.RefreshClip();
        }
        #endregion

        /// <summary>   Replace objects. </summary>
        /// <param name="graphicsList"> List of graphics. </param>
        /// <param name="list">         The list. </param>
        private static void ReplaceObjects(VisualCollection graphicsList, List<PropertiesGraphicsBase> list)
        {
            try
            {
                for (int i = 0; i < graphicsList.Count; i++)
                {
                    if (list == null)
                    {
                        return;
                    }

                    foreach (PropertiesGraphicsBase o in list)
                    {
                        if (o.ID == ((GraphicsBase)graphicsList[i]).Id)
                        {
                            // ���� ����Ʈ�� �ӽ� �����ߴ� �������� �ǵ��� ���´�.
                            graphicsList.RemoveAt(i);
                            graphicsList.Insert(i, o.CreateGraphics());
                            break;
                        }
                    }
                }
            }
            catch
            {

            }
        }

        /// <summary>   Fill list. </summary>
        /// <param name="graphicsList"> List of graphics. </param>
        /// <param name="listToFill">   [in,out] The list to fill. </param>
        private static void FillList(VisualCollection graphicsList, ref List<PropertiesGraphicsBase> listToFill)
        {
            try
            {
                listToFill = new List<PropertiesGraphicsBase>();

                foreach (GraphicsBase g in graphicsList)
                {
                    if (g.IsSelected)
                    {
                        // ���õ� �������� ���� ����Ʈ�� �ӽ� �����Ѵ�.
                        listToFill.Add(g.CreateSerializedObject());
                    }
                }
            }
            catch
            {
            
            }
        }
    }
}
