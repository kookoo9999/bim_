﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Common.Drawing.InspectionInformation;
using Common.DataBase;
using System.Data;

namespace Common.Drawing.InspectionTypeUI
{
    /// <summary>   Fiducial align property.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-09. </remarks>
    public class FiducialAlignProperty : InspectionAlgorithm
    {
        public int AlignMarginX;    // 0043
        public int AlignMarginY;    // 0044
        public int AlignAcceptance; // 0045

        /// <summary>   Initializes a new instance of the FiducialAlignProperty class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-09. </remarks>
        public FiducialAlignProperty()
        {
            Code = "3001";
        }

        /// <summary>   Makes a deep copy of this object. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-11. </remarks>
        public override InspectionAlgorithm Clone()
        {
            FiducialAlignProperty cloneFiducialAlignProperty = new FiducialAlignProperty();

            cloneFiducialAlignProperty.AlignMarginX = this.AlignMarginX;
            cloneFiducialAlignProperty.AlignMarginY = this.AlignMarginY;
            cloneFiducialAlignProperty.AlignAcceptance = this.AlignAcceptance;

            return cloneFiducialAlignProperty;
        }

        #region Load & Save Properties.
        /// <summary>   Loads a property. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        public override void LoadProperty(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID, string strInspectCode)
        {
            AlignMarginX        = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0043");
            AlignMarginY        = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0044");
            AlignAcceptance     = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0045");
        }

        /// <summary>   Saves a property. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        /// <returns>   Query result. </returns>
        public override int SaveProperty(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID, string strInspectCode)
        {
            try
            {
                if (ConnectFactory.DBConnector() != null)
                {
                    string strQuery;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0043", AlignMarginX);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0044", AlignMarginY);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0045", AlignAcceptance);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                }
                else return -1;
            }
            catch
            {
                return -1;
            }

            return 1; // Save Success !!!
        }
        #endregion
    }

    /// <summary>   Interaction logic for StripAlign.xaml. </summary>
    /// <remarks>   Minseok, Hwang, 2011-09-24. </remarks>
    public partial class FiducialAlign : UserControl, IInspectionTypeUICommands
    {
        #region InspectType
        /// <summary>   Gets the type of the inspection. </summary>
        /// <value> The type of the inspection. </value>
        public eVisInspectType InspectType
        {
            get
            {
                return m_enumInspectType;
            }
        }
        private eVisInspectType m_enumInspectType;
        #endregion

        /// <summary>   Initializes a new instance of the FiducialAlign class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-09. </remarks>
        public FiducialAlign()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(FiducialAlign_Loaded);
        }

        private void FiducialAlign_Loaded(object sender, RoutedEventArgs e)
        {
            this.SetFocus();
        }

        /// <summary>   Sets the focus. </summary>
        /// <remarks>   Minseok, Hwang, 2011-09-24. </remarks>
        public void SetFocus()
        {
            this.txtAlignMarginX.Focus();
        }

        /// <summary>   Sets a dialog. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        /// <param name="strCaption">   The string caption. </param>
        /// <param name="inspectType">  Type of the inspect. </param>
        public void SetDialog(string strCaption, eVisInspectType inspectType)
        {
            this.txtCaption.Text = strCaption;
            this.m_enumInspectType = inspectType;
        }

        /// <summary>   Try save. </summary>
        /// <remarks>   Minseok, Hwang, 2011-09-24. </remarks>
        /// <param name="graphic">  The graphic. </param>
        public void TrySave(GraphicsBase graphic, int anInspectID)
        {
            try
            {
                int alignMarginX = Convert.ToInt32(this.txtAlignMarginX.Text);
                int alignMarginY = Convert.ToInt32(this.txtAlignMarginY.Text);
                int alignAcceptance = Convert.ToInt32(this.txtAlignAcceptance.Text);

                FiducialAlignProperty oldFiducialAlignValue = null;
                foreach (InspectionItem element in graphic.InspectionList)
                {
                    if (element.InspectionType != null && element.ID == anInspectID)
                    {
                        oldFiducialAlignValue = element.InspectionAlgorithm as FiducialAlignProperty; // 기존에 저장된 값이 있는 경우.
                        break;
                    }
                }

                int nMaxInspectID = -1;
                foreach (InspectionItem element in graphic.InspectionList)
                {
                    if (nMaxInspectID < element.ID)
                        nMaxInspectID = element.ID;
                }

                if (oldFiducialAlignValue == null) // 기존에 저장된 값이 없는 경우, 새로 리스트에 추가시킨다.
                {
                    FiducialAlignProperty fiducialAlignValue = new FiducialAlignProperty();
                    fiducialAlignValue.AlignMarginX = alignMarginX;
                    fiducialAlignValue.AlignMarginY = alignMarginY;
                    fiducialAlignValue.AlignAcceptance = alignAcceptance;

                    InspectionItem inspectionItem = new InspectionItem();
                    inspectionItem.ID = nMaxInspectID + 1;
                    inspectionItem.InspectionType = InspectionType.GetInspectionType(m_enumInspectType);
                    inspectionItem.InspectionAlgorithm = fiducialAlignValue;

                    if (inspectionItem.InspectionType != null)
                    {
                        graphic.InspectionList.Add(inspectionItem);
                    }
                }
                else
                {
                    oldFiducialAlignValue.AlignMarginX = alignMarginX;
                    oldFiducialAlignValue.AlignMarginY = alignMarginY;
                    oldFiducialAlignValue.AlignAcceptance = alignAcceptance;
                }
            }
            catch
            {
                MessageBox.Show("잘못 입력된 값이 존재합니다. 확인 바랍니다.", "Information");
                txtAlignMarginX.Focus();
            }
        }

        /// <summary>   Cancels this object. </summary>
        /// <remarks>   Minseok, Hwang, 2011-09-24. </remarks>
        public void SetDefaultValue()
        {
            if (m_enumInspectType == eVisInspectType.eInspTypeGlobalAlign)
            {
                if (!StripAlignDefaultValue.DefaultValueLoaded)
                {
                    StripAlignDefaultValue.DefaultValueLoaded = true;
                    StripAlignDefaultValue.LoadDefaultValue();
                }

                this.txtAlignMarginX.Text = StripAlignDefaultValue.AlignMarginX.ToString();
                this.txtAlignMarginY.Text = StripAlignDefaultValue.AlignMarginY.ToString();
                this.txtAlignAcceptance.Text = StripAlignDefaultValue.AlignAcceptance.ToString();
            }
            else //if(m_enumInspectType == eVisInspectType.eInspTypeUnitAlign)
            {
                if (!UnitAlignDefaultValue.DefaultValueLoaded)
                {
                    UnitAlignDefaultValue.LoadDefaultValue();
                }

                this.txtAlignMarginX.Text = UnitAlignDefaultValue.AlignMarginX.ToString();
                this.txtAlignMarginY.Text = UnitAlignDefaultValue.AlignMarginY.ToString();
                this.txtAlignAcceptance.Text = UnitAlignDefaultValue.AlignAcceptance.ToString();
            }
        }

        /// <summary>   Displays the given settingValue. </summary>
        /// <remarks>   Minseok, Hwang, 2011-09-28. </remarks>
        /// <param name="settingValue"> The setting value. </param>
        public void Display(InspectionItem inspectionItem)
        {
            // Data를 View에 보여준다.
            FiducialAlignProperty fiducialAlignValue = inspectionItem.InspectionAlgorithm as FiducialAlignProperty;
            if (fiducialAlignValue != null)
            {
                this.txtAlignMarginX.Text = fiducialAlignValue.AlignMarginX.ToString();
                this.txtAlignMarginY.Text = fiducialAlignValue.AlignMarginY.ToString();
                this.txtAlignAcceptance.Text = fiducialAlignValue.AlignAcceptance.ToString();
            }
        }
    }
}
