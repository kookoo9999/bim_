﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Common.Drawing.InspectionInformation;
using Common.DataBase;
using System.Data;

namespace Common.Drawing.InspectionTypeUI
{
    /// <summary>   Groove property.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
    public class GrooveProperty : InspectionAlgorithm
    {
        public int ThreshType;              // 0000
        public int LowerThresh;             // 0001
        public int UpperThresh;             // 0002
        public int ApplyAverDiff;           // 0003
        public int AverMinMargin;           // 0007
        public int AverMaxMargin;           // 0008
        public int MinWidthRatio;           // 0030
        public int MinWidthSize;            // 0031
        public int MaxWidthRatio;           // 0032
        public int MaxWidthSize;            // 0033
        public int MinHeightSize;           // 0035
        public int MaxHeightRatio;          // 0036
        public int MaxHeightSize;           // 0037
        public int CriterionSize;           // 0048
        public int MinNormalRatio;          // 0038
        public int MaxNormalRatio;          // 0039

        public GrooveProperty()
        {
            Code = "3009";
        }

        public override InspectionAlgorithm Clone()
        {
            GrooveProperty cloneGroove = new GrooveProperty();

            cloneGroove.ThreshType = this.ThreshType;
            cloneGroove.LowerThresh = this.LowerThresh;
            cloneGroove.UpperThresh = this.UpperThresh;
            cloneGroove.ApplyAverDiff = this.ApplyAverDiff;
            cloneGroove.AverMinMargin = this.AverMinMargin;
            cloneGroove.AverMaxMargin = this.AverMaxMargin;
            cloneGroove.MinWidthRatio = this.MinWidthRatio;
            cloneGroove.MinWidthSize = this.MinWidthSize;
            cloneGroove.MaxWidthRatio = this.MaxWidthRatio;
            cloneGroove.MaxWidthSize = this.MaxWidthSize;
            cloneGroove.MinHeightSize = this.MinHeightSize;
            cloneGroove.MaxHeightRatio = this.MaxHeightRatio;
            cloneGroove.MaxHeightSize = this.MaxHeightSize;
            cloneGroove.CriterionSize = this.CriterionSize;
            cloneGroove.MinNormalRatio = this.MinNormalRatio;
            cloneGroove.MaxNormalRatio = this.MaxNormalRatio;

            return cloneGroove;
        }

        public override void LoadProperty(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID, string strInspectCode)
        {
            ThreshType      = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0000");
            LowerThresh     = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0001");
            UpperThresh     = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0002");
            ApplyAverDiff   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0003");
            AverMinMargin   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0007");
            AverMaxMargin   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0008");
            MinWidthRatio   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0030");
            MinWidthSize    = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0031");
            MaxWidthRatio   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0032");
            MaxWidthSize    = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0033");
            MinHeightSize   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0035");
            MaxHeightRatio  = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0036");
            MaxHeightSize   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0037");
            CriterionSize   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0048");
            MinNormalRatio  = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0038");
            MaxNormalRatio  = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0039");

        }

        public override int SaveProperty(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID, string strInspectCode)
        {
            try
            {
                if (ConnectFactory.DBConnector() != null)
                {
                    string strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0000", ThreshType);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0001 ", LowerThresh);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0002 ", UpperThresh);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                    
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0003", ApplyAverDiff);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                    
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0007", AverMinMargin);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                    
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0008", AverMaxMargin);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0030 ", MinWidthRatio);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0031 ", MinWidthSize);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                    
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0032 ", MaxWidthRatio);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                    
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0033 ", MaxWidthSize);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                     
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0035 ", MinHeightSize);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                    
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0036 ", MaxHeightRatio);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                    
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0037 ", MaxHeightSize);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0048 ", CriterionSize);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0038 ", MinNormalRatio);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                    
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0039 ", MaxNormalRatio);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                }
                else
                {
                    return -1;
                }
            }
            catch
            {
                return -1;
            }

            return 1; // Save Success !!!
        }
    }

    public partial class Groove : UserControl, IInspectionTypeUICommands
    {
        #region Inspect Type
        public eVisInspectType InspectType
        {
            get
            {
                return m_enumInspectType;
            }
        }
        private eVisInspectType m_enumInspectType;
        #endregion

        /// <summary> The default thresh type </summary>
        private static int DEFAULT_THRESH_TYPE = 2;

        public Groove()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(Groove_Loaded);
        }

        private void Groove_Loaded(object sender, RoutedEventArgs e)
        {
            this.SetFocus();
        }

        public void SetDialog(string strCaption, InspectionInformation.eVisInspectType inspectType)
        {
            this.txtCaption.Text = strCaption;
            this.m_enumInspectType = inspectType;
        }

        public void SetFocus()
        {
            this.txtLowerThreshold.Focus();
        }

        public void TrySave(GraphicsBase graphic, int anInspectID)
        {
            try
            {
                int threshType = DEFAULT_THRESH_TYPE;

                int lowerThresh = Convert.ToInt32(txtLowerThreshold.Text);
                int upperThresh = Convert.ToInt32(txtUpperThreshold.Text);

                if (lowerThresh > upperThresh)
                {
                    MessageBox.Show("임계 하한 값은 임계 상한 값을 초과할 수 없습니다.", "Information");
                    this.txtLowerThreshold.Focus();
                    return;
                }

                int applyAverDiff = (chkApplyAverDiff.IsChecked == true) ? 1 : 0;
                #region Check 평균값 최소 / 최대 허용범위
                int averMinMargin = Convert.ToInt32(txtAverMinMargin.Text);
                int averMaxMargin = Convert.ToInt32(txtAverMaxMargin.Text);

                //if (averMinMargin > averMaxMargin)
                //{
                //    MessageBox.Show("평균값 최소 허용범위는 평균값 최대 허용범위를 초과할 수 없습니다.", "Information");
                //    this.txtAverMinMargin.Focus();
                //    return;
                //}
                #endregion
                int minWidthRatio = Convert.ToInt32(txtMinWidthRatio.Text);
                int minWidthSize = Convert.ToInt32(txtMinWidthSize.Text);
                int maxWidthRatio = Convert.ToInt32(txtMaxWidthRatio.Text);
                int maxWidthSize = Convert.ToInt32(txtMaxWidthSize.Text);
                int minHeightSize = Convert.ToInt32(txtMinHeightSize.Text);
                int maxHeightRatio = Convert.ToInt32(txtMaxHeightRatio.Text);
                int maxHeightSize = Convert.ToInt32(txtMaxHeightSize.Text);
                int criterionSize = Convert.ToInt32(txtCriterionSize.Text);
                int minNormalRatio = Convert.ToInt32(txtMinNormalRatio.Text);
                int maxNormalRatio = Convert.ToInt32(txtMaxNormalRatio.Text);

                GrooveProperty oldGrooveValue = null;
                foreach (InspectionItem element in graphic.InspectionList)
                {
                    if (element.ID == anInspectID)
                    {
                        oldGrooveValue = element.InspectionAlgorithm as GrooveProperty; // 기존에 저장된 값이 있는 경우.
                        break;
                    }
                }

                int nMaxInspectID = -1;
                foreach (InspectionItem element in graphic.InspectionList)
                {
                    if (nMaxInspectID < element.ID)
                        nMaxInspectID = element.ID;
                }

                if (oldGrooveValue == null) // 기존에 저장된 값이 없는 경우, 새로 리스트에 추가시킨다.
                {
                    GrooveProperty grooveValue = new GrooveProperty();

                    grooveValue.ThreshType = threshType;
                    grooveValue.LowerThresh = lowerThresh;
                    grooveValue.UpperThresh = upperThresh;
                    grooveValue.ApplyAverDiff = applyAverDiff;
                    grooveValue.AverMinMargin = averMinMargin;
                    grooveValue.AverMaxMargin = averMaxMargin;
                    grooveValue.MinWidthRatio = minWidthRatio;
                    grooveValue.MinWidthSize = minWidthSize;
                    grooveValue.MaxWidthRatio = maxWidthRatio;
                    grooveValue.MaxWidthSize = maxWidthSize;
                    grooveValue.MinHeightSize = minHeightSize;
                    grooveValue.MaxHeightRatio = maxHeightRatio;
                    grooveValue.MaxHeightSize = maxHeightSize;
                    grooveValue.CriterionSize = criterionSize;
                    grooveValue.MinNormalRatio = minNormalRatio;
                    grooveValue.MaxNormalRatio = maxNormalRatio;


                    InspectionItem inspectionItem = new InspectionItem();
                    inspectionItem.ID = nMaxInspectID + 1;
                    inspectionItem.InspectionType = InspectionType.GetInspectionType(m_enumInspectType);
                    inspectionItem.InspectionAlgorithm = grooveValue;

                    if (inspectionItem.InspectionType != null)
                    {
                        graphic.InspectionList.Add(inspectionItem);
                    }
                }
                else
                {
                    oldGrooveValue.ThreshType = threshType;
                    oldGrooveValue.LowerThresh = lowerThresh;
                    oldGrooveValue.UpperThresh = upperThresh;
                    oldGrooveValue.ApplyAverDiff = applyAverDiff;
                    oldGrooveValue.AverMinMargin = averMinMargin;
                    oldGrooveValue.AverMaxMargin = averMaxMargin;
                    oldGrooveValue.MinWidthRatio = minWidthRatio;
                    oldGrooveValue.MinWidthSize = minWidthSize;
                    oldGrooveValue.MaxWidthRatio = maxWidthRatio;
                    oldGrooveValue.MaxWidthSize = maxWidthSize;
                    oldGrooveValue.MinHeightSize = minHeightSize;
                    oldGrooveValue.MaxHeightRatio = maxHeightRatio;
                    oldGrooveValue.MaxHeightSize = maxHeightSize;
                    oldGrooveValue.CriterionSize = criterionSize;
                    oldGrooveValue.MinNormalRatio = minNormalRatio;
                    oldGrooveValue.MaxNormalRatio = maxNormalRatio;
                }
            }
            catch
            {
                MessageBox.Show("잘못 입력된 값이 존재합니다. 확인 바랍니다.", "Information");
                txtLowerThreshold.Focus();
            }
        }

        public void SetDefaultValue()
        {
            if (m_enumInspectType == eVisInspectType.eInspTypeGroove)
            {
                if (!GrooveDefaultValue.DefaultValueLoaded)
                {
                    GrooveDefaultValue.DefaultValueLoaded = true;
                    GrooveDefaultValue.LoadDefaultValue();
                }

                this.txtLowerThreshold.Text = GrooveDefaultValue.LowerThresh.ToString();
                this.txtUpperThreshold.Text = GrooveDefaultValue.UpperThresh.ToString();
                this.chkApplyAverDiff.IsChecked = (GrooveDefaultValue.ApplyAverDiff == 1) ? true : false;
                this.txtAverMinMargin.Text = GrooveDefaultValue.AverMinMargin.ToString();
                this.txtAverMaxMargin.Text = GrooveDefaultValue.AverMaxMargin.ToString();
                this.txtMinWidthRatio.Text = GrooveDefaultValue.MinWidthRatio.ToString();
                this.txtMinWidthSize.Text = GrooveDefaultValue.MinWidthSize.ToString();
                this.txtMaxWidthRatio.Text = GrooveDefaultValue.MaxWidthRatio.ToString();
                this.txtMaxWidthSize.Text = GrooveDefaultValue.MaxWidthSize.ToString();
                this.txtMinHeightSize.Text = GrooveDefaultValue.MinHeightSize.ToString();
                this.txtMaxHeightRatio.Text = GrooveDefaultValue.MaxHeightRatio.ToString();
                this.txtMaxHeightSize.Text = GrooveDefaultValue.MaxHeightSize.ToString();
                this.txtCriterionSize.Text = GrooveDefaultValue.CriterionSize.ToString();
                this.txtMinNormalRatio.Text = GrooveDefaultValue.MinNormalRatio.ToString();
                this.txtMaxNormalRatio.Text = GrooveDefaultValue.MaxNormalRatio.ToString();
            }
        }

        public void Display(InspectionItem settingValue)
        {
            GrooveProperty grooveProperty = settingValue.InspectionAlgorithm as GrooveProperty;
            if (grooveProperty != null)
            {
                this.txtLowerThreshold.Text = grooveProperty.LowerThresh.ToString();
                this.txtUpperThreshold.Text = grooveProperty.UpperThresh.ToString();
                this.chkApplyAverDiff.IsChecked = (grooveProperty.ApplyAverDiff == 1) ? true : false;
                this.txtAverMinMargin.Text = grooveProperty.AverMinMargin.ToString();
                this.txtAverMaxMargin.Text = grooveProperty.AverMaxMargin.ToString();
                this.txtMinWidthRatio.Text = grooveProperty.MinWidthRatio.ToString();
                this.txtMinWidthSize.Text = grooveProperty.MinWidthSize.ToString();
                this.txtMaxWidthRatio.Text = grooveProperty.MaxWidthRatio.ToString();
                this.txtMaxWidthSize.Text = grooveProperty.MaxWidthSize.ToString();
                this.txtMinHeightSize.Text = grooveProperty.MinHeightSize.ToString();
                this.txtMaxHeightRatio.Text = grooveProperty.MaxHeightRatio.ToString();
                this.txtMaxHeightSize.Text = grooveProperty.MaxHeightSize.ToString();
                this.txtCriterionSize.Text = grooveProperty.CriterionSize.ToString();
                this.txtMinNormalRatio.Text = grooveProperty.MinNormalRatio.ToString();
                this.txtMaxNormalRatio.Text = grooveProperty.MaxNormalRatio.ToString();
            }
        }
    }
}
