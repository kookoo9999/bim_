﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Common.Drawing.InspectionInformation;
using Common.DataBase;

namespace Common.Drawing.InspectionTypeUI
{
    /// <summary>   Fiducial align property.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-09. </remarks>
    public class ExceptionalMaskProperty : InspectionAlgorithm
    {
        public int ExceptionX;    // 0000
        public int ExceptionY;    // 0001
        public int UseShapeShift; // 0002

        /// <summary>   Initializes a new instance of the FiducialAlignProperty class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-09. </remarks>
        public ExceptionalMaskProperty()
        {
            Code = "3016";
        }

        /// <summary>   Makes a deep copy of this object. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-11. </remarks>
        public override InspectionAlgorithm Clone()
        {
            ExceptionalMaskProperty cloneExceptioalMaskProperty = new ExceptionalMaskProperty();

            cloneExceptioalMaskProperty.ExceptionX = this.ExceptionX;
            cloneExceptioalMaskProperty.ExceptionY = this.ExceptionY;
            cloneExceptioalMaskProperty.UseShapeShift = this.UseShapeShift;

            return cloneExceptioalMaskProperty;
        }

        #region Load & Save Properties.
        /// <summary>   Loads a property. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        public override void LoadProperty(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID, string strInspectCode)
        {
            ExceptionX      = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0000");
            ExceptionY      = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0001");
            UseShapeShift   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0002");

            ExceptionX = (ExceptionX == 9999) ? -1 : ExceptionX;
            ExceptionY = (ExceptionY == 9999) ? -1 : ExceptionY;
        }

        /// <summary>   Saves a property. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        /// <returns>   Query result. </returns>
        public override int SaveProperty(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID, string strInspectCode)
        {
            try
            {
                if (ConnectFactory.DBConnector() != null)
                {
                    int nDbExceptionX = (ExceptionX == -1) ? 9999 : ExceptionX;
                    int nDbExceptionY = (ExceptionY == -1) ? 9999 : ExceptionY;
                    string strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0000", nDbExceptionX);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0001", nDbExceptionY);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    // UseShapeShift = 0 | 1 | 2 | 3;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0002", UseShapeShift);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                }
                else return -1;
            }
            catch
            {
                return -1;
            }

            return 1; // Save Success !!!
        }
        #endregion
    }

    /// <summary>
    /// Interaction logic for ExceptionalMask.xaml
    /// </summary>
    public partial class ExceptionalMask : UserControl, IInspectionTypeUICommands
    {
        public ExceptionalMask()
        {
            InitializeComponent();
            InitializeDialog();

            this.Loaded += new RoutedEventHandler(ExceptionalMask_Loaded);
        }

        private void ExceptionalMask_Loaded(object sender, RoutedEventArgs e)
        {
            this.SetFocus();
        }

        public void SetMaxValue(int anX, int anY)
        {
            this.cbExceptionY.Items.Clear();
            this.cbExceptionY.Items.Add("전체");
            for (int i = 0; i < anY; i++)
            {
                this.cbExceptionY.Items.Add((i + 1).ToString());
            }
            this.cbExceptionY.SelectedIndex = 0;

            this.cbExceptionX.Items.Clear();
            this.cbExceptionX.Items.Add("전체");
            for (int i = 0; i < anX; i++)
            {
                this.cbExceptionX.Items.Add((i + 1).ToString());
            }
            this.cbExceptionX.SelectedIndex = 0;
        }

        private void InitializeDialog()
        {
            this.cbUseOffset.Items.Clear();
            this.cbUseOffset.Items.Add("사용안함");
            this.cbUseOffset.Items.Add("Shape Shift");
            this.cbUseOffset.SelectedIndex = 0;

            SetMaxValue(1, 1);
        }

        public void SetDefaultValue()
        {
            if (!ExceptionalMaskDefaultValue.DefaultValueLoaded)
            {
                ExceptionalMaskDefaultValue.DefaultValueLoaded = true;
                ExceptionalMaskDefaultValue.LoadDefaultValue();
            }

            this.cbExceptionX.SelectedIndex = (ExceptionalMaskDefaultValue.ExceptionX + 1);
            this.cbExceptionY.SelectedIndex = (ExceptionalMaskDefaultValue.ExceptionY + 1);

            if (ExceptionalMaskDefaultValue.UseShapeShift != 0)
            {
                cbUseOffset.SelectedIndex = 1;
            }
        }

        /// <summary>   Displays the given settingValue. </summary>
        /// <remarks>   Minseok, Hwang, 2011-09-28. </remarks>
        /// <param name="settingValue"> The setting value. </param>
        public void Display(InspectionItem inspectionItem)
        {
            // Data를 View에 보여준다.
            ExceptionalMaskProperty exceptionalMaskValue = inspectionItem.InspectionAlgorithm as ExceptionalMaskProperty;
            if (exceptionalMaskValue != null)
            {
                this.cbExceptionX.SelectedIndex = (exceptionalMaskValue.ExceptionX + 1);
                this.cbExceptionY.SelectedIndex = (exceptionalMaskValue.ExceptionY + 1);
                if (exceptionalMaskValue.UseShapeShift != 0)
                    this.cbUseOffset.SelectedIndex = 1;
            }
        }

        public void TrySave(GraphicsBase graphic, int anInspectID)
        {
            try
            {
                int applyExceptionY = Convert.ToInt32(this.cbExceptionY.SelectedIndex) - 1;
                int applyExceptionX = Convert.ToInt32(this.cbExceptionX.SelectedIndex) - 1;
                int applyUseShapeShift;
                switch (cbUseOffset.SelectedIndex)
                {
                    case 0:
                        applyUseShapeShift = 0;
                        // 다른 Offset 사용 여부
                        break;
                    case 1:
                        applyUseShapeShift = 3;
                        break;
                    default:
                        throw (new Exception());
                }

                ExceptionalMaskProperty oldExceptionalMaskValue = null;
                bool newItem = true;

                foreach (InspectionItem element in graphic.InspectionList)
                {
                    if (element.InspectionType != null)//element.InspectionType.Name == this.lblCaption.Content.ToString())
                    {
                        if(element.ID == anInspectID)
                        {
                            newItem = false;
                            oldExceptionalMaskValue = element.InspectionAlgorithm as ExceptionalMaskProperty;
                            break;
                        }
                        
                        if(element.InspectionType.Name == this.txtCaption.Text.ToString())
                        {
                            oldExceptionalMaskValue = element.InspectionAlgorithm as ExceptionalMaskProperty; // 기존에 저장된 값이 있는 경우.
                        }
                    }
                }

                int nMaxInspectID = -1;
                foreach (InspectionItem element in graphic.InspectionList)
                {
                    if(nMaxInspectID < element.ID)
                        nMaxInspectID = element.ID;
                }

                if (newItem) // 기존에 저장된 값이 없는 경우, 새로 리스트에 추가시킨다.
                {
                    ExceptionalMaskProperty ExceptionalMaskValue = new ExceptionalMaskProperty();
                    ExceptionalMaskValue.ExceptionX = applyExceptionX;
                    ExceptionalMaskValue.ExceptionY = applyExceptionY;
                    ExceptionalMaskValue.UseShapeShift = applyUseShapeShift;

                    InspectionItem inspectionItem = new InspectionItem();
                    inspectionItem.ID = nMaxInspectID + 1;
                    inspectionItem.InspectionType = InspectionType.GetInspectionType(eVisInspectType.eInspTypeExceptionalMask);
                    inspectionItem.InspectionAlgorithm = ExceptionalMaskValue;

                    if (inspectionItem.InspectionType != null)
                    {
                        graphic.InspectionList.Add(inspectionItem);
                    }
                }
                else
                {
                    oldExceptionalMaskValue.ExceptionX = applyExceptionX;
                    oldExceptionalMaskValue.ExceptionY = applyExceptionY;
                    oldExceptionalMaskValue.UseShapeShift = applyUseShapeShift;
                }

                graphic.Caption = CaptionHelper.ExceptionalMaskCaption;
                graphic.ObjectColor = GraphicsColors.Blue;
                graphic.TextColor = GraphicsColors.Blue;
                graphic.RegionType = GraphicsRegionType.Except;
            }
            catch
            {
                MessageBox.Show("잘못 입력된 값이 존재합니다. 확인 바랍니다.", "Information");
                cbExceptionX.Focus();
            }
        }

        public void SetFocus()
        {
            this.cbExceptionX.Focus();
        }

        /// <summary>   Sets a dialog. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        /// <param name="strCaption">   The string caption. </param>
        /// <param name="inspectType">  Type of the inspect. </param>
        public void SetDialog(string strCaption, eVisInspectType inspectType)
        {
            this.txtCaption.Text = strCaption;
        }
    }
}
