﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using Common.Drawing.InspectionInformation;

namespace Common.Drawing.InspectionTypeUI
{
    /// <summary>   Interface for inspection type user interface commands.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-09-24. </remarks>
    public interface IInspectionTypeUICommands
    {
        /// <summary>   Sets the focus. </summary>
        void SetFocus();

        /// <summary>   Sets a dialog. </summary>
        /// <param name="strCaption">   The string caption. </param>
        /// <param name="inspectType">  Type of the inspect. </param>
        void SetDialog(string strCaption, eVisInspectType inspectType);

        /// <summary>   Try save. </summary>
        /// <param name="graphic">  The graphic. </param>
        void TrySave(GraphicsBase graphic, int anInspectID);

        /// <summary>   Cancels this object. </summary>
        void SetDefaultValue();

        /// <summary>   Displays the given settingValue. </summary>
        /// <param name="settingValue"> The setting value. </param>
        void Display(InspectionItem settingValue);
    }
}
