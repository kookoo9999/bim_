﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Common.Drawing.InspectionInformation;
using Common.DataBase;
using System.Data;

namespace Common.Drawing.InspectionTypeUI
{
    /// <summary>   Lead shape with center line property.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-11. </remarks>
    public class LeadShapeWithCenterLineProperty : InspectionAlgorithm
    {
        public int ThreshType;      // 0000
        public int LowerThresh;     // 0001
        public int UpperThresh;     // 0002
        public int MinWidthRatio;   // 0030
        public int MinWidthSize;    // 0031
        public int MaxWidthRatio;   // 0032
        public int MaxWidthSize;    // 0033
        public int MinHeightsize;   // 0035
        public int MinNormalRatio;  // 0038
        public int MaxNormalRatio;  // 0039

        /// <summary>   Initializes a new instance of the ShapeShiftProperty class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        public LeadShapeWithCenterLineProperty()
        {
            Code = "3008";
        }

        #region Load & Save Properties.
        /// <summary>   Loads a property. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        public override void LoadProperty(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID, string strInspectCode)
        {
            ThreshType      = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode,strInspectID, strInspectCode, this.Code, "0000");
            LowerThresh     = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode,strInspectID, strInspectCode, this.Code, "0001");
            UpperThresh     = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode,strInspectID, strInspectCode, this.Code, "0002");
            MinWidthRatio   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode,strInspectID, strInspectCode, this.Code, "0030");
            MinWidthSize    = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode,strInspectID, strInspectCode, this.Code, "0031");
            MaxWidthRatio   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode,strInspectID, strInspectCode, this.Code, "0032");
            MaxWidthSize    = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode,strInspectID, strInspectCode, this.Code, "0033");
            MinHeightsize   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode,strInspectID, strInspectCode, this.Code, "0035");
            MinNormalRatio  = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode,strInspectID, strInspectCode, this.Code, "0038");
            MaxNormalRatio  = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode,strInspectID, strInspectCode, this.Code, "0039");
        }

        /// <summary>   Saves a property. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        /// <returns>   Query result. </returns>
        public override int SaveProperty(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID, string strInspectCode)
        {
            try
            {
                if (ConnectFactory.DBConnector() != null)
                {
                    string strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0000", ThreshType);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0001", LowerThresh);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0002", UpperThresh);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0030", MinWidthRatio);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                  
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0031", MinWidthSize);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                  
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0032", MaxWidthRatio);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                    
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0033", MaxWidthSize);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                  
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0035", MinHeightsize);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                    
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0038", MinNormalRatio);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0039", MaxNormalRatio);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                }
                else
                {
                    return -1;
                }
            }
            catch
            {
                return -1;
            }

            return 1; // Save Success !!!
        }
        #endregion

        /// <summary>   Makes a deep copy of this object. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-11. </remarks>
        public override InspectionAlgorithm Clone()
        {
            LeadShapeWithCenterLineProperty cloneLeadShapeWithCenterLineProperty = new LeadShapeWithCenterLineProperty();

            cloneLeadShapeWithCenterLineProperty.ThreshType = this.ThreshType;
            cloneLeadShapeWithCenterLineProperty.LowerThresh = this.LowerThresh;
            cloneLeadShapeWithCenterLineProperty.UpperThresh = this.UpperThresh;
            cloneLeadShapeWithCenterLineProperty.MinWidthRatio = this.MinWidthRatio;
            cloneLeadShapeWithCenterLineProperty.MinWidthSize = this.MinWidthSize;
            cloneLeadShapeWithCenterLineProperty.MaxWidthRatio = this.MaxWidthRatio;
            cloneLeadShapeWithCenterLineProperty.MaxWidthSize = this.MaxWidthSize;
            cloneLeadShapeWithCenterLineProperty.MinHeightsize = this.MinHeightsize;
            cloneLeadShapeWithCenterLineProperty.MinNormalRatio = this.MinNormalRatio;
            cloneLeadShapeWithCenterLineProperty.MaxNormalRatio = this.MaxNormalRatio;

            return cloneLeadShapeWithCenterLineProperty;
        }
    }

    /// <summary>   Lead shape with center line.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
    public partial class LeadShapeWithCenterLine : UserControl, IInspectionTypeUICommands
    {
        #region Inspect Type
        /// <summary>   Gets the type of the inspection. </summary>
        /// <value> The type of the inspection. </value>
        public eVisInspectType InspectType
        {
            get
            {
                return m_enumInspectType;
            }
        }
        private eVisInspectType m_enumInspectType;
        #endregion

        public LeadShapeWithCenterLine()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(LeadShapeWithCenterLine_Loaded);
        }

        private void LeadShapeWithCenterLine_Loaded(object sender, RoutedEventArgs e)
        {
            this.SetFocus();
        }

        /// <summary>   Sets the focus. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        public void SetFocus()
        {
            this.txtLowerThreshold.Focus();
        }

        /// <summary>   Sets a dialog. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        /// <param name="strCaption">   The string caption. </param>
        /// <param name="inspectType">  Type of the inspect. </param>
        public void SetDialog(string strCaption, eVisInspectType inspectType)
        {
            this.txtCaption.Text = strCaption;
            this.m_enumInspectType = inspectType;
        }

        public void TrySave(GraphicsBase graphic, int anInspectID)
        {
            try
            {
                int threshType = 2;

                int lowerThresh = Convert.ToInt32(txtLowerThreshold.Text);
                int upperThresh = Convert.ToInt32(txtUpperThreshold.Text);

                if (lowerThresh > upperThresh)
                {
                    MessageBox.Show("임계 하한 값은 임계 상한 값을 초과할 수 없습니다.", "Information");
                    this.txtLowerThreshold.Focus();
                    return;
                }

                int minNormalRatio = Convert.ToInt32(txtMinNormalRatio.Text);
                int maxNormalRatio = Convert.ToInt32(txtMaxNormalRatio.Text);

                if (minNormalRatio > maxNormalRatio)
                {
                    MessageBox.Show("리드편차 최소 허용범위는 리드편차 최대 허용범위를 초과할 수 없습니다.", "Information");
                    this.txtMinNormalRatio.Focus();
                    return;
                }

                int minHeightSize = Convert.ToInt32(txtMinHeightSize.Text);

                int minWidthRatio = Convert.ToInt32(txtMinWidthRatio.Text);
                int maxWidthRatio = Convert.ToInt32(txtMaxWidthRatio.Text);

                if (minWidthRatio > maxWidthRatio)
                {
                    MessageBox.Show("리드 최소 선폭범위는 리드 최대 선폭범위를 초과할 수 없습니다.", "Information");
                    this.txtMinWidthRatio.Focus();
                    return;
                }

                int minWidthSize = Convert.ToInt32(txtMinWidthSize.Text);
                int maxWidthSize = Convert.ToInt32(txtMaxWidthSize.Text);

                if (minWidthSize > maxWidthSize)
                {
                    MessageBox.Show("리드 최소 선폭은 리드 최대 선폭을 초과할 수 없습니다.", "Information");
                    this.txtMinWidthSize.Focus();
                    return;
                }

                LeadShapeWithCenterLineProperty oldLeadWithCenterLineValue = null;
                foreach (InspectionItem element in graphic.InspectionList)
                {
                    if (element.ID == anInspectID)
                    {
                        oldLeadWithCenterLineValue = element.InspectionAlgorithm as LeadShapeWithCenterLineProperty; // 기존에 저장된 값이 있는 경우.
                        break;
                    }
                }

                int nMaxInspectID = -1;
                foreach (InspectionItem element in graphic.InspectionList)
                {
                    if (nMaxInspectID < element.ID)
                        nMaxInspectID = element.ID;
                }

                if (oldLeadWithCenterLineValue == null) // 기존에 저장된 값이 없는 경우, 새로 리스트에 추가시킨다.
                {
                    LeadShapeWithCenterLineProperty leadWithCenterLineValue = new LeadShapeWithCenterLineProperty();

                    leadWithCenterLineValue.ThreshType = threshType;
                    leadWithCenterLineValue.LowerThresh = lowerThresh;
                    leadWithCenterLineValue.UpperThresh = upperThresh;
                    leadWithCenterLineValue.MinWidthRatio = minWidthRatio;
                    leadWithCenterLineValue.MinWidthSize = minWidthSize;
                    leadWithCenterLineValue.MaxWidthRatio = maxWidthRatio;
                    leadWithCenterLineValue.MaxWidthSize = maxWidthSize;
                    leadWithCenterLineValue.MinHeightsize = minHeightSize;
                    leadWithCenterLineValue.MinNormalRatio = minNormalRatio;
                    leadWithCenterLineValue.MaxNormalRatio = maxNormalRatio;

                    InspectionItem inspectionItem = new InspectionItem();
                    inspectionItem.ID = nMaxInspectID + 1;
                    inspectionItem.InspectionType = InspectionType.GetInspectionType(m_enumInspectType);
                    inspectionItem.InspectionAlgorithm = leadWithCenterLineValue;

                    if (inspectionItem.InspectionType != null)
                    {
                        graphic.InspectionList.Add(inspectionItem);
                    }
                }
                else
                {
                    oldLeadWithCenterLineValue.ThreshType = threshType;
                    oldLeadWithCenterLineValue.LowerThresh = lowerThresh;
                    oldLeadWithCenterLineValue.UpperThresh = upperThresh;
                    oldLeadWithCenterLineValue.MinWidthRatio = minWidthRatio;
                    oldLeadWithCenterLineValue.MinWidthSize = minWidthSize;
                    oldLeadWithCenterLineValue.MaxWidthRatio = maxWidthRatio;
                    oldLeadWithCenterLineValue.MaxWidthSize = maxWidthSize;
                    oldLeadWithCenterLineValue.MinHeightsize = minHeightSize;
                    oldLeadWithCenterLineValue.MinNormalRatio = minNormalRatio;
                    oldLeadWithCenterLineValue.MaxNormalRatio = maxNormalRatio;
                }
            }
            catch
            {
                MessageBox.Show("잘못 입력된 값이 존재합니다. 확인 바랍니다.", "Information");
                txtLowerThreshold.Focus();
            }
        }

        public void SetDefaultValue()
        {
            if (m_enumInspectType == eVisInspectType.eInspTypeLeadShapeWithCL)
            {
                if (!LeadShapeWithCenterLineDefaultValue.DefaultValueLoaded)
                {
                    LeadShapeWithCenterLineDefaultValue.DefaultValueLoaded = true;
                    LeadShapeWithCenterLineDefaultValue.LoadDefaultValue();
                }

                this.txtLowerThreshold.Text = LeadShapeWithCenterLineDefaultValue.LowerThresh.ToString();
                this.txtUpperThreshold.Text = LeadShapeWithCenterLineDefaultValue.UpperThresh.ToString();
                this.txtMinWidthRatio.Text = LeadShapeWithCenterLineDefaultValue.MinWidthRatio.ToString();
                this.txtMinWidthSize.Text = LeadShapeWithCenterLineDefaultValue.MinWidthSize.ToString();
                this.txtMaxWidthRatio.Text = LeadShapeWithCenterLineDefaultValue.MaxWidthRatio.ToString();
                this.txtMaxWidthSize.Text = LeadShapeWithCenterLineDefaultValue.MaxWidthSize.ToString();
                this.txtMinHeightSize.Text = LeadShapeWithCenterLineDefaultValue.MinHeightsize.ToString();
                this.txtMinNormalRatio.Text = LeadShapeWithCenterLineDefaultValue.MinNormalRatio.ToString();
                this.txtMaxNormalRatio.Text = LeadShapeWithCenterLineDefaultValue.MaxNormalRatio.ToString();
            }
        }

        public void Display(InspectionItem settingValue)
        {
            LeadShapeWithCenterLineProperty leadWithCenterLineValue = settingValue.InspectionAlgorithm as LeadShapeWithCenterLineProperty;
            if (leadWithCenterLineValue != null)
            {
                this.txtLowerThreshold.Text = leadWithCenterLineValue.LowerThresh.ToString();
                this.txtUpperThreshold.Text = leadWithCenterLineValue.UpperThresh.ToString();
                this.txtMinWidthRatio.Text = leadWithCenterLineValue.MinWidthRatio.ToString();
                this.txtMinWidthSize.Text = leadWithCenterLineValue.MinWidthSize.ToString();
                this.txtMaxWidthRatio.Text = leadWithCenterLineValue.MaxWidthRatio.ToString();
                this.txtMaxWidthSize.Text = leadWithCenterLineValue.MaxWidthSize.ToString();
                this.txtMinHeightSize.Text = leadWithCenterLineValue.MinHeightsize.ToString();
                this.txtMinNormalRatio.Text = leadWithCenterLineValue.MinNormalRatio.ToString();
                this.txtMaxNormalRatio.Text = leadWithCenterLineValue.MaxNormalRatio.ToString();
            }
        }
    }
}
