﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Common.Drawing.InspectionInformation;
using Common.DataBase;
using System.Data;

namespace Common.Drawing.InspectionTypeUI
{
    /// <summary>   Shape shift property.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
    public class ShapeShiftProperty : InspectionAlgorithm
    {
        public int ThreshType;              // 0000
        public int LowerThresh;             // 0001
        public int UpperThresh;             // 0002
        public int ApplyAverDiff;           // 0003
        public int MaskLowerThresh;         // 0004
        public int MaskUpperThresh;         // 0005
        public int InspRange;               // 0006
        public int AverMinMargin;           // 0007
        public int AverMaxMargin;           // 0008
        public int MinMargin;               // 0009
        public int MaxMargin;               // 0010
        public int ErosionTrainIter = 0;    // 0011
        public int DilationTrainIter = 0;   // 0012
        public int ErosionInspIter = 0;     // 0013
        public int DilationInspIter = 0;    // 0014
        public int MinDefectSize;           // 0015
        public int MinSmallDefectSize;      // 0016
        public int MinSmallDefectCount;     // 0017
        public int ErosionShapeIter;        // 0021  
        public int DilationShapeIter;       // 0022
        public int GroundLowerThresh;       // 0023
        public int GroundUpperThresh;       // 0024
        public int ShapeLowerThresh;        // 0025
        public int ShapeUpperThresh;        // 0026
        public int CorrectMethod;           // 0027
        public int ShapeShiftMarginX;       // 0028
        public int ShapeShiftMarginY;       // 0029

        public ShapeShiftProperty()
        {
            Code = "3005";
        }

        /// <summary>   Loads a property. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
        public override void LoadProperty(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID, string strInspectCode)
        {
            ThreshType          = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0000");
            LowerThresh         = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0001");
            UpperThresh         = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0002");
            ApplyAverDiff       = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0003");
            MaskLowerThresh     = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0004");
            MaskUpperThresh     = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0005");
            InspRange           = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0006");
            AverMinMargin       = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0007");
            AverMaxMargin       = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0008");
            MinMargin           = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0009");
            MaxMargin           = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0010");
            ErosionTrainIter    = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0011");
            DilationTrainIter   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0012");
            ErosionInspIter     = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0013");
            DilationInspIter    = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0014");
            MinDefectSize       = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0015");
            MinSmallDefectSize  = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0016");
            MinSmallDefectCount = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0017");
            ErosionShapeIter    = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0021");
            DilationShapeIter   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0022");
            GroundLowerThresh   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0023");
            GroundUpperThresh   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0024");
            ShapeLowerThresh    = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0025");
            ShapeUpperThresh    = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0026");
            CorrectMethod       = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0027");
            ShapeShiftMarginX   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0028");
            ShapeShiftMarginY   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0029");
        }

        /// <summary>   Saves a property. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
        public override int SaveProperty(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID, string strInspectCode)
        {
            try
            {
                if (ConnectFactory.DBConnector() != null)
                {
                    string strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0000", ThreshType);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    if (ThreshType == 0 || ThreshType == 2) // LowerThreshold 값은 임계이상, 임계범위인 경우에만 저장한다.
                    {
                        strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0001", LowerThresh);
                        if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    }
                    if (ThreshType == 1 || ThreshType == 2) // Upperthreshold 값은 임계이하, 임계범위인 경우에만 저장한다.
                    {
                        strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0002", UpperThresh);
                        if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    }
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0003", ApplyAverDiff);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0004", MaskLowerThresh);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0005", MaskUpperThresh);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0006", InspRange);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0007", AverMinMargin);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0008", AverMaxMargin);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0009", MinMargin);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0010", MaxMargin);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0011", ErosionTrainIter);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0012", DilationTrainIter);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0013", ErosionInspIter);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0014", DilationInspIter);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0015", MinDefectSize);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0016", MinSmallDefectSize);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0017", MinSmallDefectCount);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0021", ErosionShapeIter);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0022", DilationShapeIter);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0023", GroundLowerThresh);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0024", GroundUpperThresh);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0025", ShapeLowerThresh);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0026", ShapeUpperThresh);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0027", CorrectMethod);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0028", ShapeShiftMarginX);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0029", ShapeShiftMarginY);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                }
                else
                {
                    return -1;
                }
            }
            catch
            {
                return -1;
            }

            return 1; // Save Success !!!
        }

        /// <summary>   Makes a deep copy of this object. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
        /// <returns>   A copy of this object. </returns>
        public override InspectionAlgorithm Clone()
        {
            ShapeShiftProperty cloneShapeShift = new ShapeShiftProperty();

            cloneShapeShift.ThreshType = this.ThreshType;
            cloneShapeShift.LowerThresh = this.LowerThresh;
            cloneShapeShift.UpperThresh = this.UpperThresh;
            cloneShapeShift.ApplyAverDiff = this.ApplyAverDiff;
            cloneShapeShift.MaskLowerThresh = this.MaskLowerThresh;
            cloneShapeShift.MaskUpperThresh = this.MaskUpperThresh;
            cloneShapeShift.InspRange = this.InspRange;
            cloneShapeShift.AverMinMargin = this.AverMinMargin;
            cloneShapeShift.AverMaxMargin = this.AverMaxMargin;
            cloneShapeShift.MinMargin = this.MinMargin;
            cloneShapeShift.MaxMargin = this.MaxMargin;
            cloneShapeShift.ErosionTrainIter = this.ErosionTrainIter;
            cloneShapeShift.DilationTrainIter = this.DilationTrainIter;
            cloneShapeShift.ErosionInspIter = this.ErosionInspIter;
            cloneShapeShift.DilationInspIter = this.DilationInspIter;
            cloneShapeShift.MinDefectSize = this.MinDefectSize;
            cloneShapeShift.MinSmallDefectSize = this.MinSmallDefectSize;
            cloneShapeShift.MinSmallDefectCount = this.MinSmallDefectCount;
            cloneShapeShift.ErosionShapeIter = this.ErosionShapeIter;
            cloneShapeShift.DilationShapeIter = this.DilationShapeIter;
            cloneShapeShift.GroundLowerThresh = this.GroundLowerThresh;
            cloneShapeShift.GroundUpperThresh = this.GroundUpperThresh;
            cloneShapeShift.ShapeLowerThresh = this.ShapeLowerThresh;
            cloneShapeShift.ShapeUpperThresh = this.ShapeUpperThresh;
            cloneShapeShift.CorrectMethod = this.CorrectMethod;
            cloneShapeShift.ShapeShiftMarginX = this.ShapeShiftMarginX;
            cloneShapeShift.ShapeShiftMarginY = this.ShapeShiftMarginY;

            return cloneShapeShift;
        }
    }

    /// <summary>   Shape shift.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
    public partial class ShapeShift : UserControl, IInspectionTypeUICommands
    {
        #region Inspect Type
        public eVisInspectType InspectType
        {
            get
            {
                return m_enumInspectType;
            }
        }
        private eVisInspectType m_enumInspectType;
        #endregion

        /// <summary> The default correct method </summary>
        private static int DEFAULT_CORRECT_METHOD = 0;

        /// <summary>   Initializes a new instance of the ShapeShift class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-10. </remarks>
        public ShapeShift()
        {
            InitializeComponent();
            InitializeEvent();

            this.radThresholdRange.IsChecked = true;
            this.chkMinRange.IsChecked = true;
            this.chkMaxRange.IsChecked = true;
            this.chkSameValue.IsChecked = false;
            SetRadioState2();

            this.Loaded += new RoutedEventHandler(ShapeShift_Loaded);
        }

        private void ShapeShift_Loaded(object sender, RoutedEventArgs e)
        {
            this.SetFocus();
        }

        private void InitializeEvent()
        {
            this.radThresholdLower.Click += radThreshold_Click;
            this.radThresholdUpper.Click += radThreshold_Click;
            this.radThresholdRange.Click += new RoutedEventHandler(radThresholdRange_Click);
            this.chkSameValue.Click += new RoutedEventHandler(chkSameValue_Click);
            this.txtThreshold.TextChanged += new TextChangedEventHandler(txtThreshold_TextChanged);
            this.txtLowerThreshold.TextChanged += new TextChangedEventHandler(txtLowerThreshold_TextChanged);
            this.txtUpperThreshold.TextChanged += new TextChangedEventHandler(txtUpperThreshold_TextChanged);
            this.txtMaskLowerThresh.TextChanged += new TextChangedEventHandler(txtMaskLowerThresh_TextChanged);
            this.txtMaskUpperThresh.TextChanged += new TextChangedEventHandler(txtMaskUpperThresh_TextChanged);
        }

        #region Textbox text changed events.
        private void txtThreshold_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (chkSameValue.IsChecked == true)
            {
                if (radThresholdLower.IsChecked == true)
                {
                    txtMaskLowerThresh.Text = "0";
                    txtMaskUpperThresh.Text = txtThreshold.Text;
                }
                else if (radThresholdUpper.IsChecked == true)
                {
                    txtMaskLowerThresh.Text = txtThreshold.Text;
                    txtMaskUpperThresh.Text = "255";
                }
            }
        }

        private void txtUpperThreshold_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (chkSameValue.IsChecked == true)
            {
                txtMaskUpperThresh.Text = txtUpperThreshold.Text;
            }
        }

        private void txtLowerThreshold_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (chkSameValue.IsChecked == true)
            {
                txtMaskLowerThresh.Text = txtLowerThreshold.Text;
            }
        }

        private void txtMaskUpperThresh_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (chkSameValue.IsChecked == true)
            {
                txtUpperThreshold.Text = txtMaskUpperThresh.Text;
            }
        }

        private void txtMaskLowerThresh_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (chkSameValue.IsChecked == true)
            {
                txtLowerThreshold.Text = txtMaskLowerThresh.Text;
            }
        }
        #endregion

        private void chkSameValue_Click(object sender, RoutedEventArgs e)
        {            
            if (radThresholdUpper.IsChecked == true)
            {
                this.chkMinRange.IsChecked = true;
                this.chkMaxRange.IsChecked = false;
                if (chkSameValue.IsChecked == true)
                {
                    this.txtMaskLowerThresh.Text = this.txtThreshold.Text;
                    this.txtMaskUpperThresh.Text = "255";
                }
            }
            else if (radThresholdLower.IsChecked == true)
            {
                this.chkMinRange.IsChecked = false;
                this.chkMaxRange.IsChecked = true;
                if (chkSameValue.IsChecked == true)
                {
                    this.txtMaskLowerThresh.Text = "0";
                    this.txtMaskUpperThresh.Text = this.txtThreshold.Text;
                }
            }
            else //radThresholdRange.IsChecked == true
            {
                this.chkMinRange.IsChecked = true;
                this.chkMaxRange.IsChecked = true;
                if (chkSameValue.IsChecked == true)
                {
                    this.txtMaskLowerThresh.Text = this.txtLowerThreshold.Text;
                    this.txtMaskUpperThresh.Text = this.txtUpperThreshold.Text;
                }
            }
        }

        #region Radio button events.
        /// <summary>   Event handler. Called by radThreshold for click events. </summary>
        /// <remarks>   Minseok, Hwang, 2011-09-28. </remarks>
        /// <param name="sender">   Source of the event. </param>
        /// <param name="e">        Routed event information. </param>
        private void radThreshold_Click(object sender, RoutedEventArgs e)
        {
            SetRadioState1();
            this.txtThreshold.Focus();

            chkSameValue_Click(null, null);
        }

        /// <summary>   Event handler. Called by radThresholdLower for click events. </summary>
        /// <remarks>   Minseok, Hwang, 2011-09-28. </remarks>
        /// <param name="sender">   Source of the event. </param>
        /// <param name="e">        Routed event information. </param>
        private void radThresholdRange_Click(object sender, RoutedEventArgs e)
        {
            SetRadioState2();
            this.txtLowerThreshold.Focus();

            chkSameValue_Click(null, null);
        }
        #endregion

        private void SetRadioState1()
        {
            this.txtLowerGV.Visibility = Visibility.Collapsed;
            this.txtLowerThreshold.Visibility = Visibility.Collapsed;
            this.txtUpperGV.Visibility = Visibility.Collapsed;
            this.txtUpperThreshold.Visibility = Visibility.Collapsed;

            this.txtThreshold.Visibility = Visibility.Visible;
            this.txtGV.Visibility = Visibility.Visible;
        }

        private void SetRadioState2()
        {
            this.txtLowerGV.Visibility = Visibility.Visible;
            this.txtLowerThreshold.Visibility = Visibility.Visible;
            this.txtUpperGV.Visibility = Visibility.Visible;
            this.txtUpperThreshold.Visibility = Visibility.Visible;

            this.txtThreshold.Visibility = Visibility.Collapsed;
            this.txtGV.Visibility = Visibility.Collapsed;
        }

        public void SetFocus()
        {
            if (this.radThresholdRange.IsChecked == true)
            {
                SetRadioState2();
                this.txtLowerThreshold.Focus();
            }
            else
            {
                SetRadioState1();
                this.txtThreshold.Focus();
            }
        }

        public void SetDialog(string strCaption, InspectionInformation.eVisInspectType inspectType)
        {
            this.txtCaption.Text = strCaption;
            this.m_enumInspectType = inspectType;
        }

        public void TrySave(GraphicsBase graphic, int anInspectID)
        {
            try
            {
                #region Check 하한 / 상한 검출값
                int threshType = 0;
                int lowerThresh = -1;
                int upperThresh = -1;
                if (radThresholdUpper.IsChecked == true) // 임계 이상
                {
                    threshType = 0;
                    lowerThresh = Convert.ToInt32(txtThreshold.Text);
                    upperThresh = 255;
                }
                else if (radThresholdLower.IsChecked == true) // 임계 이하
                {
                    threshType = 1;
                    lowerThresh = 0;
                    upperThresh = Convert.ToInt32(txtThreshold.Text);
                }
                else if (radThresholdRange.IsChecked == true) // 임계 범위
                {
                    threshType = 2;
                    lowerThresh = Convert.ToInt32(txtLowerThreshold.Text);
                    upperThresh = Convert.ToInt32(txtUpperThreshold.Text);

                    if (lowerThresh > upperThresh)
                    {
                        MessageBox.Show("임계 하한 값은 임계 상한 값을 초과할 수 없습니다.", "Information");
                        this.txtLowerThreshold.Focus();
                        return;
                    }
                }
                #endregion

                int applyAverDiff = (chkApplyAverDiff.IsChecked == true) ? 1 : 0;

                #region Check 마스크 임계값
                int maskLowerThresh = Convert.ToInt32(txtMaskLowerThresh.Text);
                int maskUpperThresh = Convert.ToInt32(txtMaskUpperThresh.Text);

                if (maskLowerThresh > maskUpperThresh)
                {
                    MessageBox.Show("마스크 임계하한 값은 마스크 임계상한 값을 초과할 수 없습니다.", "Information");
                    this.txtMaskLowerThresh.Focus();
                    return;
                }
                #endregion

                int inspRange = 0;
                if (this.chkMinRange.IsChecked == true)
                {
                    inspRange += 1;
                }
                if (this.chkMaxRange.IsChecked == true)
                {
                    inspRange += 2;
                }
                if (this.chkInRange.IsChecked == true)
                {
                    inspRange += 4;
                }

                #region Check 평균값 최소 / 최대 허용범위
                int averMinMargin = Convert.ToInt32(txtAverMinMargin.Text);
                int averMaxMargin = Convert.ToInt32(txtAverMaxMargin.Text);

                //if (averMinMargin > averMaxMargin)
                //{
                //    MessageBox.Show("평균값 최소 허용범위는 평균값 최대 허용범위를 초과할 수 없습니다.", "Information");
                //    this.txtAverMinMargin.Focus();
                //    return;
                //}
                #endregion

                #region Check 검사 최소 / 최대 허용범위
                int minMargin = Convert.ToInt32(txtMinMargin.Text);
                int maxMargin = Convert.ToInt32(txtMaxMargin.Text);

                //if (minMargin > maxMargin)
                //{
                //    MessageBox.Show("검사 최소 허용범위는 검사 최대 허용범위를 초과할 수 없습니다.", "Information");
                //    this.txtMinMargin.Focus();
                //    return;
                //}
                #endregion

                int erosionTrainIter = Convert.ToInt32(txtErosionTrainIter.Text);
                int dilationTrainIter = Convert.ToInt32(txtDilationTrainIter.Text);
                int erosionInspIter = Convert.ToInt32(txtErosionInspIter.Text);
                int dilationInspIter = Convert.ToInt32(txtDilationInspIter.Text);
                int minDefectSize = Convert.ToInt32(txtMinDefectSize.Text);
                int minSmallDefectSize = Convert.ToInt32(txtMinSmallDefectCount.Text);
                int minSmallDefectCount = Convert.ToInt32(txtMinSmallDefectCount.Text);
                int erosionShapeIter = Convert.ToInt32(txtErosionShapeIter.Text);
                int dilationShapeIter = Convert.ToInt32(txtDilationShapeIter.Text);

                #region Check 전체 Mask 하한 / 상한
                int groundLowerThresh = Convert.ToInt32(txtGroundLowerThresh.Text);
                int groundUpperThresh = Convert.ToInt32(txtGroundUpperThresh.Text);
                if (groundLowerThresh > groundUpperThresh)
                {
                    MessageBox.Show("전체 Mask 하한 값은 전체 Mask 상한 값을 초과할 수 없습니다.", "Information");
                    this.txtGroundLowerThresh.Focus();
                    return;
                }
                #endregion

                #region Check 형상 Mask 하한 / 상한
                int shapeLowerThresh = Convert.ToInt32(txtShapeLowerThresh.Text);
                int shapeUpperThresh = Convert.ToInt32(txtShapeUpperThresh.Text);
                if (shapeLowerThresh > shapeUpperThresh)
                {
                    MessageBox.Show("형상 Mask 하한 값은 형상 Mask 상한 값을 초과할 수 없습니다.", "Information");
                    this.txtShapeLowerThresh.Focus();
                    return;
                }
                #endregion

                int shapeShiftMarginX = Convert.ToInt32(txtShapeShiftMarginX.Text);
                int shapeShiftMarginY = Convert.ToInt32(txtShapeShiftMarginY.Text);
                int correctMethod = DEFAULT_CORRECT_METHOD;

                ShapeShiftProperty oldShapeShiftValue = null;
                foreach (InspectionItem element in graphic.InspectionList)
                {
                    if (element.ID == anInspectID)
                    {
                        oldShapeShiftValue = element.InspectionAlgorithm as ShapeShiftProperty; // 기존에 저장된 값이 있는 경우.
                        break;
                    }
                }

                int nMaxInspectID = -1;
                foreach (InspectionItem element in graphic.InspectionList)
                {
                    if (nMaxInspectID < element.ID)
                        nMaxInspectID = element.ID;
                }

                if (oldShapeShiftValue == null) // 기존에 저장된 값이 없는 경우, 새로 리스트에 추가시킨다.
                {
                    ShapeShiftProperty shapeShiftValue = new ShapeShiftProperty();

                    shapeShiftValue.ThreshType = threshType;
                    shapeShiftValue.LowerThresh = lowerThresh;
                    shapeShiftValue.UpperThresh = upperThresh;
                    shapeShiftValue.ApplyAverDiff = applyAverDiff;
                    shapeShiftValue.MaskLowerThresh = maskLowerThresh;
                    shapeShiftValue.MaskUpperThresh = maskUpperThresh;
                    shapeShiftValue.InspRange = inspRange;
                    shapeShiftValue.AverMinMargin = averMinMargin;
                    shapeShiftValue.AverMaxMargin = averMaxMargin;
                    shapeShiftValue.MinMargin = minMargin;
                    shapeShiftValue.MaxMargin = maxMargin;
                    shapeShiftValue.ErosionTrainIter = erosionTrainIter;
                    shapeShiftValue.DilationTrainIter = dilationTrainIter;
                    shapeShiftValue.ErosionInspIter = erosionInspIter;
                    shapeShiftValue.DilationInspIter = dilationInspIter;
                    shapeShiftValue.MinDefectSize = minDefectSize;
                    shapeShiftValue.MinSmallDefectSize = minSmallDefectSize;
                    shapeShiftValue.MinSmallDefectCount = minSmallDefectCount;
                    shapeShiftValue.ErosionShapeIter = erosionShapeIter;
                    shapeShiftValue.DilationShapeIter = dilationShapeIter;
                    shapeShiftValue.GroundLowerThresh = groundLowerThresh;
                    shapeShiftValue.GroundUpperThresh = groundUpperThresh;
                    shapeShiftValue.ShapeLowerThresh = shapeLowerThresh;
                    shapeShiftValue.ShapeUpperThresh = shapeUpperThresh;
                    shapeShiftValue.CorrectMethod = correctMethod;
                    shapeShiftValue.ShapeShiftMarginX = shapeShiftMarginX;
                    shapeShiftValue.ShapeShiftMarginY = shapeShiftMarginY;

                    InspectionItem inspectionItem = new InspectionItem();
                    inspectionItem.ID = nMaxInspectID + 1;
                    inspectionItem.InspectionType = InspectionType.GetInspectionType(m_enumInspectType);
                    inspectionItem.InspectionAlgorithm = shapeShiftValue;

                    if (inspectionItem.InspectionType != null)
                    {
                        graphic.InspectionList.Add(inspectionItem);
                    }
                }
                else
                {
                    oldShapeShiftValue.ThreshType = threshType;
                    oldShapeShiftValue.LowerThresh = lowerThresh;
                    oldShapeShiftValue.UpperThresh = upperThresh;
                    oldShapeShiftValue.ApplyAverDiff = applyAverDiff;
                    oldShapeShiftValue.MaskLowerThresh = maskLowerThresh;
                    oldShapeShiftValue.MaskUpperThresh = maskUpperThresh;
                    oldShapeShiftValue.InspRange = inspRange;
                    oldShapeShiftValue.AverMinMargin = averMinMargin;
                    oldShapeShiftValue.AverMaxMargin = averMaxMargin;
                    oldShapeShiftValue.MinMargin = minMargin;
                    oldShapeShiftValue.MaxMargin = maxMargin;
                    oldShapeShiftValue.ErosionTrainIter = erosionTrainIter;
                    oldShapeShiftValue.DilationTrainIter = dilationTrainIter;
                    oldShapeShiftValue.ErosionInspIter = erosionInspIter;
                    oldShapeShiftValue.DilationInspIter = dilationInspIter;
                    oldShapeShiftValue.MinDefectSize = minDefectSize;
                    oldShapeShiftValue.MinSmallDefectSize = minSmallDefectSize;
                    oldShapeShiftValue.MinSmallDefectCount = minSmallDefectCount;
                    oldShapeShiftValue.ErosionShapeIter = erosionShapeIter;
                    oldShapeShiftValue.DilationShapeIter = dilationShapeIter;
                    oldShapeShiftValue.GroundLowerThresh = groundLowerThresh;
                    oldShapeShiftValue.GroundUpperThresh = groundUpperThresh;
                    oldShapeShiftValue.ShapeLowerThresh = shapeLowerThresh;
                    oldShapeShiftValue.ShapeUpperThresh = shapeUpperThresh;
                    oldShapeShiftValue.CorrectMethod = correctMethod;
                    oldShapeShiftValue.ShapeShiftMarginX = shapeShiftMarginX;
                    oldShapeShiftValue.ShapeShiftMarginY = shapeShiftMarginY;
                }
            }
            catch
            {
                MessageBox.Show("잘못 입력된 값이 존재합니다. 확인 바랍니다.", "Information");
                if (txtThreshold.Visibility == Visibility.Visible)
                {
                    txtThreshold.Focus();
                }
                else
                {
                    txtLowerThreshold.Focus();
                }
            }
        }

        public void SetDefaultValue()
        {
            if (m_enumInspectType == eVisInspectType.eInspTypeTape)
            {
                if (!TapeDefaultValue.DefaultValueLoaded)
                {
                    TapeDefaultValue.DefaultValueLoaded = true;
                    TapeDefaultValue.LoadDefaultValue();
                }

                if (TapeDefaultValue.ThreshType == 0)
                {
                    SetRadioState1();
                    this.radThresholdUpper.IsChecked = true;
                    this.chkMinRange.IsChecked = true;
                    this.chkMaxRange.IsChecked = false;
                    this.txtThreshold.Text = TapeDefaultValue.UpperThresh.ToString();
                    this.txtLowerThreshold.Text = TapeDefaultValue.LowerThresh.ToString();
                    this.txtUpperThreshold.Text = TapeDefaultValue.UpperThresh.ToString();
                }
                else if (TapeDefaultValue.ThreshType == 1)
                {
                    SetRadioState1();
                    this.radThresholdLower.IsChecked = true;
                    this.chkMinRange.IsChecked = false;
                    this.chkMaxRange.IsChecked = true;
                    this.txtThreshold.Text = TapeDefaultValue.LowerThresh.ToString();
                    this.txtLowerThreshold.Text = TapeDefaultValue.LowerThresh.ToString();
                    this.txtUpperThreshold.Text = TapeDefaultValue.UpperThresh.ToString();
                }
                else
                {
                    this.radThresholdRange.IsChecked = true;
                    this.chkMinRange.IsChecked = true;
                    this.chkMaxRange.IsChecked = true;
                    this.txtLowerThreshold.Text = TapeDefaultValue.LowerThresh.ToString();
                    this.txtUpperThreshold.Text = TapeDefaultValue.UpperThresh.ToString();
                    this.txtThreshold.Text = TapeDefaultValue.LowerThresh.ToString();
                }
                this.chkApplyAverDiff.IsChecked = (TapeDefaultValue.ApplyAverDiff == 1) ? true : false;
                this.txtMaskLowerThresh.Text = TapeDefaultValue.MaskLowerThresh.ToString();
                this.txtMaskUpperThresh.Text = TapeDefaultValue.MaskUpperThresh.ToString();
                this.SetCheckBoxState(TapeDefaultValue.InspRange);
                this.txtAverMinMargin.Text = TapeDefaultValue.AverMinMargin.ToString();
                this.txtAverMaxMargin.Text = TapeDefaultValue.AverMaxMargin.ToString();
                this.txtMinMargin.Text = TapeDefaultValue.MinMargin.ToString();
                this.txtMaxMargin.Text = TapeDefaultValue.MaxMargin.ToString();
                this.txtErosionTrainIter.Text = TapeDefaultValue.ErosionTrainIter.ToString();
                this.txtDilationTrainIter.Text = TapeDefaultValue.DilationTrainIter.ToString();
                this.txtErosionInspIter.Text = TapeDefaultValue.ErosionInspIter.ToString();
                this.txtDilationInspIter.Text = TapeDefaultValue.DilationInspIter.ToString();
                this.txtMinDefectSize.Text = TapeDefaultValue.MinDefectSize.ToString();
                this.txtMinSmallDefectSize.Text = TapeDefaultValue.MinSmallDefectSize.ToString();
                this.txtMinSmallDefectCount.Text = TapeDefaultValue.MinSmallDefectCount.ToString();
                this.txtErosionShapeIter.Text = TapeDefaultValue.ErosionShapeIter.ToString();
                this.txtDilationShapeIter.Text = TapeDefaultValue.DilationShapeIter.ToString();
                this.txtGroundLowerThresh.Text = TapeDefaultValue.GroundLowerThresh.ToString();
                this.txtGroundUpperThresh.Text = TapeDefaultValue.GroundUpperThresh.ToString();
                this.txtShapeLowerThresh.Text = TapeDefaultValue.ShapeLowerThresh.ToString();
                this.txtShapeUpperThresh.Text = TapeDefaultValue.ShapeUpperThresh.ToString();
                this.txtShapeShiftMarginX.Text = TapeDefaultValue.ShapeShiftMarginX.ToString();
                this.txtShapeShiftMarginY.Text = TapeDefaultValue.ShapeShiftMarginY.ToString();
            }
            else if (m_enumInspectType == eVisInspectType.eInspTypePlate)
            {
                if (!PlateDefaultValue.DefaultValueLoaded)
                {
                    PlateDefaultValue.DefaultValueLoaded = true;
                    PlateDefaultValue.LoadDefaultValue();
                }

                if (PlateDefaultValue.ThreshType == 0)
                {
                    SetRadioState1();
                    this.radThresholdUpper.IsChecked = true;
                    this.txtThreshold.Text = PlateDefaultValue.UpperThresh.ToString();
                    this.txtLowerThreshold.Text = PlateDefaultValue.LowerThresh.ToString();
                    this.txtUpperThreshold.Text = PlateDefaultValue.UpperThresh.ToString();
                }
                else if (PlateDefaultValue.ThreshType == 1)
                {
                    SetRadioState1();
                    this.radThresholdLower.IsChecked = true;
                    this.txtThreshold.Text = PlateDefaultValue.LowerThresh.ToString();
                    this.txtLowerThreshold.Text = PlateDefaultValue.LowerThresh.ToString();
                    this.txtUpperThreshold.Text = PlateDefaultValue.UpperThresh.ToString();
                }
                else
                {
                    this.radThresholdRange.IsChecked = true;
                    this.txtLowerThreshold.Text = PlateDefaultValue.LowerThresh.ToString();
                    this.txtUpperThreshold.Text = PlateDefaultValue.UpperThresh.ToString();
                    this.txtThreshold.Text = PlateDefaultValue.LowerThresh.ToString();
                }
                this.chkApplyAverDiff.IsChecked = (PlateDefaultValue.ApplyAverDiff == 1) ? true : false;
                this.txtMaskLowerThresh.Text = PlateDefaultValue.MaskLowerThresh.ToString();
                this.txtMaskUpperThresh.Text = PlateDefaultValue.MaskUpperThresh.ToString();
                this.SetCheckBoxState(PlateDefaultValue.InspRange);
                this.txtAverMinMargin.Text = PlateDefaultValue.AverMinMargin.ToString();
                this.txtAverMaxMargin.Text = PlateDefaultValue.AverMaxMargin.ToString();
                this.txtMinMargin.Text = PlateDefaultValue.MinMargin.ToString();
                this.txtMaxMargin.Text = PlateDefaultValue.MaxMargin.ToString();
                this.txtErosionTrainIter.Text = PlateDefaultValue.ErosionTrainIter.ToString();
                this.txtDilationTrainIter.Text = PlateDefaultValue.DilationTrainIter.ToString();
                this.txtErosionInspIter.Text = PlateDefaultValue.ErosionInspIter.ToString();
                this.txtDilationInspIter.Text = PlateDefaultValue.DilationInspIter.ToString();
                this.txtMinDefectSize.Text = PlateDefaultValue.MinDefectSize.ToString();
                this.txtMinSmallDefectSize.Text = PlateDefaultValue.MinSmallDefectSize.ToString();
                this.txtMinSmallDefectCount.Text = PlateDefaultValue.MinSmallDefectCount.ToString();
                this.txtErosionShapeIter.Text = PlateDefaultValue.ErosionShapeIter.ToString();
                this.txtDilationShapeIter.Text = PlateDefaultValue.DilationShapeIter.ToString();
                this.txtGroundLowerThresh.Text = PlateDefaultValue.GroundLowerThresh.ToString();
                this.txtGroundUpperThresh.Text = PlateDefaultValue.GroundUpperThresh.ToString();
                this.txtShapeLowerThresh.Text = PlateDefaultValue.ShapeLowerThresh.ToString();
                this.txtShapeUpperThresh.Text = PlateDefaultValue.ShapeUpperThresh.ToString();
                this.txtShapeShiftMarginX.Text = PlateDefaultValue.ShapeShiftMarginX.ToString();
                this.txtShapeShiftMarginY.Text = PlateDefaultValue.ShapeShiftMarginY.ToString();
            }
        }

        /// <summary>   Sets a check box state. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-19. </remarks>
        /// <param name="switchValue">  The switch value. </param>
        private void SetCheckBoxState(int switchValue)
        {
            switch (switchValue)
            {
                case 1:
                    this.chkMinRange.IsChecked = true; // 1
                    this.chkMaxRange.IsChecked = false;
                    this.chkInRange.IsChecked = false;
                    break;
                case 2:
                    this.chkMinRange.IsChecked = false;
                    this.chkMaxRange.IsChecked = true; // 2
                    this.chkInRange.IsChecked = false;
                    break;
                case 3:
                    this.chkMinRange.IsChecked = true;
                    this.chkMaxRange.IsChecked = true; // 1 + 2
                    this.chkInRange.IsChecked = false;
                    break;
                case 4:
                    this.chkMinRange.IsChecked = false;
                    this.chkMaxRange.IsChecked = false;
                    this.chkInRange.IsChecked = true; // 4
                    break;
                case 5:
                    this.chkMinRange.IsChecked = true;
                    this.chkMaxRange.IsChecked = false;
                    this.chkInRange.IsChecked = true; // 1 + 4
                    break;
                case 6:
                    this.chkMinRange.IsChecked = false;
                    this.chkMaxRange.IsChecked = true;
                    this.chkInRange.IsChecked = true; // 2 + 4
                    break;
                case 7:
                    this.chkMinRange.IsChecked = true;
                    this.chkMaxRange.IsChecked = true;
                    this.chkInRange.IsChecked = true; // 1 + 2 + 4
                    break;
            }
        }

        public void Display(InspectionItem settingValue)
        {
            ShapeShiftProperty shapeShiftProperty = settingValue.InspectionAlgorithm as ShapeShiftProperty;
            if (shapeShiftProperty != null)
            {
                if (shapeShiftProperty.ThreshType == 0) // 임계 이상
                {
                    SetRadioState1();
                    this.radThresholdUpper.IsChecked = true;
                    this.txtThreshold.Text = shapeShiftProperty.LowerThresh.ToString();
                    this.txtLowerThreshold.Text = shapeShiftProperty.LowerThresh.ToString();
                    this.txtUpperThreshold.Text = shapeShiftProperty.UpperThresh.ToString();
                }
                else if (shapeShiftProperty.ThreshType == 1) // 임계 이하
                {
                    SetRadioState1();
                    this.radThresholdLower.IsChecked = true;
                    this.txtThreshold.Text = shapeShiftProperty.UpperThresh.ToString();
                    this.txtLowerThreshold.Text = shapeShiftProperty.LowerThresh.ToString();
                    this.txtUpperThreshold.Text = shapeShiftProperty.UpperThresh.ToString();
                }
                else // 임계 범위
                {
                    SetRadioState2();
                    this.radThresholdRange.IsChecked = true;
                    this.txtLowerThreshold.Text = shapeShiftProperty.LowerThresh.ToString();
                    this.txtUpperThreshold.Text = shapeShiftProperty.UpperThresh.ToString();
                    this.txtThreshold.Text = shapeShiftProperty.LowerThresh.ToString();
                }
                this.chkApplyAverDiff.IsChecked = (shapeShiftProperty.ApplyAverDiff == 1) ? true : false;
                this.chkSameValue.IsChecked = false;
                this.txtMaskLowerThresh.Text = shapeShiftProperty.MaskLowerThresh.ToString();
                this.txtMaskUpperThresh.Text = shapeShiftProperty.MaskUpperThresh.ToString();
                this.SetCheckBoxState(shapeShiftProperty.InspRange);
                this.txtAverMinMargin.Text = shapeShiftProperty.AverMinMargin.ToString();
                this.txtAverMaxMargin.Text = shapeShiftProperty.AverMaxMargin.ToString();
                this.txtMinMargin.Text = shapeShiftProperty.MinMargin.ToString();
                this.txtMaxMargin.Text = shapeShiftProperty.MaxMargin.ToString();
                this.txtErosionTrainIter.Text = shapeShiftProperty.ErosionTrainIter.ToString();
                this.txtDilationTrainIter.Text = shapeShiftProperty.DilationTrainIter.ToString();
                this.txtErosionInspIter.Text = shapeShiftProperty.ErosionInspIter.ToString();
                this.txtDilationInspIter.Text = shapeShiftProperty.DilationInspIter.ToString();
                this.txtMinDefectSize.Text = shapeShiftProperty.MinDefectSize.ToString();
                this.txtMinSmallDefectSize.Text = shapeShiftProperty.MinSmallDefectSize.ToString();
                this.txtMinSmallDefectCount.Text = shapeShiftProperty.MinSmallDefectCount.ToString();
                this.txtErosionShapeIter.Text = shapeShiftProperty.ErosionShapeIter.ToString();
                this.txtDilationShapeIter.Text = shapeShiftProperty.DilationShapeIter.ToString();
                this.txtGroundLowerThresh.Text = shapeShiftProperty.GroundLowerThresh.ToString();
                this.txtGroundUpperThresh.Text = shapeShiftProperty.GroundUpperThresh.ToString();
                this.txtShapeLowerThresh.Text = shapeShiftProperty.ShapeLowerThresh.ToString();
                this.txtShapeUpperThresh.Text = shapeShiftProperty.ShapeUpperThresh.ToString();
                this.txtShapeShiftMarginX.Text = shapeShiftProperty.ShapeShiftMarginX.ToString();
                this.txtShapeShiftMarginY.Text = shapeShiftProperty.ShapeShiftMarginY.ToString();
            }
        }
    }
}
