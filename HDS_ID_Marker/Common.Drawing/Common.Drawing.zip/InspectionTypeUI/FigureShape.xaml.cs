﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Common.Drawing.InspectionInformation;
using Common.DataBase;
using System.Data;

namespace Common.Drawing.InspectionTypeUI
{
    /// <summary>   Figure shape property.  </summary>
    /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
    public class FigureShapeProperty : InspectionAlgorithm
    {
        public int InspRange;               // 0006
        public int AverMinMargin;           // 0007
        public int AverMaxMargin;           // 0008
        public int MinMargin;               // 0009
        public int MaxMargin;               // 0010
        public int ErosionTrainIter;        // 0011
        public int DilationTrainIter;       // 0012
        public int ErosionInspIter;         // 0013
        public int DilationInspIter;        // 0014
        public int MinWidthSize;            // 0031
        public int MinHeightSize;           // 0035
        public int MinNormalRatio;          // 0038
        public int MaxNormalRatio;          // 0039
        public int AlignMaxDist;            // 0046
        public int DarkAreaWidth;           // 0047

        public FigureShapeProperty()
        {
            Code = "3010";
        }

        /// <summary>   Loads a property. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
        public override void LoadProperty(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID, string strInspectCode)
        {
            InspRange           = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0006");
            AverMinMargin       = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0007");
            AverMaxMargin       = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0008");
            MinMargin           = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0009");
            MaxMargin           = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0010");
            ErosionTrainIter    = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0011");
            DilationTrainIter   = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0012");
            ErosionInspIter     = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0013");
            DilationInspIter    = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0014");
            MinWidthSize        = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0031");
            MinHeightSize       = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0035");
            MinNormalRatio      = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0038");
            MaxNormalRatio      = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0039");
            AlignMaxDist        = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0046");
            DarkAreaWidth       = InspectionQueryHelper.GetParamValue(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, this.Code, "0047");
        }

        /// <summary>   Saves a property. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
        public override int SaveProperty(string strMachineCode, string strModelCode, string strWorkType, string strSectionCode, string strRoiCode, string strInspectID, string strInspectCode)
        {
            try
            {
                if (ConnectFactory.DBConnector() != null)
                {
                    string strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0006", InspRange);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0007", AverMinMargin);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0008", AverMaxMargin);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                    
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0009", MinMargin);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0010", MaxMargin);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                  
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0011", ErosionTrainIter);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                  
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0012", DilationTrainIter);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0013", ErosionInspIter);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0014", DilationInspIter);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0031", MinWidthSize);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                  
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0035", MinHeightSize);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                    
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0038", MinNormalRatio);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0039", MaxNormalRatio);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0046", AlignMaxDist);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;                                                   
                    strQuery = InspectionQueryHelper.GetInsertQuery(strMachineCode, strModelCode, strWorkType, strSectionCode, strRoiCode, strInspectID, strInspectCode, Code, "0047", DarkAreaWidth);
                    if (ConnectFactory.DBConnector().Execute(strQuery) < 1) return -1;
                }
                else
                {
                    return -1;
                }
            }
            catch
            {
                return -1;
            }

            return 1; // Save Success !!!
        }

        /// <summary>   Makes a deep copy of this object. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-20. </remarks>
        /// <returns>   A copy of this object. </returns>
        public override InspectionAlgorithm Clone()
        {
            FigureShapeProperty cloneFigureShape = new FigureShapeProperty();

            cloneFigureShape.InspRange = this.InspRange;
            cloneFigureShape.AverMinMargin = this.AverMinMargin;
            cloneFigureShape.AverMaxMargin = this.AverMaxMargin;
            cloneFigureShape.MinMargin = this.MinMargin;
            cloneFigureShape.MaxMargin = this.MaxMargin;
            cloneFigureShape.ErosionTrainIter = this.ErosionTrainIter;
            cloneFigureShape.DilationTrainIter = this.DilationTrainIter;
            cloneFigureShape.ErosionInspIter = this.ErosionInspIter;
            cloneFigureShape.DilationInspIter = this.DilationInspIter;
            cloneFigureShape.MinWidthSize = this.MinWidthSize;
            cloneFigureShape.MinHeightSize = this.MinHeightSize;
            cloneFigureShape.MinNormalRatio = this.MinNormalRatio;
            cloneFigureShape.MaxNormalRatio = this.MaxNormalRatio;
            cloneFigureShape.AlignMaxDist = this.AlignMaxDist;
            cloneFigureShape.DarkAreaWidth = this.DarkAreaWidth;

            return cloneFigureShape;
        }
    }

    public partial class FigureShape : UserControl, IInspectionTypeUICommands
    {
        #region Inspect Type
        public eVisInspectType InspectType
        {
            get
            {
                return m_enumInspectType;
            }
        }
        private eVisInspectType m_enumInspectType;
        #endregion

        public FigureShape()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(FigureShape_Loaded);
        }

        private void FigureShape_Loaded(object sender, RoutedEventArgs e)
        {
            this.SetFocus();
        }

        public void SetDialog(string strCaption, InspectionInformation.eVisInspectType inspectType)
        {
            this.txtCaption.Text = strCaption;
            this.m_enumInspectType = inspectType;
        }

        public void SetFocus()
        {
            this.txtAverMinMargin.Focus();
        }

        public void TrySave(GraphicsBase graphic, int anInspectID)
        {
            try
            {
                #region Check 평균값 최소 / 최대 허용범위
                int averMinMargin = Convert.ToInt32(txtAverMinMargin.Text);
                int averMaxMargin = Convert.ToInt32(txtAverMaxMargin.Text);

                //if (averMinMargin > averMaxMargin)
                //{
                //    MessageBox.Show("평균값 최소 허용범위는 평균값 최대 허용범위를 초과할 수 없습니다.", "Information");
                //    this.txtAverMinMargin.Focus();
                //    return;
                //}
                #endregion

                #region Check 검사 최소 / 최대 허용범위
                int inspRange = 0;
                if (this.chkMinRange.IsChecked == true)
                {
                    inspRange += 1;
                }
                if (this.chkMaxRange.IsChecked == true)
                {
                    inspRange += 2;
                }
                if (this.chkInRange.IsChecked == true)
                {
                    inspRange += 4;
                }

                int minMargin = Convert.ToInt32(txtMinMargin.Text);
                int maxMargin = Convert.ToInt32(txtMaxMargin.Text);

                //if (minMargin > maxMargin)
                //{
                //    MessageBox.Show("검사 최소 허용범위는 검사 최대 허용범위를 초과할 수 없습니다.", "Information");
                //    this.txtMinMargin.Focus();
                //    return;
                //}
                #endregion

                int erosionTrainIter = Convert.ToInt32(txtErosionTrainIter.Text);
                int dilationTrainIter = Convert.ToInt32(txtDilationTrainIter.Text);
                int erosionInspIter = Convert.ToInt32(txtErosionInspIter.Text);
                int dilationInspIter = Convert.ToInt32(txtDilationInspIter.Text);
                int minWidthSize = Convert.ToInt32(txtMinWidthSize.Text);
                int minHeightSize = Convert.ToInt32(txtMinHeightSize.Text);
                int minNormalRatio = Convert.ToInt32(txtMinNormalRatio.Text);
                int maxNormalRatio = Convert.ToInt32(txtMaxNormalRatio.Text);
                int alignMaxDist = Convert.ToInt32(txtAlignMaxDist.Text);
                int darkAreaWidth = Convert.ToInt32(txtDarkAreaWidth.Text);

                FigureShapeProperty oldFigureShapeValue = null;
                foreach (InspectionItem element in graphic.InspectionList)
                {
                    if (element.ID == anInspectID)
                    {
                        oldFigureShapeValue = element.InspectionAlgorithm as FigureShapeProperty; // 기존에 저장된 값이 있는 경우.
                        break;
                    }
                }

                int nMaxInspectID = -1;
                foreach (InspectionItem element in graphic.InspectionList)
                {
                    if (nMaxInspectID < element.ID)
                        nMaxInspectID = element.ID;
                }

                if (oldFigureShapeValue == null) // 기존에 저장된 값이 없는 경우, 새로 리스트에 추가시킨다.
                {
                    FigureShapeProperty figureShapeValue = new FigureShapeProperty();

                    figureShapeValue.InspRange = inspRange;
                    figureShapeValue.AverMinMargin = averMinMargin;
                    figureShapeValue.AverMaxMargin = averMaxMargin;
                    figureShapeValue.MinMargin = minMargin;
                    figureShapeValue.MaxMargin = maxMargin;
                    figureShapeValue.ErosionTrainIter = erosionTrainIter;
                    figureShapeValue.DilationTrainIter = dilationTrainIter;
                    figureShapeValue.ErosionInspIter = erosionInspIter;
                    figureShapeValue.DilationInspIter = dilationInspIter;
                    figureShapeValue.MinWidthSize = minWidthSize;
                    figureShapeValue.MinHeightSize = minHeightSize;
                    figureShapeValue.MinNormalRatio = minNormalRatio;
                    figureShapeValue.MaxNormalRatio = maxNormalRatio;
                    figureShapeValue.AlignMaxDist = alignMaxDist;
                    figureShapeValue.DarkAreaWidth = darkAreaWidth;

                    InspectionItem inspectionItem = new InspectionItem();
                    inspectionItem.ID = nMaxInspectID + 1;
                    inspectionItem.InspectionType = InspectionType.GetInspectionType(m_enumInspectType);
                    inspectionItem.InspectionAlgorithm = figureShapeValue;

                    if (inspectionItem.InspectionType != null)
                    {
                        graphic.InspectionList.Add(inspectionItem);
                    }
                }
                else
                {
                    oldFigureShapeValue.InspRange = inspRange;
                    oldFigureShapeValue.AverMinMargin = averMinMargin;
                    oldFigureShapeValue.AverMaxMargin = averMaxMargin;
                    oldFigureShapeValue.MinMargin = minMargin;
                    oldFigureShapeValue.MaxMargin = maxMargin;
                    oldFigureShapeValue.ErosionTrainIter = erosionTrainIter;
                    oldFigureShapeValue.DilationTrainIter = dilationTrainIter;
                    oldFigureShapeValue.ErosionInspIter = erosionInspIter;
                    oldFigureShapeValue.DilationInspIter = dilationInspIter;
                    oldFigureShapeValue.MinWidthSize = minWidthSize;
                    oldFigureShapeValue.MinHeightSize = minHeightSize;
                    oldFigureShapeValue.MinNormalRatio = minNormalRatio;
                    oldFigureShapeValue.MaxNormalRatio = maxNormalRatio;
                    oldFigureShapeValue.AlignMaxDist = alignMaxDist;
                    oldFigureShapeValue.DarkAreaWidth = darkAreaWidth;
                }
            }
            catch
            {
                MessageBox.Show("잘못 입력된 값이 존재합니다. 확인 바랍니다.", "Information");
                txtAverMinMargin.Focus();
            }
        }

        public void SetDefaultValue()
        {
            if (m_enumInspectType == eVisInspectType.eInspTypeShapeHalfEtching)
            {
                if (!ShapeHalfEtchingDefaultValue.DefaultValueLoaded)
                {
                    ShapeHalfEtchingDefaultValue.DefaultValueLoaded = true;
                    ShapeHalfEtchingDefaultValue.LoadDefaultValue();
                }

                this.SetCheckBoxState(ShapeHalfEtchingDefaultValue.InspRange);
                this.txtAverMinMargin.Text = ShapeHalfEtchingDefaultValue.AverMinMargin.ToString();
                this.txtAverMaxMargin.Text = ShapeHalfEtchingDefaultValue.AverMaxMargin.ToString();
                this.txtMinMargin.Text = ShapeHalfEtchingDefaultValue.MinMargin.ToString();
                this.txtMaxMargin.Text = ShapeHalfEtchingDefaultValue.MaxMargin.ToString();
                this.txtErosionTrainIter.Text = ShapeHalfEtchingDefaultValue.ErosionTrainIter.ToString();
                this.txtDilationTrainIter.Text = ShapeHalfEtchingDefaultValue.DilationTrainIter.ToString();
                this.txtErosionInspIter.Text = ShapeHalfEtchingDefaultValue.ErosionInspIter.ToString();
                this.txtDilationInspIter.Text = ShapeHalfEtchingDefaultValue.DilationInspIter.ToString();
                this.txtMinWidthSize.Text = ShapeHalfEtchingDefaultValue.MinWidthSize.ToString();
                this.txtMinHeightSize.Text = ShapeHalfEtchingDefaultValue.MinHeightSize.ToString();
                this.txtMinNormalRatio.Text = ShapeHalfEtchingDefaultValue.MinNormalRatio.ToString();
                this.txtMaxNormalRatio.Text = ShapeHalfEtchingDefaultValue.MaxNormalRatio.ToString();
                this.txtAlignMaxDist.Text = ShapeHalfEtchingDefaultValue.AlignMaxDist.ToString();
                this.txtDarkAreaWidth.Text = ShapeHalfEtchingDefaultValue.DarkAreaWidth.ToString();
            }
        }

        /// <summary>   Sets a check box state. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-19. </remarks>
        /// <param name="switchValue">  The switch value. </param>
        private void SetCheckBoxState(int switchValue)
        {
            switch (switchValue)
            {
                case 1:
                    this.chkMinRange.IsChecked = true; // 1
                    this.chkMaxRange.IsChecked = false;
                    this.chkInRange.IsChecked = false;
                    break;
                case 2:
                    this.chkMinRange.IsChecked = false;
                    this.chkMaxRange.IsChecked = true; // 2
                    this.chkInRange.IsChecked = false;
                    break;
                case 3:
                    this.chkMinRange.IsChecked = true;
                    this.chkMaxRange.IsChecked = true; // 1 + 2
                    this.chkInRange.IsChecked = false;
                    break;
                case 4:
                    this.chkMinRange.IsChecked = false;
                    this.chkMaxRange.IsChecked = false;
                    this.chkInRange.IsChecked = true; // 4
                    break;
                case 5:
                    this.chkMinRange.IsChecked = true;
                    this.chkMaxRange.IsChecked = false;
                    this.chkInRange.IsChecked = true; // 1 + 4
                    break;
                case 6:
                    this.chkMinRange.IsChecked = false;
                    this.chkMaxRange.IsChecked = true;
                    this.chkInRange.IsChecked = true; // 2 + 4
                    break;
                case 7:
                    this.chkMinRange.IsChecked = true;
                    this.chkMaxRange.IsChecked = true;
                    this.chkInRange.IsChecked = true; // 1 + 2 + 4
                    break;
            }
        }

        public void Display(InspectionItem settingValue)
        {
            FigureShapeProperty figureShapeProperty = settingValue.InspectionAlgorithm as FigureShapeProperty;
            if (figureShapeProperty != null)
            {
                this.SetCheckBoxState(figureShapeProperty.InspRange);
                this.txtAverMinMargin.Text = figureShapeProperty.AverMinMargin.ToString();
                this.txtAverMaxMargin.Text = figureShapeProperty.AverMaxMargin.ToString();
                this.txtMinMargin.Text = figureShapeProperty.MinMargin.ToString();
                this.txtMaxMargin.Text = figureShapeProperty.MaxMargin.ToString();
                this.txtErosionTrainIter.Text = figureShapeProperty.ErosionTrainIter.ToString();
                this.txtDilationTrainIter.Text = figureShapeProperty.DilationTrainIter.ToString();
                this.txtErosionInspIter.Text = figureShapeProperty.ErosionInspIter.ToString();
                this.txtDilationInspIter.Text = figureShapeProperty.DilationInspIter.ToString();
                this.txtMinWidthSize.Text = figureShapeProperty.MinWidthSize.ToString();
                this.txtMinHeightSize.Text = figureShapeProperty.MinHeightSize.ToString();
                this.txtMinNormalRatio.Text = figureShapeProperty.MinNormalRatio.ToString();
                this.txtMaxNormalRatio.Text = figureShapeProperty.MaxNormalRatio.ToString();
                this.txtAlignMaxDist.Text = figureShapeProperty.AlignMaxDist.ToString();
                this.txtDarkAreaWidth.Text = figureShapeProperty.DarkAreaWidth.ToString();
            }
        }
    }
}
