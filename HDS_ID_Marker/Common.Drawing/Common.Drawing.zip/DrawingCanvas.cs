using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Diagnostics;
using System.IO;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.ComponentModel;

// Modified & Commented by Minseok Hwang.

namespace Common.Drawing
{
    public delegate void ContextMenuChangeEventHandler(ContextMenuCommand selectedContextMenuCommand);
    public delegate void SelectedGraphicChangeEventHandler(GraphicsBase newGraphic);
    public delegate void NotifyConstraintEventHandler(string strMessage); // Drawing Canvas�� �������� ���� ����ڿ��� �νĽ�Ű�� �뵵�� ����.
    public delegate void ChangeToolEventHandler(ToolType newToolType);

    /// <summary>
    /// Canvas used as host for DrawingVisual objects. Allows to draw graphics objects using mouse.
    /// </summary>
    public class DrawingCanvas : Canvas
    {
        public static event ContextMenuChangeEventHandler ContextMenuChangeEvent;
        public static event SelectedGraphicChangeEventHandler SelectedGraphicChangeEvent;
        public static event NotifyConstraintEventHandler NotifyConstraintEvent;
        public static event ChangeToolEventHandler ToolTypeChangeEvent;
        public static readonly RoutedEvent IsDirtyChangedEvent;

        #region Class Members
        private VisualCollection graphicsList;
        private static List<GraphicsBase> graphicsClipboardList = new List<GraphicsBase>();

        public static readonly DependencyProperty MaxGraphicsCountProperty;
        public static readonly DependencyProperty IsBasedCanvasProperty;
        public static readonly DependencyProperty ToolProperty;
        public static readonly DependencyProperty ActualScaleProperty;
        public static readonly DependencyProperty IsDirtyProperty;
        public static readonly DependencyProperty LineWidthProperty;
        public static readonly DependencyProperty RegionTypeProperty;
        public static readonly DependencyProperty ObjectColorProperty;
        public static readonly DependencyProperty TextColorProperty;
        public static readonly DependencyProperty TextFontFamilyNameProperty;
        public static readonly DependencyProperty TextFontStyleProperty;
        public static readonly DependencyProperty TextFontWeightProperty;
        public static readonly DependencyProperty TextFontStretchProperty;
        public static readonly DependencyProperty TextFontSizeProperty;
        public static readonly DependencyProperty CanUndoProperty;
        public static readonly DependencyProperty CanRedoProperty;
        public static readonly DependencyProperty CanSelectAllProperty;
        public static readonly DependencyProperty CanUnselectAllProperty;
        public static readonly DependencyProperty CanDeleteProperty;
        public static readonly DependencyProperty CanDeleteAllProperty;
        public static readonly DependencyProperty CanMoveToFrontProperty;
        public static readonly DependencyProperty CanMoveToBackProperty;
        public static readonly DependencyProperty CanSetPropertiesProperty;
        public static readonly DependencyProperty SelectedGraphicProperty;

        public bool drawingFinished = false;

        private Tool[] tools;
        private ToolText toolText;
        private ToolPointer toolPointer;

        public ContextMenu contextMenu;
        private UndoManager undoManager;
        #endregion Class Members

        #region Constructors
        /// <summary>   Initializes a new instance of the DrawingCanvas class. </summary>
        public DrawingCanvas()
            : base()
        {
            this.graphicsList = new VisualCollection(this);
            this.FocusVisualStyle = null;

            InitializeDrawingTools();
            InitializeEvent();
            CreateContextMenu();
        }

        /// <summary>   Initializes static members of the DrawingCanvas class. </summary>
        static DrawingCanvas()
        {
            PropertyMetadata metaData;

            // MaxGraphicsCount
            metaData = new PropertyMetadata(1000);
            MaxGraphicsCountProperty = DependencyProperty.Register("MaxGraphicsCount", typeof(int), typeof(DrawingCanvas), metaData);

            // Tool
            metaData = new PropertyMetadata(ToolType.Pointer);
            ToolProperty = DependencyProperty.Register("Tool", typeof(ToolType), typeof(DrawingCanvas), metaData);

            // Is Based Canvas
            metaData = new PropertyMetadata(false);
            IsBasedCanvasProperty = DependencyProperty.Register("IsBasedCanvas", typeof(bool), typeof(DrawingCanvas), metaData);

            // ActualScale
            metaData = new PropertyMetadata(1.0 /* default value */, new PropertyChangedCallback(ActualScaleChanged) /* change callback */);
            ActualScaleProperty = DependencyProperty.Register("ActualScale", typeof(double), typeof(DrawingCanvas), metaData);

            // IsDirty
            metaData = new PropertyMetadata(false);
            IsDirtyProperty = DependencyProperty.Register("IsDirty", typeof(bool), typeof(DrawingCanvas), metaData);

            // LineWidth
            metaData = new PropertyMetadata(2.0 /* default value */, new PropertyChangedCallback(LineWidthChanged));
            LineWidthProperty = DependencyProperty.Register("LineWidth", typeof(double), typeof(DrawingCanvas), metaData);

            // RegionType
            metaData = new PropertyMetadata(GraphicsRegionType.Inspection  /* default value */);
            RegionTypeProperty = DependencyProperty.Register("RegionType", typeof(GraphicsRegionType), typeof(DrawingCanvas), metaData);

            // ObjectColor
            metaData = new PropertyMetadata(Colors.Black  /* default value */, new PropertyChangedCallback(ObjectColorChanged));
            ObjectColorProperty = DependencyProperty.Register("ObjectColor", typeof(Color), typeof(DrawingCanvas), metaData);

            // TextColor
            metaData = new PropertyMetadata(Color.FromArgb(255, 0, 255, 0)  /* default value */, new PropertyChangedCallback(TextColorChanged));
            TextColorProperty = DependencyProperty.Register("TextColor", typeof(Color), typeof(DrawingCanvas), metaData);

            // TextFontFamilyName
            metaData = new PropertyMetadata(Properties.Settings.Default.DefaultFontFamily, new PropertyChangedCallback(TextFontFamilyNameChanged));
            TextFontFamilyNameProperty = DependencyProperty.Register("TextFontFamilyName", typeof(string), typeof(DrawingCanvas), metaData);

            // TextFontStyle
            metaData = new PropertyMetadata(FontStyles.Normal, new PropertyChangedCallback(TextFontStyleChanged));
            TextFontStyleProperty = DependencyProperty.Register("TextFontStyle", typeof(FontStyle), typeof(DrawingCanvas), metaData);

            // TextFontWeight
            metaData = new PropertyMetadata(FontWeights.Normal, new PropertyChangedCallback(TextFontWeightChanged));
            TextFontWeightProperty = DependencyProperty.Register("TextFontWeight", typeof(FontWeight), typeof(DrawingCanvas), metaData);

            // TextFontStretch
            metaData = new PropertyMetadata(FontStretches.Normal, new PropertyChangedCallback(TextFontStretchChanged));
            TextFontStretchProperty = DependencyProperty.Register("TextFontStretch", typeof(FontStretch), typeof(DrawingCanvas), metaData);

            // TextFontSize
            metaData = new PropertyMetadata(12.0  /* default value */, new PropertyChangedCallback(TextFontSizeChanged));
            TextFontSizeProperty = DependencyProperty.Register("TextFontSize", typeof(double), typeof(DrawingCanvas), metaData);

            // CanUndo
            metaData = new PropertyMetadata(false);
            CanUndoProperty = DependencyProperty.Register("CanUndo", typeof(bool), typeof(DrawingCanvas), metaData);

            // CanRedo
            metaData = new PropertyMetadata(false);
            CanRedoProperty = DependencyProperty.Register("CanRedo", typeof(bool), typeof(DrawingCanvas), metaData);

            // CanSelectAll
            metaData = new PropertyMetadata(false);
            CanSelectAllProperty = DependencyProperty.Register("CanSelectAll", typeof(bool), typeof(DrawingCanvas), metaData);

            // CanUnselectAll
            metaData = new PropertyMetadata(false);
            CanUnselectAllProperty = DependencyProperty.Register("CanUnselectAll", typeof(bool), typeof(DrawingCanvas), metaData);

            // CanDelete
            metaData = new PropertyMetadata(false);
            CanDeleteProperty = DependencyProperty.Register("CanDelete", typeof(bool), typeof(DrawingCanvas), metaData);

            // CanDeleteAll
            metaData = new PropertyMetadata(false);
            CanDeleteAllProperty = DependencyProperty.Register("CanDeleteAll", typeof(bool), typeof(DrawingCanvas), metaData);

            // CanMoveToFront
            metaData = new PropertyMetadata(false);
            CanMoveToFrontProperty = DependencyProperty.Register("CanMoveToFront", typeof(bool), typeof(DrawingCanvas), metaData);

            // CanMoveToBack
            metaData = new PropertyMetadata(false);
            CanMoveToBackProperty = DependencyProperty.Register("CanMoveToBack", typeof(bool), typeof(DrawingCanvas), metaData);

            // CanSetProperties
            metaData = new PropertyMetadata(false);
            CanSetPropertiesProperty = DependencyProperty.Register("CanSetProperties", typeof(bool), typeof(DrawingCanvas), metaData);

            // SelectedShapeProperty
            metaData = new PropertyMetadata();
            SelectedGraphicProperty = DependencyProperty.Register("SelectedGraphic", typeof(GraphicsBase), typeof(DrawingCanvas), metaData);

            // IsDirtyChanged
            IsDirtyChangedEvent = EventManager.RegisterRoutedEvent("IsDirtyChangedChanged", RoutingStrategy.Bubble, typeof(DependencyPropertyChangedEventHandler), typeof(DrawingCanvas));
        }
        #endregion Constructor

        /// <summary>   Executes the render action. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-01. </remarks>
        /// <param name="dc">   The device-context. </param>
        protected override void OnRender(DrawingContext dc)
        {
            // ��Ƽ �ٸ����.
            this.VisualBitmapScalingMode = System.Windows.Media.BitmapScalingMode.NearestNeighbor;
            base.OnRender(dc);
        }

        /// <summary>   Initializes the drawing tools. </summary>
        /// <remarks>   Minseok,Hwang, 2011-08-16. </remarks>
        private void InitializeDrawingTools()
        {
            // Create array of drawing tools
            tools = new Tool[(int)ToolType.Max];

            toolPointer = new ToolPointer();
            tools[(int)ToolType.Move] = toolPointer;
            tools[(int)ToolType.Pointer] = toolPointer;
            tools[(int)ToolType.Rectangle] = new ToolRectangle();
            tools[(int)ToolType.Ellipse] = new ToolEllipse();
            tools[(int)ToolType.Line] = new ToolLine();
            tools[(int)ToolType.PolyLine] = new ToolPolyLine();
            tools[(int)ToolType.AlignPattern] = new ToolRectangle();

            toolText = new ToolText(this);
            tools[(int)ToolType.Text] = toolText;

            // Create undo manager
            undoManager = new UndoManager(this);
        }

        /// <summary>   Initializes the event. </summary>
        /// <remarks>   Minseok,Hwang, 2011-08-16. </remarks>
        private void InitializeEvent()
        {
            this.undoManager.StateChanged += undoManager_StateChanged;
            this.Loaded += DrawingCanvas_Loaded;
            this.MouseDown += DrawingCanvas_MouseDown;
            this.MouseMove += DrawingCanvas_MouseMove;
            this.MouseUp += DrawingCanvas_MouseUp;
            this.KeyDown += DrawingCanvas_KeyDown;
            this.LostMouseCapture += DrawingCanvas_LostMouseCapture;
        }

        #region Dependency Properties
        #region MaxGraphicsCount
        /// <summary>   Gets or sets the number of maximum graphics. </summary>
        /// <value> The number of maximum graphics. </value>
        public int MaxGraphicsCount
        {
            get
            {
                return (int)GetValue(MaxGraphicsCountProperty);
            }
            set
            {
                SetValue(MaxGraphicsCountProperty, value);
            }
        }
        #endregion

        #region Tool
        /// <summary>   Currently active drawing tool. </summary>
        /// <value> The tool. </value>
        public ToolType Tool
        {
            get
            {
                return (ToolType)GetValue(ToolProperty);
            }
            set
            {
                if ((int)value >= 0 && (int)value < (int)ToolType.Max)
                {
                    SetValue(ToolProperty, value);

                    if ((int)value > 0)
                    {
                        // Set cursor immediately - important when tool is selected from the menu
                        tools[(int)Tool].SetCursor(this);
                    }
                }
            }
        }
        #endregion Tool

        #region IsBasedCanvas
        public bool IsBasedCanvas
        {
            get
            {
                return (bool)GetValue(IsBasedCanvasProperty);
            }
            set
            {
                SetValue(IsBasedCanvasProperty, value);
            }
        }
        #endregion

        #region ActualScale
        /// <summary>   Dependency property ActualScale. </summary>
        /// <value> The actual scale. </value>
        public double ActualScale
        {
            get
            {
                return (double)GetValue(ActualScaleProperty);
            }
            set
            {
                SetValue(ActualScaleProperty, value);
            }
        }

        /// <summary>   Callback function called when ActualScale dependency property is changed. </summary>
        /// <param name="property"> The property. </param>
        /// <param name="args">     Dependency property changed event information. </param>
        static void ActualScaleChanged(DependencyObject property, DependencyPropertyChangedEventArgs args)
        {
            try
            {
                DrawingCanvas d = property as DrawingCanvas;

                double scale = d.ActualScale;

                foreach (GraphicsBase b in d.GraphicsList)
                {
                    b.ActualScale = scale;
                }

                foreach (GraphicsBase b in DrawingCanvas.GraphicsClipboardList)
                {
                    b.ActualScale = scale;
                }
            }
            catch
            {

            }
        }
        #endregion ActualScale

        #region IsDirty
        /// <summary>   Returns true if document is changed. </summary>
        /// <value> true if this object is dirty, false if not. </value>
        public bool IsDirty
        {
            get
            {
                return (bool)GetValue(IsDirtyProperty);
            }
            internal set
            {
                SetValue(IsDirtyProperty, value);

                // Raise IsDirtyChanged event.
                RoutedEventArgs newargs = new RoutedEventArgs(IsDirtyChangedEvent);
                RaiseEvent(newargs);
            }
        }
        #endregion IsDirty

        #region CanUndo
        /// <summary>   Return True if Undo operation is possible. </summary>
        /// <value> true if we can undo, false if not. </value>
        public bool CanUndo
        {
            get
            {
                return (bool)GetValue(CanUndoProperty);
            }
            set
            {
                SetValue(CanUndoProperty, value);
            }
        }
        #endregion CanUndo

        #region CanRedo
        /// <summary>   Return True if Redo operation is possible. </summary>
        /// <value> true if we can redo, false if not. </value>
        public bool CanRedo
        {
            get
            {
                return (bool)GetValue(CanRedoProperty);
            }
            set
            {
                SetValue(CanRedoProperty, value);
            }
        }
        #endregion CanRedo

        #region CanSelectAll
        /// <summary>   Return true if Select All function is available. </summary>
        /// <value> true if we can select all, false if not. </value>
        public bool CanSelectAll
        {
            get
            {
                return (bool)GetValue(CanSelectAllProperty);
            }
            internal set
            {
                SetValue(CanSelectAllProperty, value);
            }
        }
        #endregion CanSelectAll

        #region CanUnselectAll
        /// <summary>   Return true if Unselect All function is available. </summary>
        /// <value> true if we can unselect all, false if not. </value>
        public bool CanUnselectAll
        {
            get
            {
                return (bool)GetValue(CanUnselectAllProperty);
            }
            internal set
            {
                SetValue(CanUnselectAllProperty, value);
            }
        }
        #endregion CanUnselectAll

        #region CanDelete
        /// <summary>   Return true if Delete function is available. </summary>
        /// <value> true if we can delete, false if not. </value>
        public bool CanDelete
        {
            get
            {
                return (bool)GetValue(CanDeleteProperty);
            }
            internal set
            {
                SetValue(CanDeleteProperty, value);
            }
        }
        #endregion CanDelete

        #region CanDeleteAll
        /// <summary>   Return true if Delete All function is available. </summary>
        /// <value> true if we can delete all, false if not. </value>
        public bool CanDeleteAll
        {
            get
            {
                return (bool)GetValue(CanDeleteAllProperty);
            }
            internal set
            {
                SetValue(CanDeleteAllProperty, value);
            }
        }
        #endregion CanDeleteAll

        #region CanMoveToFront
        /// <summary>   Return true if Move to Front function is available. </summary>
        /// <value> true if we can move to front, false if not. </value>
        public bool CanMoveToFront
        {
            get
            {
                return (bool)GetValue(CanMoveToFrontProperty);
            }
            internal set
            {
                SetValue(CanMoveToFrontProperty, value);
            }
        }
        #endregion CanMoveToFront

        #region CanMoveToBack
        /// <summary>   Return true if Move to Back function is available. </summary>
        /// <value> true if we can move to back, false if not. </value>
        public bool CanMoveToBack
        {
            get
            {
                return (bool)GetValue(CanMoveToBackProperty);
            }
            internal set
            {
                SetValue(CanMoveToBackProperty, value);
            }
        }
        #endregion CanMoveToBack

        #region CanSetProperties
        /// <summary>
        /// Return true if currently active properties (line width, color etc.)
        /// can be applied to selected objects.
        /// </summary>
        /// <value> true if we can set properties, false if not. </value>
        public bool CanSetProperties
        {
            get
            {
                return (bool)GetValue(CanSetPropertiesProperty);
            }
            internal set
            {
                SetValue(CanSetPropertiesProperty, value);
            }
        }
        #endregion CanSetProperties

        #region SelectedGraphicProperty
        public GraphicsBase SelectedGraphic
        {
            get
            {
                return (GraphicsBase)GetValue(SelectedGraphicProperty);
            }
            set
            {
                // Back to green.
                if (GetValue(SelectedGraphicProperty) != null)
                {
                    if (((GraphicsBase)GetValue(SelectedGraphicProperty)).RegionType == GraphicsRegionType.StripAlign ||
                        ((GraphicsBase)GetValue(SelectedGraphicProperty)).RegionType == GraphicsRegionType.UnitAlign ||
                        ((GraphicsBase)GetValue(SelectedGraphicProperty)).RegionType == GraphicsRegionType.LocalAlign)
                    {
                        ((GraphicsBase)GetValue(SelectedGraphicProperty)).ObjectColor = GraphicsColors.Red;
                        ((GraphicsBase)GetValue(SelectedGraphicProperty)).TextColor = GraphicsColors.Red;
                    }
                    else if (((GraphicsBase)GetValue(SelectedGraphicProperty)).RegionType == GraphicsRegionType.Except)
                    {
                        ((GraphicsBase)GetValue(SelectedGraphicProperty)).ObjectColor = GraphicsColors.Blue;
                        ((GraphicsBase)GetValue(SelectedGraphicProperty)).TextColor = GraphicsColors.Blue;
                    }
                    else
                    {
                        ((GraphicsBase)GetValue(SelectedGraphicProperty)).ObjectColor = GraphicsColors.Green;
                        ((GraphicsBase)GetValue(SelectedGraphicProperty)).TextColor = GraphicsColors.Green;
                    }
                    ((GraphicsBase)GetValue(SelectedGraphicProperty)).RefreshDrawing();
                }

                SelectedGraphicChangeEventHandler eventRunner = SelectedGraphicChangeEvent;
                if (eventRunner != null)
                {
                    eventRunner(value);
                }

                SetValue(SelectedGraphicProperty, value);
                // Set to Orange. (Selected ROI)
                if (GetValue(SelectedGraphicProperty) != null)
                {
                    ((GraphicsBase)GetValue(SelectedGraphicProperty)).ObjectColor = Colors.Orange;
                    ((GraphicsBase)GetValue(SelectedGraphicProperty)).TextColor = Colors.Orange;
                    ((GraphicsBase)GetValue(SelectedGraphicProperty)).RefreshDrawing();
                }
            }
        }
        #endregion



        #region LineWidth
        /// <summary>
        /// Line width of new graphics object. Setting this property is also applied to current selection.
        /// </summary>
        /// <value> The width of the line. </value>
        [DefaultValue(2.0)]
        public double LineWidth
        {
            get
            {
                return (double)GetValue(LineWidthProperty);
            }
            set
            {
                SetValue(LineWidthProperty, value);

            }
        }

        /// <summary>   Callback function called when LineWidth dependency property is changed. </summary>
        /// <param name="property"> The property. </param>
        /// <param name="args">     Dependency property changed event information. </param>
        static void LineWidthChanged(DependencyObject property, DependencyPropertyChangedEventArgs args)
        {
            try
            {
                DrawingCanvas d = property as DrawingCanvas;

                HelperFunctions.ApplyLineWidth(d, d.LineWidth, true);
            }
            catch
            {

            }
        }
        #endregion LineWidth

        #region RegionType

        /// <summary>   Gets or sets the type of the region. </summary>
        /// <value> The type of the region. </value>
        public GraphicsRegionType RegionType
        {
            get
            {
                return (GraphicsRegionType)GetValue(RegionTypeProperty);
            }
            set
            {
                SetValue(RegionTypeProperty, value);
            }
        }

        #endregion

        #region ObjectColor

        /// <summary>
        /// Color of new graphics object. Setting this property is also applied to current selection.
        /// </summary>
        /// <value> The color of the object. </value>
        public Color ObjectColor
        {
            get
            {
                return (Color)GetValue(ObjectColorProperty);
            }
            set
            {
                SetValue(ObjectColorProperty, value);

            }
        }

        /// <summary>   Callback function called when ObjectColor dependency property is changed. </summary>
        /// <param name="property"> The property. </param>
        /// <param name="args">     Dependency property changed event information. </param>
        static void ObjectColorChanged(DependencyObject property, DependencyPropertyChangedEventArgs args)
        {
            try
            {
                DrawingCanvas d = property as DrawingCanvas;

                HelperFunctions.ApplyColor(d, d.ObjectColor, true);
            }
            catch
            {

            }
        }
        #endregion ObjectColor

        #region TextColor

        /// <summary>   Gets or sets the color of the text. </summary>
        /// <value> The color of the text. </value>
        public Color TextColor
        {
            get
            {
                return (Color)GetValue(TextColorProperty);
            }
            set
            {
                SetValue(TextColorProperty, value);

            }
        }

        /// <summary>   Text color changed. </summary>
        /// <remarks>   Minseok,Hwang, 2011-08-16. </remarks>
        /// <param name="property"> The property. </param>
        /// <param name="args">     Dependency property changed event information. </param>
        static void TextColorChanged(DependencyObject property, DependencyPropertyChangedEventArgs args)
        {
            try
            {
                DrawingCanvas d = property as DrawingCanvas;

                if (d != null)
                {
                    HelperFunctions.ApplyColor(d, d.TextColor, true);
                }
            }
            catch
            {

            }
        }
        #endregion TextColor

        #region TextFontFamilyName
        /// <summary>
        /// Font Family name of new graphics object. Setting this property is also applied to current
        /// selection.
        /// </summary>
        /// <value> The name of the text font family. </value>
        public string TextFontFamilyName
        {
            get
            {
                return (string)GetValue(TextFontFamilyNameProperty);
            }
            set
            {
                SetValue(TextFontFamilyNameProperty, value);

            }
        }

        /// <summary>
        /// Callback function called when TextFontFamilyName dependency property is changed.
        /// </summary>
        /// <param name="property"> The property. </param>
        /// <param name="args">     Dependency property changed event information. </param>
        static void TextFontFamilyNameChanged(DependencyObject property, DependencyPropertyChangedEventArgs args)
        {
            try
            {
                DrawingCanvas d = property as DrawingCanvas;

                HelperFunctions.ApplyFontFamily(d, d.TextFontFamilyName, true);
            }
            catch
            {

            }
        }
        #endregion TextFontFamilyName

        #region TextFontStyle
        /// <summary>
        /// Font style of new graphics object. Setting this property is also applied to current selection.
        /// </summary>
        /// <value> The text font style. </value>
        public FontStyle TextFontStyle
        {
            get
            {
                return (FontStyle)GetValue(TextFontStyleProperty);
            }
            set
            {
                SetValue(TextFontStyleProperty, value);

            }
        }

        /// <summary>
        /// Callback function called when TextFontStyle dependency property is changed.
        /// </summary>
        /// <param name="property"> The property. </param>
        /// <param name="args">     Dependency property changed event information. </param>
        static void TextFontStyleChanged(DependencyObject property, DependencyPropertyChangedEventArgs args)
        {
            try
            {
                DrawingCanvas d = property as DrawingCanvas;

                HelperFunctions.ApplyFontStyle(d, d.TextFontStyle, true);

            }
            catch
            {

            }
        }
        #endregion TextFontStyle

        #region TextFontWeight
        /// <summary>
        /// Font weight of new graphics object. Setting this property is also applied to current
        /// selection.
        /// </summary>
        /// <value> The text font weight. </value>
        public FontWeight TextFontWeight
        {
            get
            {
                return (FontWeight)GetValue(TextFontWeightProperty);
            }
            set
            {
                SetValue(TextFontWeightProperty, value);

            }
        }

        /// <summary>
        /// Callback function called when TextFontWeight dependency property is changed.
        /// </summary>
        /// <param name="property"> The property. </param>
        /// <param name="args">     Dependency property changed event information. </param>
        static void TextFontWeightChanged(DependencyObject property, DependencyPropertyChangedEventArgs args)
        {
            try
            {
                DrawingCanvas d = property as DrawingCanvas;

                HelperFunctions.ApplyFontWeight(d, d.TextFontWeight, true);
            }
            catch
            {

            }
        }
        #endregion TextFontWeight

        #region TextFontStretch
        /// <summary>
        /// Font stretch of new graphics object. Setting this property is also applied to current
        /// selection.
        /// </summary>
        /// <value> The text font stretch. </value>
        public FontStretch TextFontStretch
        {
            get
            {
                return (FontStretch)GetValue(TextFontStretchProperty);
            }
            set
            {
                SetValue(TextFontStretchProperty, value);

            }
        }

        /// <summary>
        /// Callback function called when TextFontStretch dependency property is changed.
        /// </summary>
        /// <param name="property"> The property. </param>
        /// <param name="args">     Dependency property changed event information. </param>
        static void TextFontStretchChanged(DependencyObject property, DependencyPropertyChangedEventArgs args)
        {
            try
            {
                DrawingCanvas d = property as DrawingCanvas;

                HelperFunctions.ApplyFontStretch(d, d.TextFontStretch, true);
            }
            catch
            {

            }
        }
        #endregion TextFontStretch

        #region TextFontSize
        /// <summary>
        /// Font size of new graphics object. Setting this property is also applied to current selection.
        /// </summary>
        /// <value> The size of the text font. </value>
        public double TextFontSize
        {
            get
            {
                return (double)GetValue(TextFontSizeProperty);
            }
            set
            {
                SetValue(TextFontSizeProperty, value);

            }
        }

        /// <summary>   Callback function called when TextFontSize dependency property is changed. </summary>
        /// <param name="property"> The property. </param>
        /// <param name="args">     Dependency property changed event information. </param>
        static void TextFontSizeChanged(DependencyObject property, DependencyPropertyChangedEventArgs args)
        {
            try
            {
                DrawingCanvas d = property as DrawingCanvas;

                HelperFunctions.ApplyFontSize(d, d.TextFontSize, true);
            }
            catch
            {

            }
        }
        #endregion TextFontSize
        #endregion Dependency Properties

        #region Routed Events
        /// <summary>
        /// IsDirtyChanged event.
        /// 
        /// If client binds to IsDirty property, this event is not required. But if client knows when
        /// IsDirty changed without binding, IsDirtyChanged is needed.
        /// </summary>
        /// <value> The is dirty changed. </value>
        public event RoutedEventHandler IsDirtyChanged
        {
            add
            {
                AddHandler(IsDirtyChangedEvent, value);
            }
            remove
            {
                RemoveHandler(IsDirtyChangedEvent, value);
            }
        }
        #endregion Routed Events

        #region Public Functions
        /// <summary>
        /// Return list of graphic objects. Used if client program needs to make its own usage of
        /// graphics objects, like save them in some persistent storage.
        /// </summary>
        /// <returns>   The list of graphic objects. </returns>
        public PropertiesGraphicsBase[] GetListOfGraphicObjects()
        {
            PropertiesGraphicsBase[] result = new PropertiesGraphicsBase[graphicsList.Count];

            int i = 0;

            foreach (GraphicsBase g in graphicsList)
            {
                result[i++] = g.CreateSerializedObject();
            }

            return result;
        }

        /// <summary>
        /// Draw all graphics objects to DrawingContext supplied by client. Can be used for printing or
        /// saving image together with graphics as single bitmap.
        /// 
        /// Selection tracker is not drawn.
        /// </summary>
        /// <param name="drawingContext">   Context for the drawing. </param>
        public void Draw(DrawingContext drawingContext)
        {
            Draw(drawingContext, false);
        }

        /// <summary>
        /// Draw all graphics objects to DrawingContext supplied by client. Can be used for printing or
        /// saving image together with graphics as single bitmap.
        /// 
        /// withSelection = true - draw selected objects with tracker.
        /// </summary>
        /// <param name="drawingContext">   Context for the drawing. </param>
        /// <param name="withSelection">    true to with selection. </param>
        public void Draw(DrawingContext drawingContext, bool withSelection)
        {
            bool oldSelection = false;

            foreach (GraphicsBase b in graphicsList)
            {
                if (!withSelection)
                {
                    // Keep selection state and unselect
                    oldSelection = b.IsSelected;
                    b.IsSelected = false;
                }

                b.Draw(drawingContext);

                if (!withSelection)
                {
                    // Restore selection state
                    b.IsSelected = oldSelection;
                }
            }
        }

        /// <summary>   Clear graphics list. </summary>        
        public void Clear()
        {
            graphicsList.Clear();
            graphicsClipboardList.Clear();
            ClearHistory();
            UpdateState();
        }

        /// <summary>   Save graphics to XML file. Throws: DrawingCanvasException. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-15. </remarks>
        /// <param name="fileName">         The string to save. </param>
        /// <param name="strModelName">     Name of the string model. </param>
        /// <param name="strSectionName">   Name of the string section. </param>
        /// <param name="pixelWidth">       Width of the pixel. </param>
        /// <param name="pixelHeight">      Height of the pixel. </param>
        public void Save(string fileName, string strModelName, string strSectionName, int pixelWidth, int pixelHeight)
        {
            try
            {
                SerializationHelper serializedGraphicsList = new SerializationHelper(graphicsList);
                serializedGraphicsList.ModelName = strModelName;
                serializedGraphicsList.SectionName = strSectionName;
                serializedGraphicsList.RegionWidth = pixelWidth;
                serializedGraphicsList.RegionHeight = pixelHeight;

                XmlSerializer xml = new XmlSerializer(typeof(SerializationHelper));

                using (Stream stream = new FileStream(fileName,
                    FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    xml.Serialize(stream, serializedGraphicsList);
                    //ClearHistory();
                    UpdateState();
                }
            }
            catch
            {
                //
            }
        }

        /// <summary>   XML to GraphicsList. </summary>
        /// <remarks>   Minseok, Hwang, 2011-11-29. </remarks>
        public int Load(string fileName, string strModelName, string strSectionName, int pixelWidth, int pixelHeight)
        {
            try
            {
                SerializationHelper serializedGraphicsList;
                XmlSerializer xml = new XmlSerializer(typeof(SerializationHelper));

                using (Stream stream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    serializedGraphicsList = (SerializationHelper)xml.Deserialize(stream);
                    if (serializedGraphicsList.ModelName != strModelName)
                    {
                        return -1; // ���� ƼĪ���� �𵨰� ���ƾ� �Ѵ�.
                    }
                    else if (serializedGraphicsList.RegionWidth > pixelWidth || serializedGraphicsList.RegionHeight > pixelHeight)
                    {
                        return -2; // ���� ƼĪ���� Section�� Width�� ���ų� Ŀ���Ѵ�.
                    }
                }

                if (serializedGraphicsList.Graphics == null)
                {
                    throw new Exception();
                }

                graphicsList.Clear();
                graphicsClipboardList.Clear();

                GraphicsBase graphic;
                GraphicsRectangle graphicsRectangle = null;
                foreach (PropertiesGraphicsBase g in serializedGraphicsList.Graphics)
                {
                    // 2011-11-29, Minseok Hwang Added. XML ������ Local Align�� �ݺ� ������ �������־�� ��.
                    
                    graphic = g.CreateGraphics();
                    graphicsList.Add(graphic);

                    // �ݺ� ���� graphicsList�� �߰�.
                    if (graphic is GraphicsRectangle)
                    {
                        if (graphic.RegionType == GraphicsRegionType.UnitRegion || graphic.RegionType == GraphicsRegionType.OuterRegion)
                        {
                            IterationGraphics(graphic as GraphicsRectangle);
                        }
                    }

                    // Local Align grapihcsList�� �߰�.
                    if (g.LocalAligns != null)
                    {
                        graphic.LocalAligns = new GraphicsRectangle[g.LocalAligns.Length];

                        for (int i = 0; i < g.LocalAligns.Length; i++)
                        {
                            if (g.LocalAligns[i].X == -1 || g.LocalAligns[i].Y == -1)
                            {
                                continue;
                            }
                            
                            graphicsRectangle = new GraphicsRectangle(
                                g.LocalAligns[i].X - 15,
                                g.LocalAligns[i].Y - 15,
                                g.LocalAligns[i].X + 15,
                                g.LocalAligns[i].Y + 15,
                                this.LineWidth,
                                GraphicsRegionType.LocalAlign,
                                GraphicsColors.Red,
                                GraphicsColors.Red,
                                this.ActualScale
                                );
                            graphicsRectangle.Caption = CaptionHelper.LocalAlignCaption;

                            // ��ȣ ����.
                            graphicsRectangle.MotherROI = graphic;
                            graphic.LocalAligns[i] = graphicsRectangle;

                            graphicsList.Add(graphicsRectangle);
                        }
                        g.LocalAligns = null;
                    }
                }

                this.Refresh();

                // Update clip for all loaded objects.
                RefreshClip();

                foreach (GraphicsBase g in graphicsList)
                {
                    g.RefreshDrawing();
                }

                ClearHistory();
                UpdateState();
            }
            catch
            {
                //
            }

            return 0;
        }

        /// <summary>   Select all. </summary>
        public void SelectAll()
        {
            SelectedGraphic = null;
            HelperFunctions.SelectAll(this);
            UpdateState();
        }

        /// <summary>   Unselect all. </summary>
        public void UnselectAll()
        {
            SelectedGraphic = null;
            HelperFunctions.UnselectAll(this);
            UpdateState();
        }

        /// <summary>   Delete selection. </summary>
        public void Delete()
        {
            // ���õ� ROI�� �����Ѵ�.

            // 1. �ݺ� ������ ���� ������ ROI�� ���� ��󿡼� ���ܽ�Ų��.
            foreach (GraphicsRectangle selectedRectangle in SelectionRectangle)
            {
                if (selectedRectangle.RegionType == GraphicsRegionType.UnitRegion ||
                    selectedRectangle.RegionType == GraphicsRegionType.OuterRegion)
                {
                    if (!selectedRectangle.IsFiducialRegion && (selectedRectangle.IterationValue.Column + selectedRectangle.IterationValue.Row) != 2)
                    {
                        selectedRectangle.IsSelected = false;
                    }
                }
            }
            // 2. ���� Unit�� ���õ� ���, �׿� ���õ� �ڽ� ROI�� ���� ��� ���Խ�Ų��.
            foreach (GraphicsRectangle selectedRectangle in SelectionRectangle)
            {
                if (selectedRectangle.IsFiducialRegion)
                {
                    foreach (GraphicsBase targetROI in graphicsList)
                    {
                        //�ݺ����� �ڽ� ROI ����
                        if (targetROI is GraphicsRectangle)
                        {
                            if (((GraphicsRectangle)targetROI).MotherROI != null &&
                                ((GraphicsRectangle)targetROI).MotherROI == selectedRectangle)
                            {
                                targetROI.IsSelected = true;
                            }
                        }
                    }
                }
            }

            // 3. Local Align ����
            foreach (GraphicsBase targetROI in Selection)
            {
                if (targetROI.LocalAligns != null) // Local Align�� ���� ROI�� �ش�ȴ�.
                {
                    if (targetROI.LocalAligns.Length != 0)
                    {
                        foreach (GraphicsBase childROI in graphicsList)
                        {
                            if (childROI is GraphicsRectangle && ((GraphicsRectangle)childROI).MotherROI == targetROI)
                            {
                                childROI.IsSelected = true;
                            }
                        }
                    }
                }
                else if (targetROI.RegionType == GraphicsRegionType.LocalAlign) // Local Align�� �ش�ȴ�.
                {
                    foreach (GraphicsBase parentROI in graphicsList)
                    {
                        if (parentROI == ((GraphicsRectangle)targetROI).MotherROI)
                        {
                            for (int i = 0; i < parentROI.LocalAligns.Length; i++)
                            {
                                if (parentROI.LocalAligns[i] != null &&
                                    parentROI.LocalAligns[i] == targetROI)
                                {
                                    parentROI.LocalAligns[i] = null;
                                    break; // for
                                }
                            }
                            break; // foreach
                        }
                    }
                }
            }

            // 4. �� �ܰ踦 ���� ���õ� ROI�� ��� �����Ѵ�.
            undoManager.AddCommandToHistory(new CommandChangeState(this));
            HelperFunctions.DeleteSelection(this);
            UpdateState();
            SelectedGraphic = null;
        }

        /// <summary>   Delete all. </summary>
        public void DeleteAll()
        {
            undoManager.AddCommandToHistory(new CommandChangeState(this));
            HelperFunctions.DeleteAll(this);
            UpdateState();
            SelectedGraphic = null;
        }

        /// <summary>   Move selection to the front of Z-order. </summary>
        public void MoveToFront()
        {
            HelperFunctions.MoveSelectionToFront(this);
            UpdateState();
        }

        /// <summary>   Move selection to the end of Z-order. </summary>
        public void MoveToBack()
        {
            HelperFunctions.MoveSelectionToBack(this);
            UpdateState();
        }

        /// <summary>   Apply currently active properties to selected objects. </summary>
        public void SetProperties()
        {
            HelperFunctions.ApplyProperties(this);
            UpdateState();
        }

        /// <summary>   Set clip for all graphics objects. </summary>
        public void RefreshClip()
        {
            foreach (GraphicsBase b in graphicsList)
            {
                b.Clip = new RectangleGeometry(new Rect(0, 0, this.ActualWidth, this.ActualHeight));

                // Good chance to refresh actual scale
                b.ActualScale = this.ActualScale;
            }

            foreach (GraphicsBase b in graphicsClipboardList)
            {
                b.Clip = new RectangleGeometry(new Rect(0, 0, this.ActualWidth, this.ActualHeight));

                // Good chance to refresh actual scale
                b.ActualScale = this.ActualScale;
            }
        }

        /// <summary>   Remove clip for all graphics objects. </summary>
        public void RemoveClip()
        {
            foreach (GraphicsBase b in graphicsList)
            {
                b.Clip = null;
            }

            foreach (GraphicsBase b in graphicsClipboardList)
            {
                b.Clip = null;
            }
        }

        /// <summary>   Undo. </summary>
        public void Undo()
        {
            if (!CanUndo)
            {
                return;
            }

            undoManager.Undo();

            #region Local Align �� �ݺ������� �ڽ� ROI�� ��� �ٽ� �θ� ROI�� �������־�� �Ѵ�. ## Minseok, Hwang. 2011-11-28 added. ##
            GraphicsRectangle graphicsRectangle;
            List<GraphicsRectangle> orphanRoiList = new List<GraphicsRectangle>();
            List<GraphicsRectangle> motherRoiList = new List<GraphicsRectangle>();
            List<GraphicsRectangle> localAlignList = new List<GraphicsRectangle>();
            foreach (GraphicsBase graphic in graphicsList)
            {
                if (graphic.RegionType == GraphicsRegionType.UnitRegion ||
                    graphic.RegionType == GraphicsRegionType.OuterRegion)
                {
                    graphicsRectangle = graphic as GraphicsRectangle;
                    if (!graphicsRectangle.IsFiducialRegion)
                    {
                        orphanRoiList.Add(graphicsRectangle);
                    }
                    else
                    {
                        motherRoiList.Add(graphicsRectangle);
                    }
                }
                else if (graphic.RegionType == GraphicsRegionType.LocalAlign)
                {
                    localAlignList.Add(graphic as GraphicsRectangle);
                }
            }

            foreach (GraphicsRectangle orphanROI in orphanRoiList)
            {
                foreach (GraphicsRectangle motherROI in motherRoiList)
                {
                    // �� ������ �ݺ� ���� ���� ���� ������ ����ϴ�.
                    if (orphanROI.SymmetryValue == motherROI.SymmetryValue &&
                        orphanROI.IterationValue == motherROI.IterationValue)
                    {
                        orphanROI.MotherROI = motherROI;
                        orphanROI.IsFiducialRegion = false;
                        orphanROI.Caption = CaptionHelper.GetSectionPositionCaption(orphanROI);
                    }
                }
            }

            foreach (GraphicsRectangle localAlignROI in localAlignList)
            {
                foreach (GraphicsBase graphic in graphicsList)
                {
                    if (localAlignROI.MotherROI.Id == graphic.Id)
                    {
                        if (graphic.LocalAligns == null)
                        {
                            graphic.LocalAligns = new GraphicsRectangle[4];
                        }

                        for (int i = 0; i < graphic.LocalAligns.Length; i++)
                        {
                            if (graphic.LocalAligns[i] == null)
                            {
                                graphic.LocalAligns[i] = localAlignROI;
                                localAlignROI.MotherROI = graphic;

                                break;
                            }
                        }
                    }
                }
            }
            #endregion

            UpdateState();
        }

        /// <summary>   Redo. </summary>
        public void Redo()
        {
            if (!CanRedo)
            {
                return;
            }

            undoManager.Redo();
            UpdateState();
        }
        #endregion Public Functions

        #region Internal Properties
        /// <summary>   Get graphic object by index. </summary>
        /// <value> The indexed item. </value>
        internal GraphicsBase this[int index]
        {
            get
            {
                if (index >= 0 && index < Count)
                {
                    return (GraphicsBase)graphicsList[index];
                }

                return null;
            }
        }

        /// <summary>   Get number of graphic objects. </summary>
        /// <value> The count. </value>
        internal int Count
        {
            get
            {
                return graphicsList.Count;
            }
        }

        /// <summary>   Get number of selected graphic objects. </summary>
        /// <value> The number of selections. </value>
        public int SelectionCount
        {
            get
            {
                int n = 0;

                foreach (GraphicsBase g in this.graphicsList)
                {
                    if (g.IsSelected)
                    {
                        n++;
                    }
                }

                return n;
            }
        }

        /// <summary>   Return list of graphics. </summary>
        /// <value> A List of graphics. </value>
        public VisualCollection GraphicsList
        {
            get
            {
                return graphicsList;
            }
        }

        /// <summary>   Gets a list of graphics clipboards. </summary>
        /// <value> A List of graphics clipboards. </value>
        public static List<GraphicsBase> GraphicsClipboardList
        {
            get
            {
                return graphicsClipboardList;
            }
        }

        /// <summary>   Returns INumerable which may be used for enumeration of selected objects. </summary>
        /// <value> The selection. </value>
        internal IEnumerable<GraphicsBase> Selection
        {
            get
            {
                foreach (GraphicsBase o in graphicsList)
                {
                    if (o.IsSelected)
                    {
                        yield return o;
                    }
                }
            }
        }

        /// <summary>   Gets the selection rectangle. </summary>
        /// <value> The selection rectangle. </value>
        public IEnumerable<GraphicsBase> SelectionRectangle
        {
            get
            {
                foreach (GraphicsBase o in graphicsList)
                {
                    if (o is GraphicsRectangle && o.IsSelected)
                    {
                        yield return o;
                    }
                }
            }
        }

        #endregion Internal Properties

        #region Visual Children Overrides
        /// <summary>
        /// Get number of children: VisualCollection count. If in-place editing textbox is active, add 1.
        /// </summary>
        /// <value> The number of visual childrens. </value>
        protected override int VisualChildrenCount
        {
            get
            {
                int n = graphicsList.Count;

                if (toolText.TextBox != null)
                {
                    n++;
                }

                return n;
            }
        }

        /// <summary>
        /// Get visual child - one of GraphicsBase objects or in-place editing textbox, if it is active.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">  Thrown when one or more arguments are outside
        ///                                                 the required range. </exception>
        /// <param name="index">    Zero-based index of the. </param>
        /// <returns>   The visual child. </returns>
        protected override Visual GetVisualChild(int index)
        {
            if (index < 0 || index >= graphicsList.Count)
            {
                if (toolText.TextBox != null && index == graphicsList.Count)
                {
                    return toolText.TextBox;
                }

                throw new ArgumentOutOfRangeException("index");
            }

            return graphicsList[index];
        }
        #endregion Visual Children Overrides

        #region Mouse Event Handlers
        /// <summary>
        /// Mouse down. Left button down event is passed to active tool. Right button down event is
        /// handled in this class.
        /// </summary>
        /// <param name="sender">   Source of the event. </param>
        /// <param name="e">        Mouse button event information. </param>
        public void DrawingCanvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (tools[(int)Tool] == null)
            {
                return;
            }

            // Drawing Canvas�� �׸� �� �ִ� ������ ������ �����Ѵ�.
            if (GetSectionROICount() >= MaxGraphicsCount)
            {
                Tool = ToolType.Pointer;
            }

            this.Focus();

            if (e.ChangedButton == MouseButton.Left)
            {
                if (e.ClickCount == 2)
                {
                    // 2011-04-07. minseok, hwang.
                    if (Tool == ToolType.Pointer)
                    {
                        MoveToBack();
                    }
                    else
                    {
                        // special case for GraphicsText
                        HandleDoubleClick(e);
                    }
                }

                drawingFinished = false;
                tools[(int)Tool].OnMouseDown(this, e);

                UpdateState();
                UpdateSelectedGraphic();
            }
            else if (e.ChangedButton == MouseButton.Right)
            {
                Point point = Mouse.GetPosition(this);

                List<GraphicsBase> hittedList = new List<GraphicsBase>();
                foreach (GraphicsBase graphic in graphicsList)
                {
                    if (graphic.MakeHitTest(point) >= 0)
                    {
                        hittedList.Add(graphic);
                    }
                }

                if (hittedList.Count > 0)
                {
                    SelectedGraphic = hittedList[hittedList.Count - 1]; // ���� �տ� ���� GraphicsBase�� SelectedGraphic���� �����Ѵ�.
                }
                else
                {
                    SelectedGraphic = null;
                }

                if (Tool == ToolType.PolyLine)
                {
                    ToolPolyLine toolPolyLine = tools[(int)ToolType.PolyLine] as ToolPolyLine;

                    if (toolPolyLine != null)
                    {
                        if (toolPolyLine.CanShowContextMenu)
                        {
                            tools[(int)Tool].OnMouseDown(this, e);
                            ShowContextMenu(e);
                        }
                    }
                }
                else
                {
                    tools[(int)Tool].OnMouseUp(this, e);
                    foreach (GraphicsBase graphic in graphicsList)
                    {
                        if (graphic.MakeHitTest(point) >= 0)
                        {
                            tools[(int)Tool].OnMouseDown(this, e);
                            break;
                        }
                    }
                    ShowContextMenu(e);
                }
            }
        }

        /// <summary>
        /// Mouse move. Moving without button pressed or with left button pressed is passed to active tool.
        /// </summary>
        /// <param name="sender">   Source of the event. </param>
        /// <param name="e">        Mouse event information. </param>
        public void DrawingCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (tools[(int)Tool] == null)
            {
                return;
            }

            if (e.MiddleButton == MouseButtonState.Released && e.RightButton == MouseButtonState.Released)
            {
                tools[(int)Tool].OnMouseMove(this, e);

                UpdateState();
            }
            else
            {
                this.Cursor = HelperFunctions.DefaultCursor;
            }
        }

        /// <summary>   Mouse up event. Left button up event is passed to active tool. </summary>
        /// <param name="sender">   Source of the event. </param>
        /// <param name="e">        Mouse button event information. </param>
        public void DrawingCanvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (tools[(int)Tool] == null)
            {
                return;
            }

            // Drawing Canvas�� �׸� �� �ִ� ������ ������ �����Ѵ�.
            int graphicCount = 0;
            foreach (GraphicsBase graphic in graphicsList)
            {
                if (graphic.RegionType == GraphicsRegionType.StripAlign)
                {
                    graphicCount++;
                }
                else if (graphic is GraphicsRectangle && ((GraphicsRectangle)graphic).MotherROI == null) // �ڱ� �ڽ��� source unit region�� ���.
                {
                    graphicCount++;
                }
            }
            if (graphicCount >= MaxGraphicsCount)
            {
                Tool = ToolType.Pointer;
            }

            if (SelectedGraphic is GraphicsSelectionRectangle)
            {
                if (((GraphicsSelectionRectangle)SelectedGraphic).WidthProperty == 0 &&
                   ((GraphicsSelectionRectangle)SelectedGraphic).HeightProperty == 0)
                {
                    SelectedGraphic = null;
                }
            }

            // Mouse Up ������ SelectedGraphic ��ȭ(�̵�, ������ ����)�� �ݿ���Ų��.
            if (SelectedGraphic != null && SelectedGraphic.MakeHitTest(e.GetPosition(this)) >= 0)
            {
                SelectedGraphicChangeEventHandler eventRunner = SelectedGraphicChangeEvent;
                if (eventRunner != null)
                {
                    eventRunner(SelectedGraphic);
                }
            }

            if (Tool != ToolType.PolyLine && e.ChangedButton == MouseButton.Left)
            {
                drawingFinished = true;
                tools[(int)Tool].OnMouseUp(this, e);

                UpdateState();
            }
            else if (Tool == ToolType.PolyLine && e.ChangedButton == MouseButton.Right)
            {
                try
                {
                    drawingFinished = true;
                    tools[(int)ToolType.PolyLine].OnMouseUp(this, e);

                    GraphicsPolyLine polyLine = graphicsList[graphicsList.Count - 1] as GraphicsPolyLine;
                    if (polyLine != null)
                    {
                        if (polyLine.Points.Length > 3)
                        {
                            List<Point> points = new List<Point>();

                            points.Add(polyLine.Points[0]);
                            int nPoints = polyLine.Points.Length;
                            for (int i = 1; i < nPoints - 1; i++)
                            {
                                if (polyLine.Points[i] != polyLine.Points[i + 1])
                                {
                                    points.Add(polyLine.Points[i]);
                                }
                            }
                            graphicsList.RemoveAt(graphicsList.Count - 1);

                            points.Add(Mouse.GetPosition(this));

                            polyLine = new GraphicsPolyLine(
                                points,
                                this.LineWidth,
                                this.RegionType,
                                this.ObjectColor,
                                this.TextColor,
                                this.ActualScale);

                            // �ϼ��� �ٰ����� ����Ʈ�� �߰��Ѵ�.
                            SelectedGraphic = polyLine;
                            graphicsList.Add(polyLine);
                            polyLine.IsSelected = true;

                            undoManager.AddCommandToHistory(new CommandAdd(polyLine));
                        }
                        else
                        {
                            graphicsList.RemoveAt(graphicsList.Count - 1);
                        }
                    }
                }
                catch
                {
                    ShowContextMenu(e);
                }

                UpdateState();
            }
        }
        #endregion Mouse Event Handlers

        #region Other Event Handlers
        /// <summary>   Initialization after control is loaded. </summary>
        /// <param name="sender">   Source of the event. </param>
        /// <param name="e">        Routed event information. </param>
        public void DrawingCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            this.Focusable = true;      // to handle keyboard messages
        }

        public void SymmetryGraphic(Point aRightBottom, FilpType aFlip)
        {
            foreach (GraphicsBase roi in this.graphicsList)
            {
                if (roi.IsSelected == true)
                {
                    if (roi is GraphicsRectangleBase)
                    {
                        #region Rectangle, Ellipse Symmetry
                        GraphicsRectangleBase graphicsRectangleBase = roi as GraphicsRectangleBase;
                        if (aFlip == FilpType.UPDOWN)
                        {
                            graphicsRectangleBase.Top = aRightBottom.Y - graphicsRectangleBase.Top;
                            graphicsRectangleBase.Bottom = aRightBottom.Y - graphicsRectangleBase.Bottom;
                        }
                        else if(aFlip == FilpType.LEFTRIGHT)
                        {
                            graphicsRectangleBase.Left = aRightBottom.X - graphicsRectangleBase.Left;
                            graphicsRectangleBase.Right = aRightBottom.X - graphicsRectangleBase.Right;
                        }
                        graphicsRectangleBase.RefreshDrawing();
                        #endregion
                    }
                    else if (roi is GraphicsPolyLine)
                    {
                        #region PolyLine Symmetry
                        GraphicsPolyLine graphicsPolyLine = roi as GraphicsPolyLine;
                        if (aFlip == FilpType.UPDOWN)
                        {
                            for (int i = 0; i < graphicsPolyLine.Points.Length; i++)
                            {
                                graphicsPolyLine.Points[i].Y = aRightBottom.Y - graphicsPolyLine.Points[i].Y;
                            }
                        }
                        else if (aFlip == FilpType.LEFTRIGHT)
                        {
                            for (int i = 0; i < graphicsPolyLine.Points.Length; i++)
                            {
                                graphicsPolyLine.Points[i].X = aRightBottom.X - graphicsPolyLine.Points[i].X;
                            }
                        }
                        graphicsPolyLine.RefreshDrawing();
                        #endregion
                    }
                    else if (roi is GraphicsLine)
                    {
                        #region GraphicsLine Symmetry
                        GraphicsLine graphicsLine = roi as GraphicsLine;
                        if (aFlip == FilpType.UPDOWN)
                        {
                            Point point = new Point();
                            point.Y = aRightBottom.Y - graphicsLine.Start.Y;
                            point.X = graphicsLine.Start.X;
                            graphicsLine.Start = point;

                            point = new Point();
                            point.Y = aRightBottom.Y - graphicsLine.End.Y;
                            point.X = graphicsLine.End.X;
                            graphicsLine.End = point;
                        }
                        else if (aFlip == FilpType.LEFTRIGHT)
                        {
                            Point point = new Point();
                            point.X = aRightBottom.X - graphicsLine.Start.X;
                            point.Y = graphicsLine.Start.Y;
                            graphicsLine.Start = point;

                            point = new Point();
                            point.X = aRightBottom.X - graphicsLine.End.X;
                            point.Y = graphicsLine.End.Y;
                            graphicsLine.End = point;
                        }
                        graphicsLine.RefreshDrawing();
                        #endregion                        
                    }                 
                }
            }
        }

        public void RotateGraphic(Point aCenterPoint, double aAngle)
        {
            double _Sin = Math.Sin(aAngle * Math.PI / 180);
            double _Cos = Math.Cos(aAngle * Math.PI / 180);

            foreach (GraphicsBase roi in this.graphicsList)
            {
                if (roi.IsSelected == true)
                {
                    if (roi is GraphicsRectangleBase)
                    {
                        #region Rectangle,Ellipse Rotation
                        GraphicsRectangleBase graphicsRectangleBase = roi as GraphicsRectangleBase;
                                                
                        //��ǥ�� ��ȯ
                        graphicsRectangleBase.Left -= aCenterPoint.X;
                        graphicsRectangleBase.Top -= aCenterPoint.Y;
                        graphicsRectangleBase.Right -= aCenterPoint.X;
                        graphicsRectangleBase.Bottom -= aCenterPoint.Y;

                        //ȸ��
                        double rotateLeft = graphicsRectangleBase.Left * _Cos - graphicsRectangleBase.Top * _Sin;
                        double rotateTop = graphicsRectangleBase.Left * _Sin + graphicsRectangleBase.Top * _Cos;
                        double rotateRight = graphicsRectangleBase.Right * _Cos - graphicsRectangleBase.Bottom * _Sin;
                        double rotateBottom = graphicsRectangleBase.Right * _Sin + graphicsRectangleBase.Bottom * _Cos;

                        //��ǥ�� ����
                        graphicsRectangleBase.Left = aCenterPoint.X + Math.Min(rotateRight, rotateLeft);
                        graphicsRectangleBase.Top = aCenterPoint.Y + Math.Min(rotateTop, rotateBottom);
                        graphicsRectangleBase.Right = aCenterPoint.X + Math.Max(rotateRight, rotateLeft);
                        graphicsRectangleBase.Bottom = aCenterPoint.Y + Math.Max(rotateTop, rotateBottom);

                        graphicsRectangleBase.Move(0, 0, aCenterPoint.X * 2, aCenterPoint.Y * 2);
                        graphicsRectangleBase.RefreshDrawing();
                        #endregion                        
                    }
                    else if (roi is GraphicsPolyLine)
                    {
                        #region PolyLine Rotation
                        double rotateX = 0.0;
                        double rotateY = 0.0;
                        GraphicsPolyLine graphicsPolyLine = roi as GraphicsPolyLine;
                        
                        // ȸ��
                        for (int i = 0; i < graphicsPolyLine.Points.Length; i++)
                        {
                            graphicsPolyLine.Points[i].X -= aCenterPoint.X;
                            graphicsPolyLine.Points[i].Y -= aCenterPoint.Y;

                            rotateX = graphicsPolyLine.Points[i].X * _Cos - graphicsPolyLine.Points[i].Y * _Sin;
                            rotateY = graphicsPolyLine.Points[i].X * _Sin + graphicsPolyLine.Points[i].Y * _Cos;

                            graphicsPolyLine.Points[i].X = aCenterPoint.X + rotateX;
                            graphicsPolyLine.Points[i].Y = aCenterPoint.Y + rotateY;
                        }

                        graphicsPolyLine.Move(0, 0, aCenterPoint.X * 2, aCenterPoint.Y * 2);
                        graphicsPolyLine.RefreshDrawing();
                        #endregion      
                    }
                    else if (roi is GraphicsLine)
                    {
                        #region Line Rotation
                        GraphicsLine graphicsLine = roi as GraphicsLine;
                        // ������
                        Point point = new Point();
                        point.X = graphicsLine.Start.X - aCenterPoint.X;
                        point.Y = graphicsLine.Start.Y - aCenterPoint.Y;

                        double rotateX = point.X * _Cos - point.Y * _Sin;
                        double rotateY = point.X * _Sin + point.Y * _Cos;

                        point.X = aCenterPoint.X + rotateX;
                        point.Y = aCenterPoint.Y + rotateY;
                        graphicsLine.Start = point;

                        // ����
                        point = new Point();
                        point.X = graphicsLine.End.X - aCenterPoint.X;
                        point.Y = graphicsLine.End.Y - aCenterPoint.Y;

                        rotateX = point.X * _Cos - point.Y * _Sin;
                        rotateY = point.X * _Sin + point.Y * _Cos;

                        point.X = aCenterPoint.X + rotateX;
                        point.Y = aCenterPoint.Y + rotateY;
                        graphicsLine.End = point;

                        graphicsLine.Move(0, 0, aCenterPoint.X * 2, aCenterPoint.Y * 2);
                        graphicsLine.RefreshDrawing();
                        #endregion
                    }
                }
            }
        }

        // 2011-09-01, Minseok Hwang.
        public void UpdateSelectedGraphic()
        {
            Point point = Mouse.GetPosition(this);

            List<GraphicsBase> hittedList = new List<GraphicsBase>();
            foreach (GraphicsBase graphic in graphicsList)
            {
                if (graphic.MakeHitTest(point) >= 0)
                {
                    hittedList.Add(graphic);
                }
            }

            if (hittedList.Count > 0)
            {
                SelectedGraphic = hittedList[hittedList.Count - 1]; // ���� �տ� ���� GraphicsBase�� SelectedGraphic���� �����Ѵ�.
            }
            else
            {
                SelectedGraphic = null;
            }
        }

        /// <summary>   Context menu item is clicked. </summary>
        /// <param name="sender">   Source of the event. </param>
        /// <param name="e">        Routed event information. </param>
        void contextMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MenuItem item = sender as MenuItem;

            if (item == null)
            {
                return;
            }

            ContextMenuCommand command = (ContextMenuCommand)item.Tag;
            ContextMenuChangeEventHandler eventRunner = ContextMenuChangeEvent;

            switch (command)
            {
                case ContextMenuCommand.SetROIArrayCopy:
                    if (eventRunner != null)
                    {
                        eventRunner(ContextMenuCommand.SetROIArrayCopy);
                    }
                    break;

                case ContextMenuCommand.SetFiducialUnit:
                    ChangeFiducialRegion(CaptionHelper.FiducialUnitRegionCaption);
                    break;
                case ContextMenuCommand.UnsetFiducialUnit:
                    UnsetFiducialRegion();
                    break;

                case ContextMenuCommand.SetFiducialOuter:
                    ChangeFiducialRegion(CaptionHelper.FiducialOuterRegionCaption);
                    break;
                case ContextMenuCommand.UnsetFiducialOuter:
                    UnsetFiducialRegion();
                    break;

                case ContextMenuCommand.SetExceptInspectionRegion:
                    CommandChangeState setExceptCommandChangeState = new CommandChangeState(SelectedGraphic);
                    SelectedGraphic.RegionType = GraphicsRegionType.Except;
                    SelectedGraphic.ObjectColor = GraphicsColors.Blue;
                    SelectedGraphic.TextColor = GraphicsColors.Blue;
                    SelectedGraphic.Caption = CaptionHelper.ExceptionalMaskCaption;
                    setExceptCommandChangeState.NewState(SelectedGraphic);
                    AddCommandToHistory(setExceptCommandChangeState);
                    break;

                case ContextMenuCommand.UnSetExceptInspectionRegion:
                    CommandChangeState unsetExceptCommandChangeState = new CommandChangeState(SelectedGraphic);
                    SelectedGraphic.RegionType = GraphicsRegionType.Inspection;
                    SelectedGraphic.ObjectColor = GraphicsColors.Green;
                    SelectedGraphic.TextColor = GraphicsColors.Green;
                    SelectedGraphic.Caption = "";
                    unsetExceptCommandChangeState.NewState(SelectedGraphic);
                    AddCommandToHistory(unsetExceptCommandChangeState);
                    if (eventRunner != null)
                    {
                        eventRunner(ContextMenuCommand.UnSetExceptInspectionRegion);
                    }
                    break;

                case ContextMenuCommand.SetUnitRow:
                    if (eventRunner != null)
                    {
                        eventRunner(ContextMenuCommand.SetUnitRow);
                    }
                    break;
                case ContextMenuCommand.SetUnitColumn:
                    if (eventRunner != null)
                    {
                        eventRunner(ContextMenuCommand.SetUnitColumn);
                    }
                    break;
                case ContextMenuCommand.SelectAll:
                    SelectAll();
                    break;
                case ContextMenuCommand.UnselectAll:
                    UnselectAll();
                    break;
                case ContextMenuCommand.Delete:
                    if (SelectionCount > 0)
                    {
                        Delete();
                    }
                    break;
                case ContextMenuCommand.DeleteAll:
                    DeleteAll();
                    break;
                case ContextMenuCommand.MoveToFront:
                    MoveToFront();
                    break;
                case ContextMenuCommand.MoveToBack:
                    MoveToBack();
                    break;
                case ContextMenuCommand.Undo:
                    Undo();
                    break;
                case ContextMenuCommand.Redo:
                    Redo();
                    break;
                case ContextMenuCommand.SerProperties:
                    SetProperties();
                    break;
                case ContextMenuCommand.RotateROI90:
                    if (eventRunner != null)
                    {
                        eventRunner(ContextMenuCommand.RotateROI90);
                    }
                    break;
                case ContextMenuCommand.RotateROI180:
                    if (eventRunner != null)
                    {
                        eventRunner(ContextMenuCommand.RotateROI180);
                    }
                    break;
                case ContextMenuCommand.SymmetryROIUpDown:
                    if (eventRunner != null)
                    {
                        eventRunner(ContextMenuCommand.SymmetryROIUpDown);
                    }
                    break;
                case ContextMenuCommand.SymmetryROILeftRight:
                    if (eventRunner != null)
                    {
                        eventRunner(ContextMenuCommand.SymmetryROILeftRight);
                    }
                    break;
                case ContextMenuCommand.LocalAlign:
                    if (eventRunner != null)
                    {
                        eventRunner(ContextMenuCommand.LocalAlign);
                    }
                    break;
            }
        }

        /// <summary>   Mouse capture is lost. </summary>
        /// <param name="sender">   Source of the event. </param>
        /// <param name="e">        Mouse event information. </param>
        public void DrawingCanvas_LostMouseCapture(object sender, MouseEventArgs e)
        {
            if (this.IsMouseCaptured)
            {
                CancelCurrentOperation();
                UpdateState();
            }
        }

        /// <summary>   Handle keyboard input. </summary>
        /// <param name="sender">   Source of the event. </param>
        /// <param name="e">        Key event information. </param>
        public void DrawingCanvas_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (Keyboard.Modifiers == ModifierKeys.Control)
                {
                    switch (e.Key)
                    {
                        case Key.A:
                            SelectedGraphic = null;
                            SelectAll();
                            break;
                        case Key.C:
                            if (!IsBasedCanvas)
                            {
                                if (SelectionCount > 0)
                                {
                                    CopyGraphics();
                                    if (graphicsClipboardList.Count > 0)
                                    {
                                        PasteGraphics();
                                    }
                                }                                
                            }
                            else
                            {
                                NotifyConstraintEventHandler eventRunner = NotifyConstraintEvent;
                                if (eventRunner != null)
                                {
                                    eventRunner("��ü���󿡼��� ���� ���� & �ٿ��ֱ� ����� �������� �ʽ��ϴ�.");
                                }
                            }
                            break;
                        case Key.H:
                            // �� ����
                            break;
                        case Key.R:
                            // �� ����
                            break;
                        case Key.Q:
                            // �࿭ ����
                            break;
                        case Key.Y:
                            if (!IsBasedCanvas) Redo();
                            break;
                        case Key.Z:
                            if (!IsBasedCanvas) Undo();
                            break;
                        case Key.Left:
                            MoveGraphics(-1, 0);
                            break;
                        case Key.Right:
                            MoveGraphics(1, 0);
                            break;
                        case Key.Up:
                            MoveGraphics(0, -1);
                            break;
                        case Key.Down:
                            MoveGraphics(0, 1);
                            break;
                    }
                }
                else
                {
                    switch (e.Key)
                    {
                        case Key.Delete:
                            Delete();
                            break;
                        case Key.Escape:
                            if (this.IsMouseCaptured)
                            {
                                CancelCurrentOperation();
                            }
                            break;
                        case Key.Left:
                            MoveGraphics(-10, 0);
                            break;
                        case Key.Right:
                            MoveGraphics(10, 0);
                            break;
                        case Key.Up:
                            MoveGraphics(0, -10);
                            break;
                        case Key.Down:
                            MoveGraphics(0, 10);
                            break;
                    }
                }
            }
            catch
            {

            }
        }

        // �ݺ� ���� ���
        private void UndoIterationGraphics(GraphicsRectangle aLeftTopGraphic)
        {
            GraphicsRectangle motherROI = (aLeftTopGraphic.MotherROI == null) ? aLeftTopGraphic : aLeftTopGraphic.MotherROI as GraphicsRectangle;
            int nLength = graphicsList.Count;
            for (int i = 0; i < nLength; i++)
            {
                if (graphicsList[i] == aLeftTopGraphic)
                {
                    continue;
                }
                if (graphicsList[i] is GraphicsRectangle && ((GraphicsRectangle)graphicsList[i]).MotherROI == motherROI)
                {
                    graphicsList.RemoveAt(i);
                    i--;
                    nLength--;
                }
            }
            if (aLeftTopGraphic.MotherROI != null)
            {
                graphicsList.Remove(aLeftTopGraphic.MotherROI);
            }
        }

        // �ݺ� ����
        public void IterationGraphics(GraphicsRectangle fiducialGraphic)
        {
            #region set local variables.
            int unitColumns = fiducialGraphic.IterationValue.Column;
            int unitRows = fiducialGraphic.IterationValue.Row;
            double unitXPitch = fiducialGraphic.IterationValue.XPitch;
            double unitYPitch = fiducialGraphic.IterationValue.YPitch;

            int blockColumns = fiducialGraphic.BlockIterationValue.Column;
            int blockRows = fiducialGraphic.BlockIterationValue.Row;
            double blockXPitch = fiducialGraphic.BlockIterationValue.XPitch;
            double blockYPitch = fiducialGraphic.BlockIterationValue.YPitch;

            int unitRowPerBlockRow = (int)Math.Round((double)unitRows / (double)blockRows);
            int unitColumnPerBlockColumn = (int)Math.Round((double)unitColumns / (double)blockColumns);
            #endregion

            double columnSpace = 0;
            double rowSpace = 0;

            // �ݺ� ������ ROI�� ����������� ROI�� �������� �����Ѵ�.
            if (!(fiducialGraphic.IterationXPosition == 0 && fiducialGraphic.IterationYPosition == 0))
            {
                foreach (GraphicsBase g in graphicsList)
                {
                    if (g is GraphicsRectangle &&
                        (g.RegionType == GraphicsRegionType.UnitRegion || g.RegionType == GraphicsRegionType.OuterRegion))
                    {
                        if (((GraphicsRectangle)g).MotherROI == fiducialGraphic &&
                            ((GraphicsRectangle)g).IterationXPosition == 0 &&
                            ((GraphicsRectangle)g).IterationYPosition == 0)
                        {
                            GraphicsRectangle mostLeftTopGraphic = g as GraphicsRectangle;
                            mostLeftTopGraphic.SymmetryValue = fiducialGraphic.SymmetryValue;
                            mostLeftTopGraphic.IterationValue = fiducialGraphic.IterationValue;
                            mostLeftTopGraphic.BlockIterationValue = fiducialGraphic.BlockIterationValue;

                            fiducialGraphic = mostLeftTopGraphic;

                            break;
                        }
                    }
                }
            }
            UndoIterationGraphics(fiducialGraphic);

            Debug.Assert(fiducialGraphic.IterationXPosition == 0);
            Debug.Assert(fiducialGraphic.IterationYPosition == 0);

            for (int row = 0; row < unitRows; row++)
            {
                if (row >= 1 && row % unitRowPerBlockRow == 0)
                {
                    rowSpace += blockYPitch;
                }

                for (int column = 0; column < unitColumns; column++)
                {
                    if (column == 0 && row == 0) continue;
                    
                    if (column == 0)
                    {
                        columnSpace = 0;
                    }
                    else
                    {
                        columnSpace += unitXPitch;
                    }

                    if (column % unitColumnPerBlockColumn == 0 && column >= 1)
                    {
                        columnSpace += blockXPitch;
                    }

                    GraphicsRectangle graphic = new GraphicsRectangle(fiducialGraphic.Left + columnSpace,
                        fiducialGraphic.Top + rowSpace,
                        fiducialGraphic.Right + columnSpace,
                        fiducialGraphic.Bottom + rowSpace,
                        LineWidth,
                        fiducialGraphic.RegionType,
                        GraphicsColors.Green,
                        GraphicsColors.Green,
                        fiducialGraphic.ActualScale,
                        fiducialGraphic.SymmetryValue,
                        fiducialGraphic.IterationValue,
                        fiducialGraphic.BlockIterationValue,
                        false,
                        fiducialGraphic);
                    graphic.IsValidSectionROI = fiducialGraphic.IsValidSectionROI;
                    graphic.IterationXPosition = column;
                    graphic.IterationYPosition = row;
                    graphic.Caption = CaptionHelper.GetSectionPositionCaption(graphic);
                    graphic.IsCanMove = false;

                    graphicsList.Add(graphic);
                }
                columnSpace = 0;
                rowSpace += unitYPitch;
            }

            if (fiducialGraphic.RegionType == GraphicsRegionType.UnitRegion)
            {
                fiducialGraphic.Caption = CaptionHelper.FiducialUnitRegionCaption;
            }
            else if (fiducialGraphic.RegionType == GraphicsRegionType.OuterRegion)
            {
                fiducialGraphic.Caption = CaptionHelper.FiducialOuterRegionCaption;
            }
            fiducialGraphic.IsValidSectionROI = true;
            fiducialGraphic.IsFiducialRegion = true;
            fiducialGraphic.MotherROI = null;

            UpdateState();
            UnselectAll();
        }

        /// <summary>   Copies the graphics. </summary>
        /// <remarks>   Minseok,Hwang, 2011-08-18. </remarks>
        private void CopyGraphics()
        {
            if (this.SelectionCount > 0)
            {
                graphicsClipboardList.Clear();

                foreach (GraphicsBase b in Selection)
                {
                    if (b.RegionType == GraphicsRegionType.StripAlign ||
                        b.RegionType == GraphicsRegionType.UnitAlign)
                    {
                        continue;
                    }

                    GraphicsBase graphic = b.CreateSerializedObject().CreateGraphics();
                    graphic.IsSelected = false;
                    graphicsClipboardList.Add(graphic);
                }
            }
        }

        /// <summary>   Paste graphics. </summary>
        /// <remarks>   Minseok,Hwang, 2011-08-18. </remarks>
        private void PasteGraphics()
        {
            UnselectAll();

            List<GraphicsBase> newGraphicsClipboardList = new List<GraphicsBase>();
            foreach (GraphicsBase b in graphicsClipboardList)
            {
                GraphicsBase graphic = b.CreateSerializedObject().CreateGraphics();
                graphic.Id = graphic.GetHashCode();
                graphic.IsSelected = true;
                graphic.Move(5, 5, this.ActualWidth, this.ActualHeight);
                graphic.RefreshDrawing();

                if (CanDraw(graphic, (int)Math.Round(this.ActualWidth), (int)Math.Round(this.ActualHeight)))
                {
                    graphicsList.Add(graphic);

                }
                newGraphicsClipboardList.Add(graphic);
            }
            graphicsClipboardList.Clear();
            graphicsClipboardList = newGraphicsClipboardList;

            undoManager.AddCommandToHistory(new CommandAdd(this));
            UpdateState();
        }

        /// <summary>   Move graphics. </summary>
        /// <remarks>   Minseok,Hwang, 2011-08-19. </remarks>
        /// <param name="deltaX">   The delta x coordinate. </param>
        /// <param name="deltaY">   The delta y coordinate. </param>
        private void MoveGraphics(double deltaX, double deltaY)
        {
            HelperFunctions.MoveGraphics(this, deltaX, deltaY);
            UpdateState();
        }

        /// <summary>
        /// UndoManager state is changed. Refresh CanUndo, CanRedo and IsDirty properties.
        /// </summary>
        /// <param name="sender">   Source of the event. </param>
        /// <param name="e">        Event information. </param>
        void undoManager_StateChanged(object sender, EventArgs e)
        {
            this.CanUndo = undoManager.CanUndo;
            this.CanRedo = undoManager.CanRedo;

            // Set IsDirty only if it is actually changed.
            // Setting IsDirty raises event for client.
            if (undoManager.IsDirty != this.IsDirty)
            {
                this.IsDirty = undoManager.IsDirty;
            }
        }
        #endregion Other Event Handlers

        #region Other Functions
        /// <summary>   Create context menu. </summary>
        void CreateContextMenu()
        {
            contextMenu = new ContextMenu();

            MenuItem menuItem;

            menuItem = new MenuItem();
            menuItem.Header = "ROI �ݺ� ����";
            menuItem.Tag = ContextMenuCommand.SetROIArrayCopy;
            menuItem.Click += contextMenuItem_Click;
            contextMenu.Items.Add(menuItem);

            // Unit Region�� ���� ContextMenu.
            menuItem = new MenuItem();
            menuItem.Header = "���� Unit ����";
            menuItem.Tag = ContextMenuCommand.SetFiducialUnit;
            menuItem.Click += contextMenuItem_Click;
            contextMenu.Items.Add(menuItem);

            menuItem = new MenuItem();
            menuItem.Header = "���� Unit ��������";
            menuItem.Tag = ContextMenuCommand.UnsetFiducialUnit;
            menuItem.Click += contextMenuItem_Click;
            contextMenu.Items.Add(menuItem);
            
            menuItem = new MenuItem();
            menuItem.Header = "���� �ܰ����� ����";
            menuItem.Tag = ContextMenuCommand.SetFiducialOuter;
            menuItem.Click += contextMenuItem_Click;
            contextMenu.Items.Add(menuItem);

            menuItem = new MenuItem();
            menuItem.Header = "���� �ܰ����� ��������";
            menuItem.Tag = ContextMenuCommand.UnsetFiducialOuter;
            menuItem.Click += contextMenuItem_Click;
            contextMenu.Items.Add(menuItem);

            contextMenu.Items.Add(new Separator());

            menuItem = new MenuItem();
            menuItem.Header = "�˻� ���ܿ��� ����";
            menuItem.Tag = ContextMenuCommand.SetExceptInspectionRegion;
            menuItem.Click += contextMenuItem_Click;
            contextMenu.Items.Add(menuItem);

            menuItem = new MenuItem();
            menuItem.Header = "�˻� ���ܿ��� ��������";
            menuItem.Tag = ContextMenuCommand.UnSetExceptInspectionRegion;
            menuItem.Click += contextMenuItem_Click;
            contextMenu.Items.Add(menuItem);

            contextMenu.Items.Add(new Separator());

            menuItem = new MenuItem();
            menuItem.Header = "�˻� ��� �߰�";
            menuItem.Tag = ContextMenuCommand.AddInspectItem;
            menuItem.Click += contextMenuItem_Click;
            contextMenu.Items.Add(menuItem);

            menuItem = new MenuItem();
            menuItem.Header = "Local Align";
            menuItem.Tag = ContextMenuCommand.LocalAlign;
            menuItem.Click += contextMenuItem_Click;
            contextMenu.Items.Add(menuItem);

            contextMenu.Items.Add(new Separator());

            menuItem = new MenuItem();
            menuItem.Header = "ROI ��� ����";
            menuItem.Tag = ContextMenuCommand.CopyROIToTop;
            contextMenu.Items.Add(menuItem);

            menuItem = new MenuItem();
            menuItem.Header = "ROI �Ϻ� ����";
            menuItem.Tag = ContextMenuCommand.CopyROIToBottom;
            contextMenu.Items.Add(menuItem);

            menuItem = new MenuItem();
            menuItem.Header = "ROI ���� ����";
            menuItem.Tag = ContextMenuCommand.CopyROIToTrans;
            contextMenu.Items.Add(menuItem);

            contextMenu.Items.Add(new Separator());

            #region ROI ȸ��
            menuItem = new MenuItem();
            menuItem.Header = "ROI ȸ��";
            menuItem.Tag = ContextMenuCommand.RotateROI;

            MenuItem subItem = new MenuItem();
            subItem.Header = "90��ȸ��";
            subItem.Tag = ContextMenuCommand.RotateROI90;
            subItem.Click += contextMenuItem_Click;
            menuItem.Items.Add(subItem);

            subItem = new MenuItem();
            subItem.Header = "180��ȸ��";
            subItem.Tag = ContextMenuCommand.RotateROI180;
            subItem.Click += contextMenuItem_Click;
            menuItem.Items.Add(subItem);
            contextMenu.Items.Add(menuItem);
            #endregion

            #region ROI ��Ī
            menuItem = new MenuItem();
            menuItem.Header = "ROI ��Ī";
            menuItem.Tag = ContextMenuCommand.SymmetryROI;

            subItem = new MenuItem();
            subItem.Header = "���� ��Ī";
            subItem.Tag = ContextMenuCommand.SymmetryROIUpDown;
            subItem.Click += contextMenuItem_Click;
            menuItem.Items.Add(subItem);

            subItem = new MenuItem();
            subItem.Header = "�¿� ��Ī";
            subItem.Tag = ContextMenuCommand.SymmetryROILeftRight;
            subItem.Click += contextMenuItem_Click;
            menuItem.Items.Add(subItem);
            contextMenu.Items.Add(menuItem);
            #endregion

            #region Unused Context Menu.
            //contextMenu.Items.Add(new Separator());
            
            //menuItem = new MenuItem();
            //menuItem.Header = "��ü ����";
            //menuItem.Tag = ContextMenuCommand.SelectAll;
            //menuItem.Click += contextMenuItem_Click;
            //contextMenu.Items.Add(menuItem);

            //menuItem = new MenuItem();
            //menuItem.Header = "��ü ���� ����";
            //menuItem.Tag = ContextMenuCommand.UnselectAll;
            //menuItem.Click += contextMenuItem_Click;
            //contextMenu.Items.Add(menuItem);

            //menuItem = new MenuItem();
            //menuItem.Header = "����";
            //menuItem.Tag = ContextMenuCommand.Delete;
            //menuItem.Click += contextMenuItem_Click;
            //contextMenu.Items.Add(menuItem);
            
            //menuItem = new MenuItem();
            //menuItem.Header = "��ü ����";
            //menuItem.Tag = ContextMenuCommand.DeleteAll;
            //menuItem.Click += contextMenuItem_Click;
            //contextMenu.Items.Add(menuItem);
            #endregion
        }

        public void ContextMenuBinding(ContextMenuCommand aTag)
        {
            foreach (MenuItem submenu in contextMenu.Items)
            {
                if ((ContextMenuCommand)submenu.Tag == ContextMenuCommand.CopyROIToTop)
                {
                    //submenu.ItemsSource = aSectionInfo;
                }
            }
        }

        /// <summary>   Show context menu. </summary>
        /// <param name="e">    Mouse button event information. </param>
        void ShowContextMenu(MouseButtonEventArgs e)
        {
            // Change current selection if necessary

            Point point = e.GetPosition(this);

            GraphicsBase o = null;

            for (int i = graphicsList.Count - 1; i >= 0; i--)
            {
                if (((GraphicsBase)graphicsList[i]).MakeHitTest(point) == 0)
                {
                    o = (GraphicsBase)graphicsList[i];
                    break;
                }
            }

            if (o != null)
            {
                if (!o.IsSelected)
                {
                    UnselectAll();
                }

                // Select clicked object
                o.IsSelected = true;
            }
            else
            {
                UnselectAll();
            }

            UpdateState();

            MenuItem item;

            /// Enable/disable menu items.
            foreach (object obj in contextMenu.Items)
            {
                item = obj as MenuItem;

                if (item != null)
                {
                    ContextMenuCommand command = (ContextMenuCommand)item.Tag;

                    switch (command)
                    {
                        case ContextMenuCommand.SetROIArrayCopy:
                            item.IsEnabled = (SelectedGraphic != null && SelectedGraphic is GraphicsRectangle &&
                                              SelectedGraphic.RegionType == GraphicsRegionType.UnitRegion);
                            break;
                        case ContextMenuCommand.SetFiducialUnit:
                            item.IsEnabled = (SelectedGraphic != null && SelectedGraphic is GraphicsRectangle &&
                                              SelectedGraphic.RegionType == GraphicsRegionType.UnitRegion &&
                                              ((GraphicsRectangle)SelectedGraphic).IsFiducialRegion == false);
                            break;
                        case ContextMenuCommand.UnsetFiducialUnit:
                            item.IsEnabled = (SelectedGraphic != null && SelectedGraphic is GraphicsRectangle &&
                                              SelectedGraphic.RegionType == GraphicsRegionType.UnitRegion &&
                                              ((GraphicsRectangle)SelectedGraphic).IsFiducialRegion == true);
                            break;

                        case ContextMenuCommand.SetFiducialOuter:
                            item.IsEnabled = (SelectedGraphic != null && SelectedGraphic is GraphicsRectangle &&
                                              SelectedGraphic.RegionType == GraphicsRegionType.OuterRegion &&
                                              ((GraphicsRectangle)SelectedGraphic).IsFiducialRegion == false);
                            break;
                        case ContextMenuCommand.UnsetFiducialOuter:
                            item.IsEnabled = (SelectedGraphic != null && SelectedGraphic is GraphicsRectangle &&
                                              SelectedGraphic.RegionType == GraphicsRegionType.OuterRegion &&
                                              ((GraphicsRectangle)SelectedGraphic).IsFiducialRegion == true);
                            break;

                        case ContextMenuCommand.SetExceptInspectionRegion:
                            item.IsEnabled = (SelectedGraphic != null &&
                                              SelectedGraphic.RegionType == GraphicsRegionType.Inspection);
                            break;
                        case ContextMenuCommand.UnSetExceptInspectionRegion:
                            item.IsEnabled = (SelectedGraphic != null &&
                                              SelectedGraphic.RegionType == GraphicsRegionType.Except);
                            break;

                        case ContextMenuCommand.SetUnitRow:
                            item.IsEnabled = (SelectedGraphic != null && SelectedGraphic is GraphicsRectangle);
                            break;
                        case ContextMenuCommand.SetUnitColumn:
                            item.IsEnabled = (SelectedGraphic != null && SelectedGraphic is GraphicsRectangle);
                            break;
                        case ContextMenuCommand.SelectAll:
                            item.IsEnabled = CanSelectAll;
                            break;
                        case ContextMenuCommand.UnselectAll:
                            item.IsEnabled = CanUnselectAll;
                            break;
                        case ContextMenuCommand.Delete:
                            item.IsEnabled = CanDelete;
                            break;
                        case ContextMenuCommand.DeleteAll:
                            item.IsEnabled = CanDeleteAll;
                            break;
                        case ContextMenuCommand.MoveToFront:
                            item.IsEnabled = CanMoveToFront;
                            break;
                        case ContextMenuCommand.MoveToBack:
                            item.IsEnabled = CanMoveToBack;
                            break;
                        case ContextMenuCommand.Undo:
                            item.IsEnabled = CanUndo;
                            break;
                        case ContextMenuCommand.Redo:
                            item.IsEnabled = CanRedo;
                            break;
                        case ContextMenuCommand.SerProperties:
                            item.IsEnabled = CanSetProperties;
                            break;

                        case ContextMenuCommand.CopyROIToTop:
                        case ContextMenuCommand.CopyROIToBottom:
                        case ContextMenuCommand.CopyROIToTrans:
                        case ContextMenuCommand.RotateROI:
                        case ContextMenuCommand.RotateROI90:
                            item.IsEnabled = (SelectedGraphic != null && SelectedGraphic is GraphicsBase &&
                                              ((SelectedGraphic.RegionType == GraphicsRegionType.Inspection) || (SelectedGraphic.RegionType == GraphicsRegionType.Except)) &&
                                              (SelectionCount > 0));
                            break;
                        case ContextMenuCommand.RotateROI180:
                            item.IsEnabled = (SelectedGraphic != null && SelectedGraphic is GraphicsBase &&
                                              ((SelectedGraphic.RegionType == GraphicsRegionType.Inspection) || (SelectedGraphic.RegionType == GraphicsRegionType.Except)) &&
                                              (SelectionCount > 0));
                            break;
                        case ContextMenuCommand.SymmetryROI:
                        case ContextMenuCommand.SymmetryROIUpDown:
                            item.IsEnabled = (SelectedGraphic != null && SelectedGraphic is GraphicsBase &&
                                              ((SelectedGraphic.RegionType == GraphicsRegionType.Inspection) || (SelectedGraphic.RegionType == GraphicsRegionType.Except)) &&
                                              (SelectionCount > 0));
                            break;
                        case ContextMenuCommand.SymmetryROILeftRight:
                            item.IsEnabled = (SelectedGraphic != null && SelectedGraphic is GraphicsBase &&
                                              ((SelectedGraphic.RegionType == GraphicsRegionType.Inspection) || (SelectedGraphic.RegionType == GraphicsRegionType.Except)) &&
                                              (SelectionCount > 0));
                            break;

                        case ContextMenuCommand.AddInspectItem:
                            item.IsEnabled = (SelectedGraphic != null && SelectionCount == 1 &&
                                              !(SelectedGraphic.RegionType == GraphicsRegionType.UnitRegion ||
                                               SelectedGraphic.RegionType == GraphicsRegionType.OuterRegion ||
                                               SelectedGraphic.RegionType == GraphicsRegionType.StripAlign));
                            break;
                        case ContextMenuCommand.LocalAlign:
                            item.IsEnabled = (SelectedGraphic != null && SelectedGraphic is GraphicsBase &&
                                              ((SelectedGraphic.RegionType == GraphicsRegionType.Inspection) || (SelectedGraphic.RegionType == GraphicsRegionType.Except)) &&
                                              (SelectionCount == 1));
                            break;
                    }
                }
            }

            contextMenu.IsOpen = true;
        }

        /// <summary>
        /// Cancel currently executed operation: add new object or group selection.
        /// Called when mouse capture is lost or Esc is pressed.
        /// </summary>
        void CancelCurrentOperation()
        {
            if (Tool == ToolType.Pointer)
            {
                if (graphicsList.Count > 0)
                {
                    if (graphicsList[graphicsList.Count - 1] is GraphicsSelectionRectangle)
                    {
                        // Delete selection rectangle if it exists
                        graphicsList.RemoveAt(graphicsList.Count - 1);
                    }
                    else
                    {
                        // Pointer tool moved or resized graphics object.
                        // Add this action to the history
                        toolPointer.AddChangeToHistory(this);
                    }
                }
            }
            else if (Tool > ToolType.Pointer && Tool < ToolType.Max)
            {
                // Delete last graphics object which is currently drawn
                if (graphicsList.Count > 0)
                {                    
                    if ( Tool == ToolType.PolyLine)
                    {
                        ToolPolyLine toolPolyLine = tools[(int)ToolType.PolyLine] as ToolPolyLine;
                        toolPolyLine.IsFirstClicked = true;

                        ChangeToolEventHandler eventRunner = ToolTypeChangeEvent;
                        if (eventRunner != null)
                        {
                            eventRunner(ToolType.Pointer);
                        }
                    }                    
                    graphicsList.RemoveAt(graphicsList.Count - 1);
                }
            }

            Tool = ToolType.Pointer;

            this.ReleaseMouseCapture();
            this.Cursor = HelperFunctions.DefaultCursor;
        }

        /// <summary>
        /// Hide in-place editing textbox. Called from TextTool, when user pressed Enter or Esc, or from
        /// this class, when user clicks on the canvas.
        /// 
        /// graphicsText passed to this function can be new text added by ToolText, or existing text
        /// opened for editing. If ToolText.OldText is empty, this is new object. If not, this is
        /// existing object.
        /// </summary>
        /// <param name="graphicsText"> The graphics text. </param>
        internal void HideTextbox(GraphicsText graphicsText)
        {
            if (toolText.TextBox == null)
            {
                return;
            }

            graphicsText.IsSelected = true;   // restore selection which was removed for better textbox appearance


            if (toolText.TextBox.Text.Trim().Length == 0)
            {
                // Textbox is empty: remove text object.

                if (!String.IsNullOrEmpty(toolText.OldText))  // existing text was edited
                {
                    // Since text object is removed now,
                    // Add Delete command to the history
                    undoManager.AddCommandToHistory(new CommandDelete(this));
                }

                // Remove empty text object
                graphicsList.Remove(graphicsText);
            }
            else
            {
                if (!String.IsNullOrEmpty(toolText.OldText))  // existing text was edited
                {
                    if (toolText.TextBox.Text.Trim() != toolText.OldText)     // text was really changed
                    {
                        // Create command
                        CommandChangeState command = new CommandChangeState(graphicsText);

                        // Make change in the text object
                        graphicsText.Text = toolText.TextBox.Text.Trim();
                        graphicsText.UpdateRectangle();

                        // Keep state after change and add command to the history
                        command.NewState(graphicsText);
                        undoManager.AddCommandToHistory(command);
                    }
                }
                else                                          // new text was added
                {
                    // Make change in the text object
                    graphicsText.Text = toolText.TextBox.Text.Trim();
                    graphicsText.UpdateRectangle();

                    // Add command to the history
                    undoManager.AddCommandToHistory(new CommandAdd(graphicsText));
                }
            }

            // Remove textbox and set it to null.
            this.Children.Remove(toolText.TextBox);
            toolText.TextBox = null;

            // This enables back all ApplicationCommands,
            // which are disabled while textbox is active.
            this.Focus();
        }

        /// <summary>   Open in-place edit box if GraphicsText is clicked. </summary>
        /// <param name="e">    Mouse button event information. </param>
        void HandleDoubleClick(MouseButtonEventArgs e)
        {
            Point point = e.GetPosition(this);

            // Enumerate all text objects
            for (int i = graphicsList.Count - 1; i >= 0; i--)
            {
                GraphicsText t = graphicsList[i] as GraphicsText;
                if (t != null)
                {
                    if (t.Contains(point))
                    {
                        toolText.CreateTextBox(t, this);
                        return;
                    }
                }
            }
        }

        /// <summary>   Add command to history. </summary>
        /// <param name="command">  The command. </param>
        internal void AddCommandToHistory(CommandBase command)
        {
            undoManager.AddCommandToHistory(command);
        }

        /// <summary>   Clear Undo history. </summary>
        public void ClearHistory()
        {
            undoManager.ClearHistory();
        }

        /// <summary>
        /// Update state of Can* dependency properties used for Edit commands. This function calls after
        /// any change in drawing canvas state, caused by user commands. Helps to keep client controls
        /// state up-to-date, in the case if Can* properties are used for binding.
        /// </summary>
        void UpdateState()
        {
            bool hasObjects = (this.Count > 0);
            bool hasSelectedObjects = (this.SelectionCount > 0);

            CanSelectAll = hasObjects;
            CanUnselectAll = hasObjects;
            CanDelete = hasSelectedObjects;
            CanDeleteAll = hasObjects;

            CanMoveToFront = hasSelectedObjects;
            CanMoveToBack = hasSelectedObjects;

            // �ʿ���� �����̹Ƿ� ȣ������ �ʵ��� �Ѵ�.
            // CanSetProperties = HelperFunctions.CanApplyProperties(this);
        }
        #endregion Other Functions

        /// <summary>   Unset fiducial region. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-15. </remarks>
        private void UnsetFiducialRegion()
        {
            ((GraphicsRectangle)SelectedGraphic).IsFiducialRegion = false;
            SelectedGraphic.Caption = CaptionHelper.GetSectionPositionCaption(SelectedGraphic as GraphicsRectangle);
        }

        /// <summary>   Change fiducial region. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-15. </remarks>
        /// <param name="strCaption">   The string caption. </param>
        private void ChangeFiducialRegion(string strCaption)
        {
            // CommandChangeState �ּ� ó��. (��ü ���󿡼� Undo / Redo ��� ����)
            GraphicsRectangle targetGraphic = SelectedGraphic as GraphicsRectangle;
            if (SelectedGraphic is GraphicsRectangle)
            {
                GraphicsRectangle motherROI = targetGraphic.MotherROI as GraphicsRectangle;
                if (motherROI != null)
                {
                    motherROI.IsFiducialRegion = false;
                    motherROI.Caption = CaptionHelper.GetSectionPositionCaption(motherROI);

                    foreach (GraphicsBase graphic in graphicsList)
                    {
                        if (graphic is GraphicsRectangle && ((GraphicsRectangle)graphic).MotherROI == motherROI)
                        {
                            ((GraphicsRectangle)graphic).MotherROI = targetGraphic;
                        }
                    }
                    targetGraphic.IsFiducialRegion = true;
                    targetGraphic.Caption = strCaption;
                    targetGraphic.MotherROI = null;
                    motherROI.MotherROI = targetGraphic;
                }
            }
        }

        /// <summary>   Gets the section roi count. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-17. </remarks>
        /// <returns>   The section roi count. </returns>
        public int GetSectionROICount()
        {
            int sectionROICount = 0;
            foreach (GraphicsBase graphic in graphicsList)
            {
                if (graphic.RegionType == GraphicsRegionType.StripAlign)
                {
                    sectionROICount++;
                }
                else if (graphic is GraphicsRectangle && ((GraphicsRectangle)graphic).MotherROI == null)
                {
                    sectionROICount++;
                }
            }

            return sectionROICount;
        }

        public void AddLocalAlign()
        {
            List<GraphicsBase> newGraphicsList = new List<GraphicsBase>();

            foreach (GraphicsBase graphic in Selection)
            {
                if (graphic.IsSelected)
                {
                    if (graphic.LocalAligns == null)
                    {
                        graphic.LocalAligns = new GraphicsRectangle[Definitions.MAX_LOCAL_ALIGN_COUNT];
                    }

                    int localAlignIndex = 0;
                    foreach (GraphicsRectangle graphicsRectangle in graphic.LocalAligns)
                    {
                        if (graphicsRectangle == null)
                        {
                            double Left = 0.0;
                            double Top = 0.0;
                            double Right = 0.0;
                            double Bottom = 0.0;

                            switch (localAlignIndex) // Count�� �׷��� Local Align�� ��ġ�� �����Ѵ�.
                            {
                                case 0: // �»��
                                    Left = graphic.boundaryRect.Left + 15;
                                    Top = graphic.boundaryRect.Top + 15;
                                    break;
                                case 1: // ���ϱ�
                                    Left = graphic.boundaryRect.Right - 45;
                                    Top = graphic.boundaryRect.Bottom - 45;
                                    break;
                                case 2: // ����
                                    Left = graphic.boundaryRect.Right - 45;
                                    Top = graphic.boundaryRect.Top + 15;
                                    break;
                                case 3: // ���ϱ�
                                    Left = graphic.boundaryRect.Left + 15;
                                    Top = graphic.boundaryRect.Bottom - 45;
                                    break;
                            }
                            Right = Left + 30; // Width is 30
                            Bottom = Top + 30; // Height is 30

                            // Create Local Align.
                            GraphicsRectangle localAlign = new GraphicsRectangle(Left, Top, Right, Bottom, this.LineWidth,
                                GraphicsRegionType.LocalAlign, Colors.Red, Colors.Red, graphic.ActualScale);
                            localAlign.MotherROI = graphic;
                            localAlign.Caption = CaptionHelper.LocalAlignCaption;
                            graphic.LocalAligns[localAlignIndex] = localAlign;
                            newGraphicsList.Add(localAlign);
                            
                            UnselectAll();
                            break;
                        }
                        localAlignIndex++;
                    }
                }
            }

            foreach (GraphicsBase graphic in newGraphicsList)
            {
                graphicsList.Add(graphic);
            }
        }

        /// <summary>   Queries if we can draw 'graphic'. </summary>
        /// <remarks>   Minseok, Hwang, 2011-10-16. </remarks>
        public bool CanDraw(GraphicsBase graphic, int pixelWidth = -1, int pixelHeight = -1)
        {
            // 2012-02-20, Minseok, Hwang Added : ������ ������� �ִ��� �׷����Բ� ������. ���� �߻��� ���� ��ġ �ʿ�.
            
            if (pixelWidth == -1)  pixelWidth = Convert.ToInt32(this.ActualWidth);
            if (pixelHeight == -1) pixelHeight = Convert.ToInt32(this.ActualHeight);

            double fSideMargin = 5.0;
            if (pixelWidth < fSideMargin * 2 || pixelHeight < fSideMargin * 2) // Section�� �ּ� ������.
            {
                return false;
            }

            if (graphic is GraphicsRectangleBase)
            {
                GraphicsRectangleBase rectBaseGraphic = (GraphicsRectangleBase)graphic;
                if ((int)Math.Round(rectBaseGraphic.Right - rectBaseGraphic.Left) >= pixelWidth ||
                    (int)Math.Round(rectBaseGraphic.Bottom - rectBaseGraphic.Top) >= pixelHeight)
                {
                    return false;
                }
                
                if ((int)Math.Round(rectBaseGraphic.Right) >= pixelWidth)       
                {
                    double fMargin = rectBaseGraphic.Right - pixelWidth + fSideMargin;
                    if ((int)Math.Round(rectBaseGraphic.Right) - fMargin >= pixelWidth)
                    {
                        return false; // ��ǥ ���� �Ŀ��� ���� �Ѿ�� ��� false �� ��ȯ.
                    }

                    rectBaseGraphic.Right -= fMargin;
                    if (rectBaseGraphic.Right < 0)
                    {
                        rectBaseGraphic.Right = fSideMargin;
                    }

                    rectBaseGraphic.Left -= fMargin;
                    if (rectBaseGraphic.Left < 0)
                    {
                        rectBaseGraphic.Left = 0;
                    }
                }
                if ((int)Math.Round(rectBaseGraphic.Bottom) >= pixelHeight)
                {
                    double fMargin = rectBaseGraphic.Bottom - pixelHeight + fSideMargin;
                    if ((int)Math.Round(rectBaseGraphic.Bottom) - fMargin >= pixelHeight)
                    {
                        return false; // ��ǥ ���� �Ŀ��� ���� �Ѿ�� ��� false �� ��ȯ.
                    }
                    
                    rectBaseGraphic.Bottom -= fMargin;
                    if (rectBaseGraphic.Bottom < 0)
                    {
                        rectBaseGraphic.Bottom = fSideMargin;
                    }

                    rectBaseGraphic.Top -= fMargin;
                    if (rectBaseGraphic.Top < 0)
                    {
                        rectBaseGraphic.Top = 0;
                    }

                    rectBaseGraphic.CalcBoundaryRect();
                    rectBaseGraphic.RefreshDrawing();
                }
            }
            else if (graphic is GraphicsLine)
            {
                GraphicsLine lineGraphic = (GraphicsLine)graphic;
                double distanceX = Math.Abs(lineGraphic.Start.X - lineGraphic.End.X);
                double distanceY = Math.Abs(lineGraphic.Start.Y - lineGraphic.End.Y);
                double length = Math.Sqrt((distanceX * distanceX) + (distanceY + distanceY));

                if ((int)Math.Round(lineGraphic.Start.X) >= pixelWidth)
                    lineGraphic.Start = new Point(pixelWidth - fSideMargin, lineGraphic.Start.Y);

                if ((int)Math.Round(lineGraphic.Start.Y) >= pixelHeight)
                    lineGraphic.End = new Point(lineGraphic.Start.X, pixelHeight - fSideMargin);

                if ((int)Math.Round(lineGraphic.End.X) >= pixelWidth)
                    lineGraphic.End = new Point(pixelWidth - fSideMargin, lineGraphic.End.Y);

                if ((int)Math.Round(lineGraphic.End.Y) >= pixelHeight)
                    lineGraphic.End = new Point(lineGraphic.End.X, pixelHeight - fSideMargin);
                
                lineGraphic.CalcBoundaryRect();
                lineGraphic.RefreshDrawing();
            }
            else if (graphic is GraphicsPolyLine)
            {
                GraphicsPolyLine polyLineGraphic = (GraphicsPolyLine)graphic;
                int points = polyLineGraphic.Points.Length;
                double farLeft = pixelWidth;
                double farTop = pixelHeight;
                double farRight = 0;
                double farBottom = 0;
                for (int index = 0; index < points; index++)
                {
                    farLeft = (farLeft < polyLineGraphic.Points[index].X) ? farLeft : polyLineGraphic.Points[index].X;
                    farTop = (farTop < polyLineGraphic.Points[index].Y) ? farTop : polyLineGraphic.Points[index].Y;
                    farRight = (farRight > polyLineGraphic.Points[index].X) ? farRight : polyLineGraphic.Points[index].X;
                    farBottom = (farBottom > polyLineGraphic.Points[index].Y) ? farBottom : polyLineGraphic.Points[index].Y;
                }

                if ((int)Math.Round(farRight - farLeft) >= pixelWidth || (int)Math.Round(farBottom - farTop) >= pixelHeight)
                {
                    return false;
                }

                for (int index = 0; index < points; index++)
                {
                    if ((int)Math.Round(polyLineGraphic.Points[index].X) >= pixelWidth)
                    {
                        polyLineGraphic.Points[index].X = pixelWidth - fSideMargin;
                    }

                    if ((int)Math.Round(polyLineGraphic.Points[index].Y) >= pixelHeight)
                    {
                        polyLineGraphic.Points[index].Y = pixelHeight - fSideMargin;
                    }
                }
                polyLineGraphic.CalcBoundaryRect();
                polyLineGraphic.RefreshDrawing();
            }

            return true;
        }
    }
}
