// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Resources;
using System.IO;
using System.Collections.Generic;
using System.Xml.Serialization;
using Common.Drawing.InspectionInformation;

// Modified & Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>   PolyLine graphics object. </summary>
    public class GraphicsPolyLine : GraphicsBase
    {
        #region Class Members
        private bool IsClosed = false;

        /// <summary> This class member contains all required geometry. It is ready for drawing and hit testing. </summary>
        protected PathGeometry pathGeometry;

        /// <summary> Points from pathGeometry, including StartPoint </summary>
        protected Point[] points;

        /// <summary> The handle cursor </summary>
        private static Cursor handleCursor;
        #endregion Class Members

        #region Constructors
        internal void CalcBoundaryRect()
        {
            double fMinX, fMaxX, fMinY, fMaxY;
            fMinX = fMaxX = points[0].X;
            fMinY = fMaxY = points[0].Y;

            for (int i = 1; i < points.Length; i++)
            {
                if (fMinX > points[i].X)
                    fMinX = points[i].X;
                if (fMaxX < points[i].X)
                    fMaxX = points[i].X;
                if (fMinY > points[i].Y)
                    fMinY = points[i].Y;
                if (fMaxY < points[i].Y)
                    fMaxY = points[i].Y;
            }

            boundaryRect.X = fMinX;
            boundaryRect.Y = fMinY;
            boundaryRect.Width = fMaxX - fMinX + 1;
            boundaryRect.Height = fMaxY - fMinY + 1;

            startPoint = boundaryRect.TopLeft;

            LeftProperty = (int)boundaryRect.Left;
            TopProperty = (int)boundaryRect.Top;
            WidthProperty = boundaryRect.Width;
            HeightProperty = boundaryRect.Height;

        }

        public GraphicsPolyLine(Point[] points, double lineWidth, GraphicsRegionType regionType, Color objectColor, Color textColor, double actualScale)
        {
            this.startPoint = new Point(points[0].X, points[0].Y);

            MakeGeometryFromPoints(ref points);
            CalcBoundaryRect();

            this.graphicsLineWidth = lineWidth;
            this.graphicsRegionType = regionType;
            this.graphicsObjectColor = objectColor;
            this.graphicsTextColor = textColor;
            this.graphicsActualScale = actualScale;

            //RefreshDrawng();
        }

        /// <summary>   Initializes a new instance of the GraphicsPolyLine class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-09-25. </remarks>
        /// <param name="points">       The points. </param>
        /// <param name="lineWidth">    Width of the line. </param>
        /// <param name="regionType">   Type of the region. </param>
        /// <param name="objectColor">  The object color. </param>
        /// <param name="textcolor">    The textcolor. </param>
        /// <param name="actualScale">  The actual scale. </param>
        public GraphicsPolyLine(List<Point> pointList, double lineWidth, GraphicsRegionType regionType, Color objectColor, Color textColor, double actualScale)
            : this(pointList, lineWidth, regionType, objectColor, textColor, actualScale, string.Empty, null)
        {

        }

        /// <summary>   Initializes a new instance of the GraphicsPolyLine class. </summary>
        /// <remarks>   Minseok, Hwang, 2011-09-25. </remarks>
        /// <param name="points">       The points. </param>
        /// <param name="lineWidth">    Width of the line. </param>
        /// <param name="regionType">   Type of the region. </param>
        /// <param name="objectColor">  The object color. </param>
        /// <param name="textcolor">    The textcolor. </param>
        /// <param name="actualScale">  The actual scale. </param>
        public GraphicsPolyLine(List<Point> pointList, double lineWidth, GraphicsRegionType regionType, Color objectColor, Color textColor, double actualScale, string caption, List<InspectionItem> inspectionList)
        {
            this.points = new Point[pointList.Count];
            for (int i = 0; i < pointList.Count; i++)
            {
                points[i] = pointList[i];
            }

            CalcBoundaryRect();

            MakeGeometryFromPointsByEndTime(ref points);

            this.graphicsLineWidth = lineWidth;
            this.graphicsRegionType = regionType;
            this.graphicsObjectColor = objectColor;
            this.graphicsTextColor = textColor;
            this.graphicsActualScale = actualScale;
            this.caption = caption;

            if (inspectionList != null)
            {
                foreach (InspectionItem inspectionElement in inspectionList)
                {
                    this.InspectionList.Add(inspectionElement);
                }
            }

            // Refresh Drawing.
            DrawingContext dc = this.RenderOpen();
            Draw(dc);
            dc.Close();
        }

        /// <summary>   Initializes a new instance of the GraphicsPolyLine class. </summary>
        public GraphicsPolyLine()
            : this(new Point[] { new Point(0.0, 0.0), new Point(100.0, 100.0) }, 1.0, GraphicsRegionType.Inspection, Colors.Black, Colors.Black, 1.0)
        {
        }

        /// <summary>   Initializes static members of the GraphicsPolyLine class. </summary>
        static GraphicsPolyLine()
        {
            using (MemoryStream stream = new MemoryStream(Properties.Resources.PolyHandle))
            {
                handleCursor = new Cursor(stream);
            }
        }
        #endregion Constructors

        #region Other Functions
        /// <summary>   Convert geometry to array of points. </summary>
        private void MakePoints()
        {
            points = new Point[pathGeometry.Figures[0].Segments.Count + 1];

            points[0] = pathGeometry.Figures[0].StartPoint;

            
            for (int i = 0; i < pathGeometry.Figures[0].Segments.Count; i++)
            {
                points[i + 1] = ((LineSegment)(pathGeometry.Figures[0].Segments[i])).Point;
            }
            
        }

        /// <summary>   Return array of points. </summary>
        /// <returns>   The points. </returns>
        public Point[] GetPoints()
        {
            return points;
        }

        /// <summary>   Convert array of points to geometry. </summary>
        /// <remarks>   Minseok, Hwang, 2011-09-25. </remarks>
        /// <param name="points">   [in,out] The points. </param>
        private void MakeGeometryFromPoints(ref Point[] points)
        {
            if (points == null)
            {
                // This really sucks, XML file contains Points object,
                // but list of points is empty. Do something to prevent program crush.
                points = new Point[2];
            }

            PathFigure figure = new PathFigure();
            figure.IsClosed = IsClosed;

            if (points.Length >= 1)
            {
                figure.StartPoint = points[0];
            }

            for (int i = 1; i < points.Length; i++)
            {
                LineSegment segment = new LineSegment(points[i], true);
                segment.IsSmoothJoin = true;

                figure.Segments.Add(segment);
            }

            pathGeometry = new PathGeometry();
            pathGeometry.Figures.Add(figure);

            MakePoints(); // keep points array up to date
        }

        /// <summary>   Makes a geometry from points by end time. </summary>
        /// <remarks>   Minseok, Hwang, 2011-09-25. </remarks>
        /// <param name="points">   [in,out] The points. </param>
        private void MakeGeometryFromPointsByEndTime(ref Point[] points)
        {
            if (points.Length < 1)
            {
                return;
            }

            PathFigure figure = new PathFigure();
            figure.IsClosed = true;
            IsClosed = true;

            figure.StartPoint = points[0];
            
            for (int i = 0; i < points.Length; i++)
            {
                LineSegment segment = new LineSegment(points[i], true);
                segment.IsSmoothJoin = true;

                figure.Segments.Add(segment);
            }

            pathGeometry = new PathGeometry();
            pathGeometry.Figures.Add(figure);
        }

        /// <summary>   Add new point (line segment) </summary>
        /// <param name="point">    The point. </param>
        public void AddPoint(Point point)
        {
            LineSegment segment = new LineSegment(point, true);
            segment.IsSmoothJoin = true;

            pathGeometry.Figures[0].Segments.Add(segment);

            MakePoints();   // keep points array up to date
            CalcBoundaryRect();
        }

        #endregion Other Functions

        #region Overrides
        /// <summary>   Draw object. </summary>
        /// <exception cref="ArgumentNullException">    Thrown when one or more required arguments are
        ///                                             null. </exception>
        /// <param name="drawingContext">   Context for the drawing. </param>
        public override void Draw(DrawingContext drawingContext)
        {
            if (drawingContext == null)
            {
                throw new ArgumentNullException("drawingContext");
            }

            MakeGeometryFromPoints(ref points);

            drawingContext.DrawGeometry(
                null,
                new Pen(new SolidColorBrush(ObjectColor), ActualLineWidth),
                pathGeometry);

            drawingContext.DrawText(
                CreateCaptionString(),
                new Point(startPoint.X, startPoint.Y - (15 / graphicsActualScale)));

            base.Draw(drawingContext);
        }

        /// <summary>   Test whether object contains point. </summary>
        /// <param name="point">    The Point to test for containment. </param>
        /// <returns>   true if the object is in this collection, false if not. </returns>
        public override bool Contains(Point point)
        {
            return pathGeometry.FillContains(point) || 
                pathGeometry.StrokeContains(new Pen(Brushes.Black, LineHitTestWidth), point);
        }

        /// <summary>   XML serialization support. </summary>
        /// <returns>   It returns PropertiesGraphicsPolyLine. </returns>
        public override PropertiesGraphicsBase CreateSerializedObject()
        {
            return new PropertiesGraphicsPolyLine(this);
        }

        /// <summary>   Get number of handles. </summary>
        /// <value> The number of handles. </value>
        public override int HandleCount
        {
            get
            {
                return pathGeometry.Figures[0].Segments.Count + 1;
            }
        }

        /// <summary>   Get handle point by 1-based number. </summary>
        /// <param name="handleNumber"> The handle number. </param>
        /// <returns>   The handle. </returns>
        public override Point GetHandle(int handleNumber)
        {
            if (handleNumber < 1)
            {
                handleNumber = 1;
            }

            if (handleNumber > points.Length)
            {
                handleNumber = points.Length;
            }

            return points[handleNumber - 1];
        }

        /// <summary>   Get cursor for the handle. </summary>
        /// <param name="handleNumber"> The handle number. </param>
        /// <returns>   The handle cursor. </returns>
        public override Cursor GetHandleCursor(int handleNumber)
        {
            return handleCursor;
        }

        /// <summary>   Move handle to new point (resizing). handleNumber is 1-based. </summary>
        /// <param name="point">        The point. </param>
        /// <param name="handleNumber"> The handle number. </param>
        public override void MoveHandleTo(Point point, int handleNumber)
        {
            point.X = (point.X < 0) ? 0 : point.X;
            point.Y = (point.Y < 0) ? 0 : point.Y;

            if (handleNumber == 1)
            {
                pathGeometry.Figures[0].StartPoint = point;
            }
            else
            {
                ((LineSegment)(pathGeometry.Figures[0].Segments[handleNumber - 2])).Point = point;
            }
            
            MakePoints();
            CalcBoundaryRect();
            RefreshDrawing();
        }

        /// <summary>   Move object. </summary>
        /// <remarks>   Minseok,Hwang, 2011-08-19. </remarks>
        /// <param name="deltaX">       The delta x coordinate. </param>
        /// <param name="deltaY">       The delta y coordinate. </param>
        /// <param name="maxWidth">     Width of the maximum. </param>
        /// <param name="maxHeight">    Height of the maximum. </param>
        public override void Move(double deltaX, double deltaY, double maxWidth, double maxHeight)
        {
            CalcBoundaryRect();

            if ((boundaryRect.Left + deltaX) < 0)
                deltaX = -boundaryRect.Left;
            if ((boundaryRect.Top + deltaY) < 0)
                deltaY = -boundaryRect.Top;
            if ((boundaryRect.Right + deltaX) >= maxWidth)
                deltaX = (maxWidth - 1) - boundaryRect.Right;
            if ((boundaryRect.Bottom + deltaY) >= maxHeight)
                deltaY = (maxHeight - 1) - boundaryRect.Bottom;

            for (int i = 0; i < points.Length; i++)
            {
                points[i].X += deltaX;
                points[i].Y += deltaY;
            }

            boundaryRect.X += deltaX;
            boundaryRect.Y += deltaY;
            
            MakeGeometryFromPoints(ref points);

            RefreshDrawing();
        }

        /// <summary>
        /// Hit test. Return value: -1 - no hit
        ///                          0 - hit anywhere
        ///                        > 1 - handle number.
        /// </summary>
        /// <param name="point">    The point. </param>
        /// <returns>   . </returns>
        public override int MakeHitTest(Point point)
        {
            if (IsSelected)
            {
                for (int i = 1; i <= HandleCount; i++)
                {
                    if (GetHandleRectangle(i).Contains(point))
                    {
                        return i;
                    }
                }
            }

            if (Contains(point))
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }

        /// <summary>   Test whether object intersects with rectangle. </summary>
        /// <param name="rectangle">    The rectangle. </param>
        /// <returns>   true if it succeeds, false if it fails. </returns>
        public override bool IntersectsWith(Rect rectangle)
        {
            RectangleGeometry rg = new RectangleGeometry(rectangle);

            PathGeometry p = Geometry.Combine(rg, pathGeometry, GeometryCombineMode.Intersect, null);

            return (!p.IsEmpty());
        }
        #endregion Overrides

        #region Binding Properties
        private int left;
        private int top;
        private double width;
        private double height;

        /// <summary>   Gets or sets the left. </summary>
        /// <value> The left. </value>
        [XmlIgnore]
        public int LeftProperty
        {
            get
            {
                return left;
            }
            set
            {
                left = value;
                Notify("LeftProperty");
            }
        }

        /// <summary>   Gets or sets the top. </summary>
        /// <value> The top. </value>
        [XmlIgnore]
        public int TopProperty
        {
            get
            {
                return top;
            }
            set
            {
                top = value;
                Notify("TopProperty");
            }
        }

        /// <summary>   Gets or sets the width property. </summary>
        /// <value> The width property. </value>
        [XmlIgnore]
        public double WidthProperty
        {
            get
            {
                return width;
            }
            set
            {
                width = value;
                Notify("WidthProperty");
            }
        }

        /// <summary>   Gets or sets the height property. </summary>
        /// <value> The height property. </value>
        [XmlIgnore]
        public double HeightProperty
        {
            get
            {
                return height;
            }
            set
            {
                height = value;
                Notify("HeightProperty");
            }
        }

        /// <summary>   Gets or sets the points. </summary>
        /// <value> The points. </value>
        [XmlIgnore]
        public Point[] Points
        {
            get
            {
                return points;
            }
            set
            {
                points = value;
            }
        }
        #endregion
    }
}
