// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Collections.Generic;
using Common.Drawing.InspectionInformation;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>
    ///  Rectangle graphics object.
    /// </summary>
    public class GraphicsEllipse : GraphicsRectangleBase
    {
        #region Constructors

        public GraphicsEllipse(double left, double top, double right, double bottom,
            double lineWidth, GraphicsRegionType regionType, Color objectColor, Color textColor, double actualScale)
            : this(left, top, right, bottom, lineWidth, regionType, objectColor, textColor, actualScale, string.Empty, null)
        {

        }

        public GraphicsEllipse(double left, double top, double right, double bottom,
            double lineWidth, GraphicsRegionType regionType, Color objectColor, Color textColor, double actualScale, string caption, List<InspectionItem> inspectionList)
        {
            this.startPoint = new Point(left, top);
            this.rectangleLeft = left;
            this.rectangleTop = top;
            this.rectangleRight = right;
            this.rectangleBottom = bottom;
            this.graphicsLineWidth = lineWidth;
            this.graphicsRegionType = regionType;
            this.graphicsObjectColor = objectColor;
            this.graphicsTextColor = textColor;
            this.graphicsActualScale = actualScale;
            this.caption = caption;

            this.LeftProperty = (int)left;
            this.TopProperty = (int)top;
            this.WidthProperty = Math.Abs(rectangleRight - rectangleLeft);
            this.HeightProperty = Math.Abs(rectangleBottom - rectangleTop);

            if (inspectionList != null)
            {
                foreach (InspectionItem inspectionElement in inspectionList)
                {
                    this.InspectionList.Add(inspectionElement);
                }
            }

            //RefreshDrawng();
        }

        public GraphicsEllipse()
            :
            this(0.0, 0.0, 100.0, 100.0, 1.0, GraphicsRegionType.Inspection, Colors.Black, Colors.Black, 1.0)
        {
        }

        #endregion Constructors

        #region Overrides

        /// <summary>
        /// Draw object
        /// </summary>
        public override void Draw(DrawingContext drawingContext)
        {
            if (drawingContext == null)
            {
                throw new ArgumentNullException("drawingContext");
            }

            Rect r = Rectangle;

            Point center = new Point(
                (r.Left + r.Right) / 2.0,
                (r.Top + r.Bottom) / 2.0);

            double radiusX = (r.Right - r.Left) / 2.0;
            double radiusY = (r.Bottom - r.Top) / 2.0;

            drawingContext.DrawEllipse(
                null,
                new Pen(new SolidColorBrush(ObjectColor), ActualLineWidth),
                center,
                radiusX,
                radiusY);

            drawingContext.DrawText(
                CreateCaptionString(),
                new Point(startPoint.X, startPoint.Y - (15 / graphicsActualScale)));

            base.Draw(drawingContext);
        }

        /// <summary>
        /// Test whether object contains point
        /// </summary>
        public override bool Contains(Point point)
        {
            if (IsSelected)
            {
                return this.Rectangle.Contains(point);
            }
            else
            {
                EllipseGeometry g = new EllipseGeometry(Rectangle);

                return g.FillContains(point) || g.StrokeContains(new Pen(Brushes.Black, ActualLineWidth), point);
            }
        }

        // RadiusX - 0, RadiusY = 0�� ��� ���� �������� ����.
        /// <summary>
        /// Test whether object intersects with rectangle
        /// </summary>
        //public override bool IntersectsWith(Rect rectangle)
        //{
        //    RectangleGeometry rg = new RectangleGeometry(rectangle);    // parameter
        //    EllipseGeometry eg = new EllipseGeometry(Rectangle);        // this object rectangle

        //    PathGeometry p = Geometry.Combine(rg, eg, GeometryCombineMode.Intersect, null);

        //    return (!p.IsEmpty());
        //}


        /// <summary>
        /// Serialization support
        /// </summary>
        public override PropertiesGraphicsBase CreateSerializedObject()
        {
            return new PropertiesGraphicsEllipse(this);
        }

        #endregion Overrides
    }
}
