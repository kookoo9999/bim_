// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Diagnostics;
using System.Globalization;
using System.ComponentModel;
using System.Xml.Serialization;
using System.Collections.Generic;
using Common.Drawing.InspectionInformation;
using System.Collections.ObjectModel;

// Modified & Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>
    /// Base class for all graphics objects.
    /// </summary>
    public abstract class GraphicsBase : DrawingVisual, INotifyPropertyChanged
    {
        /// <summary> List of inspection settings </summary>
        private ObservableCollection<InspectionItem> inspectionList = new ObservableCollection<InspectionItem>(); // ROI�� ���� �˻� ���� ��. InspectionType ���� ����.

        /// <summary>   Gets or sets a list of inspections. </summary>
        /// <value> A List of inspections. </value>
        public ObservableCollection<InspectionItem> InspectionList
        {
            get
            {
                return inspectionList;
            }
            set
            {
                inspectionList = value;
            }
        }

        #region Class Members

        /// <summary> The start point </summary>
        public Point startPoint;

        /// <summary> The boundary rectangle </summary>
        public Rect boundaryRect;

        /// <summary> The caption </summary>
        protected string caption = string.Empty;
        
        /// <summary> Width of the graphics line </summary>
        protected double graphicsLineWidth;

        /// <summary> Type of the graphics region </summary>
        protected GraphicsRegionType graphicsRegionType;

        /// <summary> The graphics object color </summary>
        protected Color graphicsObjectColor;

        /// <summary> The graphics text color </summary>
        protected Color graphicsTextColor;

        /// <summary> The graphics actual scale </summary>
        protected double graphicsActualScale;

        /// <summary> true to selected </summary>
        protected bool selected;

        /// <summary> Allows to write Undo - Redo functions and don't care about objects order in the list. </summary>
        private int objectId;

        /// <summary> Width of the hit test </summary>
        protected const double HitTestWidth = 8.0;

        /// <summary> Size of the handle </summary>
        protected const double HandleSize = 12.0;

        /// <summary> Size of the font </summary>
        protected const double FontSize = 12.0;

        // Objects used to draw handles. I want to keep them all time program runs,
        // therefore I don't use pens, because actual pen size can change.

        /// <summary> The external rectangle brush </summary>
        static SolidColorBrush handleBrush1 = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0)); // black

        /// <summary> The middle handle brush </summary>
        static SolidColorBrush handleBrush2 = new SolidColorBrush(Color.FromArgb(255, 255, 255, 255)); // white

        /// <summary> The internal handle brush </summary>
        static SolidColorBrush handleBrush3 = new SolidColorBrush(Color.FromArgb(255, 0, 0, 255)); // blue

        #endregion Class Members

        #region Constructor

        /// <summary>   Initializes a new instance of the GraphicsBase class. </summary>
        //protected GraphicsBase(GraphicsBaseRegionType regionType)
        protected GraphicsBase()
        {
            this.objectId = this.GetHashCode();
        }


        #endregion Constructor

        #region Properties

        /// <summary>   Gets or sets the type of the region. </summary>
        /// <value> The type of the region. </value>
        public GraphicsRegionType RegionType
        {
            get
            {
                return graphicsRegionType;
            }
            set
            {
                graphicsRegionType = value;
                Notify("RegionType");
            }
        }

        /// <summary>   Gets or sets a value indicating whether this object is selected. </summary>
        /// <value> true if this object is selected, false if not. </value>
        public bool IsSelected
        {
            get
            {
                return selected;
            }
            set
            {
                selected = value;

                RefreshDrawing();
            }
        }

        /// <summary>   Gets or sets the width of the line. </summary>
        /// <value> The width of the line. </value>
        public double LineWidth
        {
            get
            {
                return graphicsLineWidth;
            }
            set
            {
                graphicsLineWidth = value;

                RefreshDrawing();
            }
        }

        /// <summary>   Gets or sets the color of the object. </summary>
        /// <value> The color of the object. </value>
        public Color ObjectColor
        {
            get
            {
                return graphicsObjectColor;
            }
            set
            {
                graphicsObjectColor = value;

                RefreshDrawing();
            }
        }

        /// <summary>   Gets or sets the color of the text. </summary>
        /// <value> The color of the text. </value>
        public Color TextColor
        {
            get
            {
                return graphicsTextColor;
            }

            set
            {
                graphicsTextColor = value;

                RefreshDrawing();
            }
        }

        /// <summary>   Gets or sets the actual scale. </summary>
        /// <value> The actual scale. </value>
        public double ActualScale
        {
            get
            {
                return graphicsActualScale;
            }

            set
            {
                graphicsActualScale = value;

                RefreshDrawing();
            }
        }

        /// <summary>   Gets the width of the actual line. </summary>
        /// <value> The width of the actual line. </value>
        protected double ActualLineWidth
        {
            get
            {
                return graphicsActualScale <= 0 ? graphicsLineWidth : graphicsLineWidth / graphicsActualScale;
            }
        }

        /// <summary>   Gets the width of the line hit test. </summary>
        /// <value> The width of the line hit test. </value>
        protected double LineHitTestWidth
        {
            get
            {
                // Ensure that hit test area is not too narrow
                return Math.Max(8.0, ActualLineWidth);
            }
        }

        /// <summary>   Start Point. </summary>
        /// <value> The start point. </value>
        public Point StartPoint
        {
            get { return startPoint; }
        }

        /// <summary>   Caption string. </summary>
        /// <value> The caption. </value>
        public string Caption
        {
            get { return caption; }
            set 
            { 
                caption = value;

                this.RefreshDrawing();
            }
        }

        /// <summary>   Object ID. </summary>
        /// <value> The identifier. </value>
        public int Id
        {
            get { return objectId; }
            set { objectId = value; }
        }

        /// <summary> The local aligns </summary>
        public GraphicsRectangle[] LocalAligns;

        #endregion Properties

        #region Abstract Methods and Properties

        /// <summary>
        /// Returns number of handles
        /// </summary>
        public abstract int HandleCount
        {
            get;
        }


        /// <summary>
        /// Hit test, should be overwritten in derived classes.
        /// </summary>
        public abstract bool Contains(Point point);

        /// <summary>
        /// Create object for serialization
        /// </summary>
        public abstract PropertiesGraphicsBase CreateSerializedObject();

        /// <summary>
        /// Get handle point by 1-based number
        /// </summary>
        public abstract Point GetHandle(int handleNumber);

        /// <summary>
        /// Hit test.
        /// Return value: -1 - no hit
        ///                0 - hit anywhere
        ///                > 1 - handle number
        /// </summary>
        public abstract int MakeHitTest(Point point);

        /// <summary>
        /// Test whether object intersects with rectangle
        /// </summary>
        public abstract bool IntersectsWith(Rect rectangle);

        /// <summary>   Move object. </summary>
        /// <remarks>   Minseok,Hwang, 2011-08-19. </remarks>
        /// <param name="deltaX">       The delta x coordinate. </param>
        /// <param name="deltaY">       The delta y coordinate. </param>
        /// <param name="maxWidth">     Width of the maximum. </param>
        /// <param name="maxHeight">    Height of the maximum. </param>
        public abstract void Move(double deltaX, double deltaY, double maxWidth, double maxHeight);

        /// <summary>
        /// Move handle to the point
        /// </summary>
        public abstract void MoveHandleTo(Point point, int handleNumber);

        /// <summary>
        /// Get cursor for the handle
        /// </summary>
        public abstract Cursor GetHandleCursor(int handleNumber);

        #endregion Abstract Methods and Properties

        #region Virtual Methods

        /// <summary>
        /// Normalize object.
        /// Call this function in the end of object resizing,
        /// </summary>
        public virtual void Normalize()
        {
            // Empty implementation is OK for classes which don't require
            // normalization, like line.
            // Normalization is required for rectangle-based classes.
        }

        /// <summary>
        /// Implements actual drawing code.
        /// 
        /// Call GraphicsBase.Draw in the end of every derived class Draw 
        /// function to draw tracker if necessary.
        /// </summary>
        public virtual void Draw(DrawingContext drawingContext)
        {
            if (IsSelected)
            {
                DrawTracker(drawingContext);
            }
        }

        /// <summary>
        /// Draw tracker for selected object.
        /// </summary>
        public virtual void DrawTracker(DrawingContext drawingContext)
        {
            for (int i = 1; i <= HandleCount; i++)
            {
                DrawTrackerRectangle(drawingContext, GetHandleRectangle(i));
            }
        }

        /// <summary>
        /// Dump (for debugging)
        /// </summary>
        [Conditional("DEBUG")]
        public virtual void Dump()
        {
            Trace.WriteLine(this.GetType().Name);

            Trace.WriteLine("ID = " + objectId.ToString(CultureInfo.InvariantCulture) +
                "   Selected = " + selected.ToString(CultureInfo.InvariantCulture));

            Trace.WriteLine("objectColor = " + ColorToDisplay(graphicsObjectColor) +
                "  lineWidth = " + DoubleForDisplay(graphicsLineWidth));
        }

        #endregion Virtual Methods

        #region Other Methods

        /// <summary>
        /// Create Default Cation String.
        /// </summary>
        /// <returns></returns>
        public FormattedText CreateCaptionString()
        {
            Typeface typeFace = new Typeface(
                new FontFamily("Arial"),
                FontStyles.Normal,
                FontWeights.Bold,
                FontStretches.Normal
                );

            if (graphicsActualScale == 0) graphicsActualScale = 1;
            FormattedText formattedText = new FormattedText(
                caption,
                System.Globalization.CultureInfo.InvariantCulture,
                FlowDirection.LeftToRight,
                typeFace,
                FontSize / graphicsActualScale,
                new SolidColorBrush(TextColor));

            return formattedText;
        }

        /// <summary>
        /// Draw tracker rectangle
        /// </summary>
        static void DrawTrackerRectangle(DrawingContext drawingContext, Rect rectangle)
        {
            // External rectangle
            drawingContext.DrawRectangle(handleBrush1, null, rectangle);

            // Middle
            drawingContext.DrawRectangle(handleBrush2, null,
                new Rect(rectangle.Left + rectangle.Width / 8,
                         rectangle.Top + rectangle.Height / 8,
                         rectangle.Width * 3 / 4,
                         rectangle.Height * 3 / 4));

            // Internal
            drawingContext.DrawRectangle(handleBrush3, null,
                new Rect(rectangle.Left + rectangle.Width / 4,
                 rectangle.Top + rectangle.Height / 4,
                 rectangle.Width / 2,
                 rectangle.Height / 2));
        }


        /// <summary>
        /// Refresh drawing.
        /// Called after change if any object property.
        /// </summary>
        public void RefreshDrawing()
        {
            DrawingContext dc = this.RenderOpen();

            Draw(dc);

            dc.Close();
        }

        /// <summary>
        /// Get handle rectangle by 1-based number
        /// </summary>
        public Rect GetHandleRectangle(int handleNumber)
        {
            Point point = GetHandle(handleNumber);

            // Handle rectangle should have constant size, except of the case
            // when line is too width.
            double size = Math.Max(HandleSize / graphicsActualScale, ActualLineWidth * 1.1);

            return new Rect(point.X - size / 2, point.Y - size / 2, size, size);
        }

        /// <summary>
        /// Helper function used for Dump
        /// </summary>
        static string DoubleForDisplay(double value)
        {
            return ((float)value).ToString("f2", CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// Helper function used for Dump
        /// </summary>
        static string ColorToDisplay(Color value)
        {
            //return "A:" + value.A.ToString() +
            return "R:" + value.R.ToString(CultureInfo.InvariantCulture) +
                   " G:" + value.G.ToString(CultureInfo.InvariantCulture) +
                   " B:" + value.B.ToString(CultureInfo.InvariantCulture);
        }

        #endregion Other Methods

        #region implements INotifyPropertyChanged
        /**
         * @var PropertyChanged
         * @brief property changed event.
         * @see INotifyPropertyChanged
        */
        public event PropertyChangedEventHandler PropertyChanged;

        /**
         * @fn Notify(string strPropertyName)
         * @param [in] strPropertyName - changed property name.
         * @brief notify method.
         * @see INotifyPropertyChanged
         */
        protected void Notify(string strPropertyName)
        {
            PropertyChangedEventHandler p = PropertyChanged;
            if (p != null)
            {
                p(this, new PropertyChangedEventArgs(strPropertyName));
            }
        }
        #endregion
    }
}
