// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Common.Drawing.InspectionInformation;
using System.Collections.Generic;
using System.Xml.Serialization;

// Modified & Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>
    ///  Rectangle graphics object.
    /// </summary>
    public class GraphicsRectangle : GraphicsRectangleBase
    {
        #region Private member variables.
        protected IterationSymmetryInformation graphicsSymmetryValue;

        /// <summary> The graphics iteration value </summary>
        protected IterationInformation graphicsIterationValue;

        /// <summary> The graphics block iteration value </summary>
        protected IterationInformation graphicsBlockIterationValue;

        /// <summary> The graphics iteration x coordinate </summary>
        protected int graphicsIterationXPosition;

        /// <summary> The graphics iteration y coordinate </summary>
        protected int graphicsIterationYPosition;

        /// <summary> true if is fiducial region </summary>
        protected bool isFiducialRegion = false;

        /// <summary> The mother roi </summary>
        protected GraphicsBase motherROI = null;

        /// <summary> true if can move </summary>
        public bool IsCanMove = true;

        /// <summary> true if is valid section roi </summary>
        public bool IsValidSectionROI = false;
        #endregion

        #region Constructors
        // Default constructor.
        public GraphicsRectangle() 
            : this(0.0, 0.0, 100.0, 100.0, 1.0, GraphicsRegionType.Inspection, Colors.Black, Colors.Black, 1.0, new IterationSymmetryInformation(1, 1, 1, 1), new IterationInformation(1, 1, 0, 0), new IterationInformation(1, 1, 0, 0), false, null, string.Empty, null, 0, 0)
        {
        }

        // It called by DrawingCanvas
        public GraphicsRectangle(double left, double top, double right, double bottom, double lineWidth, GraphicsRegionType regionType, Color objectColor, Color textColor, double actualScale)
            : this(left, top, right, bottom, lineWidth, regionType, objectColor, textColor, actualScale, new IterationSymmetryInformation(1, 1, 1, 1), new IterationInformation(1, 1, 0, 0), new IterationInformation(1, 1, 0, 0), false, null, string.Empty, null, 0, 0)
        {

        }

        // It called by SectionManager
        public GraphicsRectangle(double left, double top, double right, double bottom, double lineWidth, GraphicsRegionType regionType, Color objectColor, Color textColor, double actualScale, IterationSymmetryInformation symmetryValue, IterationInformation iterationValue, IterationInformation blockIterationValue, bool isFiducialRegion, GraphicsBase motherROI)
            : this(left, top, right, bottom, lineWidth, regionType, objectColor, textColor, actualScale, symmetryValue, iterationValue, blockIterationValue, isFiducialRegion, motherROI, string.Empty, null, 0, 0)
        {

        }

        // It called by PropertiesGraphicRectangle
        public GraphicsRectangle(double left, double top, double right, double bottom,
                                 double lineWidth, 
                                 GraphicsRegionType regionType, 
                                 Color objectColor, Color textColor, 
                                 double actualScale,
                                 IterationSymmetryInformation symmetryValue,
                                 IterationInformation iterationValue, 
                                 IterationInformation blockIterationValue, 
                                 bool isFiducialRegion, 
                                 GraphicsBase motherROI,
                                 string caption, List<InspectionItem> inspectionList, 
                                 int iterationXPosition, int iterationYPosition)
        {
            this.startPoint = new Point(left, top);

            this.rectangleLeft = left;
            this.rectangleTop = top;
            this.rectangleRight = right;
            this.rectangleBottom = bottom;

            this.LeftProperty = (int)left;
            this.TopProperty = (int)top;
            this.WidthProperty = Math.Abs(rectangleRight - rectangleLeft);
            this.HeightProperty = Math.Abs(rectangleBottom - rectangleTop);

            this.graphicsLineWidth = lineWidth;
            this.graphicsRegionType = regionType;
            
            this.graphicsObjectColor = objectColor;
            this.graphicsTextColor = textColor;

            this.graphicsActualScale = actualScale;

            this.graphicsSymmetryValue = symmetryValue;
            this.graphicsIterationValue = iterationValue;
            this.graphicsIterationXPosition = iterationXPosition;
            this.graphicsIterationYPosition = iterationYPosition;

            this.graphicsBlockIterationValue = blockIterationValue;

            this.isFiducialRegion = isFiducialRegion;
            this.motherROI = motherROI;

            this.caption = caption;

            switch (regionType)
            {
                case GraphicsRegionType.StripAlign:
                    this.caption = CaptionHelper.StripAlignCaption;
                    break;
                case GraphicsRegionType.UnitAlign:
                    this.caption = CaptionHelper.UnitAlignCaption;
                    break;
                case GraphicsRegionType.UnitRegion:
                    this.caption = CaptionHelper.FiducialUnitRegionCaption;
                    break;
                case GraphicsRegionType.OuterRegion:
                    this.caption = CaptionHelper.FiducialOuterRegionCaption;
                    break;
                case GraphicsRegionType.Except:
                    this.caption = CaptionHelper.ExceptionalMaskCaption;
                    break;
            }

            if (inspectionList != null)
            {
                int nSequenceID = 1;
                foreach (InspectionItem inspectionElement in inspectionList)
                {
                    inspectionElement.ID = nSequenceID++;
                    this.InspectionList.Add(inspectionElement);
                }
            }

            //RefreshDrawng();
        }
        #endregion Constructors

        #region Overrides
        /// <summary>
        /// Draw object
        /// </summary>
        public override void Draw(DrawingContext drawingContext)
        {
            if (drawingContext == null)
            {
                throw new ArgumentNullException("drawingContext");
            }

            drawingContext.DrawRectangle(
                null,
                new Pen(new SolidColorBrush(ObjectColor), ActualLineWidth),
                Rectangle);

            drawingContext.DrawText(
                CreateCaptionString(),
                new Point(startPoint.X, startPoint.Y - (15 / graphicsActualScale)));

            base.Draw(drawingContext);
        }

        /// <summary>
        /// Test whether object contains point
        /// </summary>
        public override bool Contains(Point point)
        {
            return this.Rectangle.Contains(point);
        }

        public override void Move(double deltaX, double deltaY, double maxWidth, double maxHeight)
        {
            //if (!IsCanMove) return;
            //else if(IsFiducialRegion)
            //{
                
            //}

            base.Move(deltaX, deltaY, maxWidth, maxHeight);
        }

        public override void MoveHandleTo(Point point, int handleNumber)
        {
            //if (!IsCanMove) return;
            //else if (IsFiducialRegion)
            //{

            //}

            base.MoveHandleTo(point, handleNumber);
        }

        /// <summary>
        /// Serialization support
        /// </summary>
        public override PropertiesGraphicsBase CreateSerializedObject()
        {
            return new PropertiesGraphicsRectangle(this);
        }

        #endregion Overrides

        #region Properties.
        public IterationSymmetryInformation SymmetryValue
        {
            get
            {
                return graphicsSymmetryValue;
            }
            set
            {
                graphicsSymmetryValue = value;
            }
        }

        /// <summary>   Gets or sets the iteration value. </summary>
        /// <value> The iteration value. </value>
        public IterationInformation IterationValue
        {
            get
            {
                return graphicsIterationValue;
            }
            set
            {
                graphicsIterationValue = value;
            }
        }

        /// <summary>   Gets or sets the iteration x coordinate position. </summary>
        /// <value> The iteration x coordinate position. </value>
        public int IterationXPosition
        {
            get
            {
                return graphicsIterationXPosition;
            }
            set
            {
                graphicsIterationXPosition = value;
            }
        }

        /// <summary>   Gets or sets the iteration y coordinate position. </summary>
        /// <value> The iteration y coordinate position. </value>
        public int IterationYPosition
        {
            get
            {
                return graphicsIterationYPosition;
            }
            set
            {
                graphicsIterationYPosition = value;
            }
        }

        /// <summary>   Gets or sets the block iteration value. </summary>
        /// <value> The block iteration value. </value>
        public IterationInformation BlockIterationValue
        {
            get
            {
                return graphicsBlockIterationValue;
            }
            set
            {
                graphicsBlockIterationValue = value;
            }
        }

        /// <summary>   Gets or sets a value indicating whether this object is fiducial region. </summary>
        /// <value> true if this object is fiducial region, false if not. </value>
        public bool IsFiducialRegion
        {
            get
            {
                return isFiducialRegion;
            }
            set
            {
                isFiducialRegion = value;
            }
        }

        /// <summary>   Gets or sets the mother roi. </summary>
        /// <value> The mother roi. </value>
        public GraphicsBase MotherROI
        {
            get
            {
                return motherROI;
            }
            set
            {
                motherROI = value;
            }
        }
        #endregion
    }
}
