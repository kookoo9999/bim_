// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.IO;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>   Line tool. </summary>
    class ToolLine : ToolObject
    {
        /// <summary>   Initializes a new instance of the ToolLine class. </summary>
        public ToolLine()
        {
            using (MemoryStream stream = new MemoryStream(Properties.Resources.Line))
            {
                ToolCursor = new Cursor(stream);
            }
        }

        /// <summary>   Create new object. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        /// <param name="e">                Event information to send to registered event handlers. </param>
        public override void OnMouseDown(DrawingCanvas drawingCanvas, MouseButtonEventArgs e)
        {
            Point p = e.GetPosition(drawingCanvas);
            if (p.X >= drawingCanvas.ActualWidth - 1 || p.Y >= drawingCanvas.ActualHeight - 1)
            {
                return;
            }

            SetGraphicsColor(drawingCanvas);

            AddNewObject(drawingCanvas,
                new GraphicsLine(
                p,
                new Point(p.X + 1, p.Y + 1),
                drawingCanvas.LineWidth,
                drawingCanvas.RegionType,
                drawingCanvas.ObjectColor,
                drawingCanvas.TextColor,
                drawingCanvas.ActualScale));
        }

        /// <summary>   Set cursor and resize new object. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        /// <param name="e">                Event information to send to registered event handlers. </param>
        public override void OnMouseMove(DrawingCanvas drawingCanvas, MouseEventArgs e)
        {
            drawingCanvas.Cursor = ToolCursor;

            if (e.LeftButton == MouseButtonState.Pressed)
            {
                Point p = e.GetPosition(drawingCanvas);
                p.X = (p.X > drawingCanvas.ActualWidth) ? drawingCanvas.ActualWidth : p.X;
                p.Y = (p.Y > drawingCanvas.ActualHeight) ? drawingCanvas.ActualHeight : p.Y;

                GraphicsLine currentLine = drawingCanvas[drawingCanvas.Count - 1] as GraphicsLine;
                if (currentLine != null)
                {
                    if (!(currentLine.StartPoint.X == p.X && currentLine.StartPoint.Y == p.Y))
                    {
                        drawingCanvas[drawingCanvas.Count - 1].MoveHandleTo(p, 2);
                    }
                }
                
            }
        }
    }
}
