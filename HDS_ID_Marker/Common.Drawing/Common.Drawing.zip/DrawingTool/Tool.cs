// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

// Modified & Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>   Base class for all drawing tools.  </summary>
    abstract class Tool
    {
        /// <summary>   Executes the mouse down action. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        /// <param name="e">                Event information to send to registered event handlers. </param>
        public abstract void OnMouseDown(DrawingCanvas drawingCanvas, MouseButtonEventArgs e);

        /// <summary>   Executes the mouse move action. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        /// <param name="e">                Event information to send to registered event handlers. </param>
        public abstract void OnMouseMove(DrawingCanvas drawingCanvas, MouseEventArgs e);

        /// <summary>   Executes the mouse up action. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        /// <param name="e">                Event information to send to registered event handlers. </param>
        public abstract void OnMouseUp(DrawingCanvas drawingCanvas, MouseButtonEventArgs e);

        /// <summary>   Sets a cursor. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public abstract void SetCursor(DrawingCanvas drawingCanvas);

        /// <summary>   Sets the graphics color. </summary>
        /// <remarks>   Minseok,Hwang, 2011-08-17. </remarks>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        protected void SetGraphicsColor(DrawingCanvas drawingCanvas)
        {
            switch (drawingCanvas.RegionType)
            {
                case GraphicsRegionType.Inspection:
                case GraphicsRegionType.UnitRegion:
                case GraphicsRegionType.OuterRegion:
                    drawingCanvas.ObjectColor = GraphicsColors.Green;
                    drawingCanvas.TextColor = GraphicsColors.Green;
                    break;
                case GraphicsRegionType.StripAlign:
                case GraphicsRegionType.UnitAlign:
                case GraphicsRegionType.LocalAlign:
                    drawingCanvas.ObjectColor = GraphicsColors.Red;
                    drawingCanvas.TextColor = GraphicsColors.Red;
                    break;
                case GraphicsRegionType.Except:
                    drawingCanvas.ObjectColor = GraphicsColors.Blue;
                    drawingCanvas.TextColor = GraphicsColors.Blue;
                    break;
                default:
                    drawingCanvas.ObjectColor = Colors.Transparent;
                    drawingCanvas.TextColor = Colors.Transparent;
                    break;
            }
        }
    }
}
