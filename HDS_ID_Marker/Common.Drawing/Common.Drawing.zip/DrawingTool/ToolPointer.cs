// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>   Pointer tool. </summary>
    class ToolPointer : Tool
    {
        /// <summary>   Values that represent SelectionMode.  </summary>
        private enum SelectionMode
        {
            None = 0,
            Move = 1,           // object(s) are moved
            Size = 2,           // object is resized
            GroupSelection = 3
        }

        /// <summary> The select mode </summary>
        private SelectionMode selectMode = SelectionMode.None;

        /// <summary> Object which is currently resized </summary>
        private GraphicsBase resizedObject;

        /// <summary> Handle of the resized object </summary>
        private int resizedObjectHandle;

        /// <summary> Keep state about last and current point (used to move and resize objects) </summary>
        private Point lastPoint = new Point(0, 0);

        /// <summary> State of the command change </summary>
        private CommandChangeState commandChangeState;

        /// <summary> true to was move </summary>
        private bool wasMove;

        /// <summary>   Empty constructor. </summary>
        public ToolPointer()
        {
        }

        /// <summary>   Handle mouse down. Start moving, resizing or group selection. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        /// <param name="e">                Event information to send to registered event handlers. </param>
        public override void OnMouseDown(DrawingCanvas drawingCanvas, MouseButtonEventArgs e)
        {
            selectMode = SelectionMode.None;

            Point point = e.GetPosition(drawingCanvas);
            GraphicsBase movedObject = null;
            commandChangeState = null;
            wasMove = false;
            int handleNumber;

            // Test for resizing (only if control is selected, cursor is on the handle)
            for (int i = drawingCanvas.GraphicsList.Count - 1; i >= 0; i--)
            {
                if (drawingCanvas[i].IsSelected)
                {
                    handleNumber = drawingCanvas[i].MakeHitTest(point);

                    if (handleNumber > 0)
                    {
                        selectMode = SelectionMode.Size;

                        // keep resized object in class member
                        resizedObject = drawingCanvas[i];
                        resizedObjectHandle = handleNumber;

                        // Since we want to resize only one object, unselect all other objects
                        HelperFunctions.UnselectAll(drawingCanvas);
                        drawingCanvas[i].IsSelected = true;

                        commandChangeState = new CommandChangeState(drawingCanvas);

                        break;
                    }
                }
            }

            // Test for move (cursor is on the object)
            if (selectMode == SelectionMode.None)
            {
                for (int i = drawingCanvas.GraphicsList.Count - 1; i >= 0; i--)
                {
                    if (drawingCanvas[i].MakeHitTest(point) == 0)
                    {
                        movedObject = drawingCanvas[i];
                        break;
                    }
                }

                if (movedObject != null)
                {
                    selectMode = SelectionMode.Move;

                    // Unselect all if Ctrl is not pressed and clicked object is not selected yet
                    if (Keyboard.Modifiers != ModifierKeys.Control && !movedObject.IsSelected)
                    {
                        HelperFunctions.UnselectAll(drawingCanvas);
                    }

                    // Select clicked object
                    movedObject.IsSelected = true;

                    // Set move cursor
                    drawingCanvas.Cursor = Cursors.SizeAll;

                    commandChangeState = new CommandChangeState(drawingCanvas);
                }
            }

            // Click on background
            if (selectMode == SelectionMode.None)
            {
                // Unselect all if Ctrl is not pressed
                if (Keyboard.Modifiers != ModifierKeys.Control)
                {
                    HelperFunctions.UnselectAll(drawingCanvas);
                }

                // Group selection. Create selection rectangle.
                GraphicsSelectionRectangle r = new GraphicsSelectionRectangle(
                    point.X, point.Y,
                    point.X + 1, point.Y + 1,
                    drawingCanvas.ActualScale);

                r.Clip = new RectangleGeometry(new Rect(0, 0, drawingCanvas.ActualWidth, drawingCanvas.ActualHeight));

                drawingCanvas.GraphicsList.Add(r);

                selectMode = SelectionMode.GroupSelection;
            }

            lastPoint = point;

            // Capture mouse until MouseUp event is received
            drawingCanvas.CaptureMouse();
        }

        /// <summary>   Handle mouse move. Se cursor, move/resize, make group selection. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        /// <param name="e">                Event information to send to registered event handlers. </param>
        public override void OnMouseMove(DrawingCanvas drawingCanvas, MouseEventArgs e)
        {
            // Exclude all cases except left button on/off.
            if (e.MiddleButton == MouseButtonState.Pressed || e.RightButton == MouseButtonState.Pressed)
            {
                drawingCanvas.Cursor = HelperFunctions.DefaultCursor;
                return;
            }

            Point point = e.GetPosition(drawingCanvas);

            // Set cursor when left button is not pressed
            if (e.LeftButton == MouseButtonState.Released)
            {
                Cursor cursor = HelperFunctions.DefaultCursor;
                int handleNumber = 0;

                foreach(GraphicsBase graphic in drawingCanvas.GraphicsList)
                {
                    handleNumber = graphic.MakeHitTest(point);
                    if (handleNumber > 0)
                    {
                        cursor = graphic.GetHandleCursor(handleNumber);
                        break;
                    }
                }
                drawingCanvas.Cursor = cursor;
                return;
            }

            if (!drawingCanvas.IsMouseCaptured)
            {
                return;
            }

            wasMove = true;

            // Find difference between previous and current position
            double dx = point.X - lastPoint.X;
            double dy = point.Y - lastPoint.Y;

            if (point.X >= drawingCanvas.ActualWidth)
            {
                point.X = drawingCanvas.ActualWidth;
                dx = 0;
            }

            if (point.Y >= drawingCanvas.ActualHeight)
            {
                point.Y = drawingCanvas.ActualHeight;
                dy = 0;
            }

            lastPoint = point;

            if (selectMode == SelectionMode.Size) // ROI ��������.
            {
                if (resizedObject != null)
                {
                    bool bCanResize = true;

                    if (drawingCanvas.IsBasedCanvas) // ��ü ���󿡼� Resize ����.
                        bCanResize = false;
                    else if (resizedObject.RegionType == GraphicsRegionType.LocalAlign) // Local Align Resize ����.
                        bCanResize = false;

                    if (bCanResize)
                    {
                        resizedObject.MoveHandleTo(point, resizedObjectHandle); // Resize
                    }
                    else
                    {
                        drawingCanvas.Cursor = HelperFunctions.DefaultCursor;
                    }
                }
            }
            else if (selectMode == SelectionMode.Move) // ROI �̵�
            {
                if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
                {
                    foreach (GraphicsBase graphic in drawingCanvas.Selection)
                    {
                        if (graphic.RegionType == GraphicsRegionType.UnitRegion || graphic.RegionType == GraphicsRegionType.OuterRegion)
                        {
                            // UnitRegion�� OuterRegion �Ӽ��� �簢������ ����ǹǷ� �Ʒ��� ĳ������ ������ ����.
                            if (((GraphicsRectangle)graphic).IsFiducialRegion == false)
                            {
                                continue;
                            }
                        }
                        
                        // Move
                        graphic.Move(dx, dy, drawingCanvas.ActualWidth, drawingCanvas.ActualHeight);
                    }
                }
            }
            else if (selectMode == SelectionMode.GroupSelection)
            {
                // Resize selection rectangle
                drawingCanvas[drawingCanvas.Count - 1].MoveHandleTo(point, 5);
            }
        }

        /// <summary>   Handle mouse up. Return to normal state. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        /// <param name="e">                Event information to send to registered event handlers. </param>
        public override void OnMouseUp(DrawingCanvas drawingCanvas, MouseButtonEventArgs e)
        {
            if (!drawingCanvas.IsMouseCaptured)
            {
                drawingCanvas.Cursor = HelperFunctions.DefaultCursor;
                selectMode = SelectionMode.None;
                return;
            }

            if (resizedObject != null)
            {
                // after resizing
                resizedObject.Normalize();

                // Special case for text
                if (resizedObject is GraphicsText)
                {
                    (resizedObject as GraphicsText).UpdateRectangle();
                }

                resizedObject = null;
            }

            if (selectMode == SelectionMode.GroupSelection &&
                (GraphicsSelectionRectangle)drawingCanvas[drawingCanvas.Count - 1] is GraphicsSelectionRectangle)
            {
                GraphicsSelectionRectangle graphicsSelectionRectangle = (GraphicsSelectionRectangle)drawingCanvas[drawingCanvas.Count - 1];
                graphicsSelectionRectangle.Normalize();

                Rect rect = graphicsSelectionRectangle.Rectangle;
                drawingCanvas.GraphicsList.Remove(graphicsSelectionRectangle);

                foreach (GraphicsBase g in drawingCanvas.GraphicsList)
                {
                    if (g.IntersectsWith(rect))
                    {
                        g.IsSelected = true;
                    }
                }

                if (drawingCanvas.SelectionCount == 1)
                {
                    foreach(GraphicsBase selectedGraphic in drawingCanvas.Selection)
                    {
                        drawingCanvas.SelectedGraphic = selectedGraphic;
                    }
                }
            }

            drawingCanvas.ReleaseMouseCapture();
            drawingCanvas.Cursor = HelperFunctions.DefaultCursor;
            selectMode = SelectionMode.None;

            AddChangeToHistory(drawingCanvas);
        }

        /// <summary>   Set cursor. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public override void SetCursor(DrawingCanvas drawingCanvas)
        {
            drawingCanvas.Cursor = HelperFunctions.DefaultCursor;
        }

        /// <summary>   Add change to history. Called after finishing moving/resizing. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public void AddChangeToHistory(DrawingCanvas drawingCanvas)
        {
            if (commandChangeState != null && wasMove)
            {
                // Keep state after moving / resizing and add command to history
                commandChangeState.NewState(drawingCanvas);
                drawingCanvas.AddCommandToHistory(commandChangeState);

                commandChangeState = null;
            }
        }
    }
}
