// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>   Base class for all tools which create new graphic object. </summary>
    abstract class ToolObject : Tool
    {
        /// <summary> The tool cursor </summary>
        private Cursor toolCursor;

        /// <summary>   Tool cursor. </summary>
        /// <value> The tool cursor. </value>
        protected Cursor ToolCursor
        {
            get
            {
                return toolCursor;
            }
            set
            {
                toolCursor = value;
            }
        }

        /// <summary>   Left mouse is released. New object is created and resized. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        /// <param name="e">                Event information to send to registered event handlers. </param>
        public override void OnMouseUp(DrawingCanvas drawingCanvas, MouseButtonEventArgs e)
        {
            if (drawingCanvas.Count > 0)
            {
                drawingCanvas[drawingCanvas.Count - 1].Normalize();

                if (drawingCanvas[drawingCanvas.Count - 1] is GraphicsLine)
                {
                    GraphicsLine line = drawingCanvas[drawingCanvas.Count - 1] as GraphicsLine;
                    if (line != null)
                    {
                        if (line.LengthProperty == 0)
                        {
                            drawingCanvas.GraphicsList.Remove(line);
                            drawingCanvas.SelectedGraphic = null;
                        }
                    }
                }

                if (drawingCanvas.Tool != ToolType.PolyLine)
                {
                    drawingCanvas.AddCommandToHistory(new CommandAdd(drawingCanvas));
                }
            }

            drawingCanvas.Tool = ToolType.Pointer;
            drawingCanvas.Cursor = HelperFunctions.DefaultCursor;
            drawingCanvas.ReleaseMouseCapture();
        }

        /// <summary>
        /// Add new object to drawing canvas. Function is called when user left-clicks drawing canvas,
        /// and one of ToolObject-derived tools is active.
        /// </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        /// <param name="newObject">                The new object. </param>
        protected static void AddNewObject(DrawingCanvas drawingCanvas, GraphicsBase newObject)
        {
            HelperFunctions.UnselectAll(drawingCanvas);

            newObject.IsSelected = true;
            newObject.Clip = new RectangleGeometry(new Rect(0, 0, drawingCanvas.ActualWidth, drawingCanvas.ActualHeight));

            drawingCanvas.GraphicsList.Add(newObject);
            drawingCanvas.CaptureMouse();
        }

        /// <summary>   Set cursor. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        public override void SetCursor(DrawingCanvas drawingCanvas)
        {
            drawingCanvas.Cursor = this.toolCursor;
        }
    }
}
