// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.IO;

namespace Common.Drawing
{
    /// <summary>   Tool rectangle base.  </summary>
    abstract class ToolRectangleBase : ToolObject
    {
        /// <summary>   Set cursor and resize object. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        /// <param name="e">                Event information to send to registered event handlers. </param>
        public override void OnMouseMove(DrawingCanvas drawingCanvas, MouseEventArgs e)
        {
            drawingCanvas.Cursor = ToolCursor;

            if (e.LeftButton == MouseButtonState.Pressed
                && drawingCanvas.IsMouseCaptured
                && drawingCanvas.Count > 0)
            {
                Point p = e.GetPosition(drawingCanvas);
                p.X = (p.X > drawingCanvas.ActualWidth) ? drawingCanvas.ActualWidth : p.X;
                p.Y = (p.Y > drawingCanvas.ActualHeight) ? drawingCanvas.ActualHeight : p.Y;

                drawingCanvas[drawingCanvas.Count - 1].MoveHandleTo(p, 5);
            }
        }
    }
}
