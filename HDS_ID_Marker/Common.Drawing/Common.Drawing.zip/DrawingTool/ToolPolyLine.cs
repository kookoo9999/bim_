// http://www.codeproject.com/KB/WPF/WPF_DrawTools.aspx
// Author : Alex Fr
// This article, along with any associated source code and files, is licensed under The Code Project Open License (CPOL)

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.IO;

// Commented by Minseok Hwang.

namespace Common.Drawing
{
    /// <summary>   Tool polygon line.  </summary>
    class ToolPolyLine : ToolObject
    {
        public bool IsFirstClicked = true;
        public bool IsShiftPushed = false;

        /// <summary>   Gets a value indicating whether we can show context menu. </summary>
        /// <value> true if we can show context menu, false if not. </value>
        public bool CanShowContextMenu
        {
            get
            {
                // ������ ���� ���� �� �׸��⸦ �������� �ʰ� �˾� �޴��� ȣ���ϴ� ��쿡 ���Ͽ�
                // �˾� �޴��� ��½�Ű���� �Ѵ�. (SQE ��û����).
                return IsFirstClicked;
            }
        }

        /// <summary> The new polygon line </summary>
        private GraphicsPolyLine newPolyLine = null;

        /// <summary>   Initializes a new instance of the ToolPolyLine class. </summary>
        public ToolPolyLine()
        {
            using (MemoryStream stream = new MemoryStream(Properties.Resources.Pencil))
            {
                ToolCursor = new Cursor(stream); // Set Cursor.
            }
        }


        /// <summary>   Create new object. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        /// <param name="e">                Event information to send to registered event handlers. </param>
        public override void OnMouseDown(DrawingCanvas drawingCanvas, MouseButtonEventArgs e)
        {
            Point p = e.GetPosition(drawingCanvas);
            if (p.X >= drawingCanvas.ActualWidth - 1 || p.Y >= drawingCanvas.ActualHeight - 1)
            {
                return;
            }

            if (IsFirstClicked)
            {
                IsFirstClicked = false;

                SetGraphicsColor(drawingCanvas);

                newPolyLine = new GraphicsPolyLine(
                    new Point[]
                    {
                        p,
                        new Point(p.X + 1, p.Y + 1)
                    },
                    drawingCanvas.LineWidth,
                    drawingCanvas.RegionType,
                    drawingCanvas.ObjectColor,
                    drawingCanvas.TextColor,
                    drawingCanvas.ActualScale);

                AddNewObject(drawingCanvas, newPolyLine);
            }
            else // is not first clicked.
            {
                if (!IsShiftPushed)
                {
                    if (newPolyLine.Points.Length < 100) // n���� �̻����� �������� �ʵ��� ��.
                    {
                        // If not first-clicked, just add point.
                        newPolyLine.AddPoint(p);
                    }
                    else
                    {
                        drawingCanvas.drawingFinished = true;
                    }
                }
                else
                {
                    IsShiftPushed = false;
                }
            }
        }

        /// <summary>   Set cursor and resize new polyline. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        /// <param name="e">                Event information to send to registered event handlers. </param>
        public override void OnMouseMove(DrawingCanvas drawingCanvas, MouseEventArgs e)
        {
            drawingCanvas.Cursor = ToolCursor;

            if (!drawingCanvas.IsMouseCaptured)
            {
                return;
            }

            if (newPolyLine == null)
            {
                return; // precaution.
            }

            Point p = e.GetPosition(drawingCanvas);
            p.X = (p.X > drawingCanvas.ActualWidth) ? drawingCanvas.ActualWidth : p.X;
            p.Y = (p.Y > drawingCanvas.ActualHeight) ? drawingCanvas.ActualHeight : p.Y;

            if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
            {
                if (newPolyLine.Points.Length - 2 >= 0)
                {
                    IsShiftPushed = true;
                    
                    Point beforePoint = newPolyLine.Points[newPolyLine.Points.Length - 2];
                    if (Math.Abs(p.X - beforePoint.X) >= Math.Abs(p.Y - beforePoint.Y))
                    {
                        p.Y = beforePoint.Y;
                    }
                    else
                    {
                        p.X = beforePoint.X;
                    }
                }
            }
            
            newPolyLine.MoveHandleTo(p, newPolyLine.HandleCount);
        }

        /// <summary>   Left mouse is released. New object is created and resized. </summary>
        /// <param name="drawingCanvas">    The drawing canvas. </param>
        /// <param name="e">                Event information to send to registered event handlers. </param>
        public override void OnMouseUp(DrawingCanvas drawingCanvas, MouseButtonEventArgs e)
        {
            // reset.
            newPolyLine = null;
            IsFirstClicked = true;

            base.OnMouseUp(drawingCanvas, e);
        }
    }
}
